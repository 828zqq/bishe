clc;clear;
U=80;Z=160;
% 示例输入数据（多个 (x, y, t) 点）
% x, y 是点的坐标，t 是对应的参数角度
% 示例数据（多个 (x, y, t) 点）
% 数据输入
points_S = [57.3, 1.2;   % 点1，r=5，θ=30度
            19.8, -3.9; 
            -10.1, -3.8]; 
points_M = [31.8, -20.8;  % 点1，r=5，θ=30度
            10, -11;      % 点2，r=4，θ=120度
            -11.8, -2.8];
alpha = [96.1; 55.1; 17.7]; 

t_data = alpha(:)';  % 参数 t
x_s = points_S(:,1)';  % x 坐标
y_s = points_S(:,2)';  % y 坐标
x_m = points_M(:,1)';  % x 坐标
y_m = points_M(:,2)';  % y 坐标

% 调用拟合函数
[a, b, theta, h, k] = fit_ellipse(x_s, y_s, t_data);
[am, bm, thetam, hm, km] = fit_ellipse(x_m, y_m, t_data);

% 输出拟合结果
fprintf('椭圆的参数：\n');
fprintf('长轴半径 a = %.2f\n', a);
fprintf('短轴半径 b = %.2f\n', b);
fprintf('旋转角度 theta = %.2f rad (%.2f 度)\n', theta, rad2deg(theta));
fprintf('圆心坐标 h = %.2f, k = %.2f\n', h, k);

fprintf('椭圆M的参数：\n');
fprintf('长轴半径 a = %.2f\n', am);
fprintf('短轴半径 b = %.2f\n', bm);
fprintf('旋转角度 theta = %.2f rad (%.2f 度)\n', thetam, rad2deg(thetam));
fprintf('圆心坐标 h = %.2f, k = %.2f\n', hm, km);

% 可视化拟合结果
t = linspace(0, 2*pi, 100);  % 用于绘制椭圆的参数 t
x_sfit = h + a * sin(t) * cos(theta) + b * cos(t) * sin(theta);
y_sfit = k - a * sin(t) * sin(theta) + b * cos(t) * cos(theta);

x_mfit = hm + am * sin(t) * cos(thetam) + b * cos(t) * sin(thetam);
y_mfit = km - am * sin(t) * sin(thetam) + b * cos(t) * cos(thetam);

% 绘制原始数据点和拟合的椭圆
figure;
plot(x_s, y_s, 'ro', 'MarkerFaceColor', 'r');  % 原始数据点
hold on;
plot(x_sfit, y_sfit, 'b-', 'LineWidth', 2);  % 拟合椭圆
hold on;
plot(x_m, y_m, 'ro', 'MarkerFaceColor', 'g');  % 原始数据点
hold on;
plot(x_mfit, y_mfit, 'b-', 'LineWidth', 2);  % 拟合椭圆
axis equal;
title('椭圆拟合');
xlabel('X');
ylabel('Y');
legend('原始数据点', '拟合椭圆');

% 生成拟合函数
function [a, b, theta, h, k] = fit_ellipse(x_data, y_data, t_data)
    % 输入：
    % x_data    - x 坐标数据点 (n x 1)
    % y_data    - y 坐标数据点 (n x 1)
    % t_data    - 参数角度 t 数据点 (n x 1)
    % 
    % 输出：
    % a         - 长轴半径
    % b         - 短轴半径
    % theta     - 旋转角度 (单位: 弧度)
    % h         - 圆心 x 坐标
    % k         - 圆心 y 坐标

    % 定义拟合函数，椭圆的参数方程，t 变为 t - pi/2
    ellipse_model = @(params, t) ...
        params(4) + params(1) * sin(t) * cos(params(3)) + params(2) * cos(t) * sin(params(3));  % x(t)
    ellipse_model_y = @(params, t) ...
        params(5) - params(1) * sin(t) * sin(params(3)) + params(2) * cos(t) * cos(params(3));  % y(t)

    % 初始参数猜测 [a, b, theta, h, k]
    params_init = [5, 3, pi/4, 0, 0];  % 初始猜测：a, b, theta, h, k

    % 最小二乘法拟合
    options = optimset('Display', 'off');
    params_fit = lsqcurvefit(@(params, t) [ellipse_model(params, t), ellipse_model_y(params, t)], ...
                             params_init, t_data, [x_data, y_data] );

    % 提取拟合结果
    a = params_fit(1);  % 长轴半径
    b = params_fit(2);  % 短轴半径
    theta = params_fit(3);  % 旋转角度
    h = params_fit(4);  % 圆心 x 坐标
    k = params_fit(5);  % 圆心 y 坐标
    fprintf('椭圆的参数：\n');
    fprintf('长轴半径 a = %.2f\n', a);
    fprintf('短轴半径 b = %.2f\n', b);
    fprintf('旋转角度 theta = %.2f rad (%.2f 度)\n', theta, rad2deg(theta));
    fprintf('圆心坐标 h = %.2f, k = %.2f\n', h, k);
    t = linspace(0, 2*pi, 100);  % 用于绘制椭圆的参数 t
    x_sfit = h + a * sin(t) * cos(theta) + b * cos(t) * sin(theta);
    y_sfit = k - a * sin(t) * sin(theta) + b * cos(t) * cos(theta);
    figure;
    plot(x_data, y_data, 'ro', 'MarkerFaceColor', 'r');  % 原始数据点
    hold on;
    plot(x_sfit, y_sfit, 'b-', 'LineWidth', 2);  % 拟合椭圆
    axis equal;
    title('椭圆拟合');
    xlabel('X');
    ylabel('Y');
    legend('原始数据点', '拟合椭圆');


end
