function M_PSD = M_RelativeCoorTransfer1(direction_vector_Mzhou,ordered_circle_points,Mpoint_anzhuang,theta,laser_trajectory)
%根据M轴向量，圆周点起始坐标，M轴安装点,旋转角度和S机激光与M平面交点求出相对于M机PSD的相对坐标
normal_vector = direction_vector_Mzhou / norm(direction_vector_Mzhou);

% 定义平面局部坐标系的两个基向量 u 和 v
u_vector = ordered_circle_points(1, :) - Mpoint_anzhuang; % 第一个和第二个点确定 u 向量
u_vector = u_vector / norm(u_vector); % 单位化
v_vector = cross(normal_vector, u_vector); % 与法向量和 u 垂直
v_vector = v_vector / norm(v_vector); % 单位化

% 初始化二维坐标数组
projected_laser_trajectory_xy = zeros(size(laser_trajectory, 1), 2);
projected_circle_points_xy =zeros(size(ordered_circle_points,1),2);
% 计算 laser_trajectory 在初始局部坐标系下的二维坐标
for i = 1:size(projected_laser_trajectory_xy, 1)
    relative_vector = laser_trajectory(i, :) - Mpoint_anzhuang; % 相对于局部原点的向量
    projected_laser_trajectory_xy(i, 2) = dot(relative_vector, u_vector); % y坐标（投影到 u）
    projected_laser_trajectory_xy(i, 1) = dot(relative_vector, v_vector); % x 坐标（投影到 v）
end

for i = 1:size(projected_circle_points_xy, 1)
    relative_vector = ordered_circle_points(i, :) - Mpoint_anzhuang; % 相对于局部原点的向量
    projected_circle_points_xy(i, 2) = dot(relative_vector, u_vector); % y 坐标（投影到 u）
    projected_circle_points_xy(i, 1) = dot(relative_vector, v_vector); % x 坐标（投影到 v）
end



%相对坐标系转化
M_PSD=projected_laser_trajectory_xy-projected_circle_points_xy;
for i = 1:length(theta)
    % 旋转角度 theta(i) 的顺时针旋转矩阵
    R_MPSD = [cos(theta(i)), sin(theta(i));
           -sin(theta(i)), cos(theta(i))];
    
    M_PSD(i,:)=M_PSD(i,:)*R_MPSD;
    
end
M_PSD(:, 1) = -M_PSD(:, 1);
end