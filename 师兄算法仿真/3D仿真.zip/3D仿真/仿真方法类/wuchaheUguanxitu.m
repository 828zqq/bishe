clc;clear;
addpath('D:\开题\3D仿真\仿真方法类');
addpath('D:\开题\3D仿真\仿真方法类\距离U对公式影响');
%addpath('D:\开题\3D仿真');
%输入变量
% 初始化空数组，存储结果
mean_ex = [];
mean_ey = [];
mean_Sx = [];
mean_Sy = [];
Uhuatu = 10:10:1000;  % 设置U的范围
length_U = length(Uhuatu);  % 获取U的长度
for U = 1:length_U

Z=2*U;
ex=0.34;ey=-0.8;Sx=-0.2;Sy=-0.2;%S(mm/100mm) e(mm)
% 创建一个新的图形窗口
Sx_kaikou=Sx*U/100;
Sy_kaikou=Sy*U/100;
%S机M机距离Z，以及S机到联轴器中心距离
ls=150;%S机激光距离
lm=150;%M机PSD到轴的距离
l_length=30;
% 生成圆周上的点
theta = linspace(0, 2*pi, 25);  % 圆周角度范围
shaft=shaft_Line();
shaft=shaft.build_shaft_3D(ex,ey,Sx_kaikou,Sy_kaikou,U,Z);
%生成S机平面、M机平面圆周点
M_ordered_circle_points=OrderedCirclePoints(shaft.direction_vector_Mzhou,shaft.Mpoint_anzhuang,lm,l_length);
S_ordered_circle_points=OrderedCirclePoints(shaft.direction_vector_Szhou,shaft.Spoint_anzhuang,ls,l_length);
%创建M机S机平面
Mplane=Plane(shaft.direction_vector_Mzhou,shaft.Mpoint_anzhuang);
Splane=Plane(shaft.direction_vector_Szhou,shaft.Spoint_anzhuang);
%构建激光方向向量
%S_M_laser = Vector3D(S_ordered_circle_points.Chang_0point,M_ordered_circle_points.Chang_0point);
%M_S_laser = Vector3D(M_ordered_circle_points.Duan_0point,S_ordered_circle_points.Duan_0point);
S_M_laser = shaft.direction_vector_Szhou;
M_S_laser = -shaft.direction_vector_Mzhou;
%激光与平面交点集合
%M_Lasertrajectory=findIntersection_again(shaft.direction_vector_Szhou,S_M_laser.line,Mplane,theta,S_ordered_circle_points.ordered_circle_points_chang);
%S_Lasertrajectory=findIntersection_again(shaft.direction_vector_Mzhou,M_S_laser.line,Splane,theta,M_ordered_circle_points.ordered_circle_points_duan);
M_Lasertrajectory=findIntersection_again(shaft.direction_vector_Szhou,S_M_laser,Mplane,theta,S_ordered_circle_points.ordered_circle_points_chang);
S_Lasertrajectory=findIntersection_again(shaft.direction_vector_Mzhou,M_S_laser,Splane,theta,M_ordered_circle_points.ordered_circle_points_duan);%下面两行是激光平行于轴线
%坐标系转换到Mpsd和Spsd
M_PSD=M_RelativeCoorTransfer(shaft.direction_vector_Mzhou,M_ordered_circle_points.ordered_circle_points_chang,shaft.Mpoint_anzhuang,theta,M_Lasertrajectory);
S_PSD=S_RelativeCoorTransfer(theta,S_ordered_circle_points.Duan_0point,S_Lasertrajectory);
 % 获取对齐的结果并存储
    [ex_val, ey_val, Sx_val, Sy_val] = anypoints2(S_PSD, M_PSD, theta, U, Z,ex,ey,Sx,Sy);
    
    % 将返回的值存储在对应的数组中
    mean_ex = [mean_ex, ex_val];  % 存储ex的值
    mean_ey = [mean_ey, ey_val];  % 存储ey的值
    mean_Sx = [mean_Sx, Sx_val];  % 存储Sx的值
    mean_Sy = [mean_Sy, Sy_val];  % 存储Sy的值
end

figure;
% 第一个子图：ex的变化
subplot(2, 2, 1);  % 2行2列的第一个子图
scatter(Uhuatu, mean_ex, 'r');  % 绘制ex随U变化的散点图，红色
title('ex随U变化'); % 设置标题
xlabel('U'); % X轴标签
ylabel('ex'); % Y轴标签

% 第二个子图：ey的变化
subplot(2, 2, 2);  % 2行2列的第二个子图
scatter(Uhuatu, mean_ey, 'g');  % 绘制ey随U变化的散点图，绿色
title('ey随U变化'); % 设置标题
xlabel('U'); % X轴标签
ylabel('ey'); % Y轴标签

% 第三个子图：Sx的变化
subplot(2, 2, 3);  % 2行2列的第三个子图
scatter(Uhuatu, mean_Sx, 'b');  % 绘制Sx随U变化的散点图，蓝色
title('Sx随U变化'); % 设置标题
xlabel('U'); % X轴标签
ylabel('Sx'); % Y轴标签

% 第四个子图：Sy的变化
subplot(2, 2, 4);  % 2行2列的第四个子图
scatter(Uhuatu, mean_Sy, 'm');  % 绘制Sy随U变化的散点图，紫色
title('Sy随U变化'); % 设置标题
xlabel('U'); % X轴标签
ylabel('Sy'); % Y轴标签

% 设置总标题
exStr = num2str(ex);
eyStr = num2str(ey);
SxStr = num2str(Sx);
SyStr = num2str(Sy);
sgtitle(['仿真坐标代公式计算标准差随安装距离变化,ex=', exStr, ';ey=', eyStr, ';Sx=', SxStr, ';Sy=', SyStr]);
 % 设置整个图形窗口的总标题
%k = 19/25; 
%U = 25;
%maxPoints = 34; 
%result = zeros(100, 5); 
%count = 0;
%
%figure
%scatter(data{:,1}, data{:,2}, [], 'b');
%hold on;
%
%scatter(data{:,4}, data{:,5}, [], 'g');

%legend("S机实测点","M机实测","S机仿真","M机仿真")
%axis equal;
%line([0, 360], [0.01, 0.01], 'linestyle', '--', 'color', 'r');
%line([0, 360], [-0.01, -0.01], 'linestyle', '--', 'color', 'r');

%title("同一根轴任意点法所求不对中量");
%xlabel("横坐标角度（data(i,3)）");
%ylabel("不对中量mm");

figure;
% 第一个子图：ex的变化
subplot(2, 2, 1);  % 2行2列的第一个子图
scatter(Uhuatu, 100*abs((mean_ex)/ex), 'r');  % 绘制ex随U变化的散点图，红色
title('ex随U变化'); % 设置标题
xlabel('U'); % X轴标签
ylabel('ex'); % Y轴标签
% 设置y轴刻度格式为百分比
ytickformat(gca, '%,.0f');  % 设置y轴为百分比格式

% 第二个子图：ey的变化
subplot(2, 2, 2);  % 2行2列的第二个子图
scatter(Uhuatu, 100*abs((mean_ey)/ey), 'g');  % 绘制ey随U变化的散点图，绿色
title('ey随U变化'); % 设置标题
xlabel('U'); % X轴标签
ylabel('ey'); % Y轴标签
% 设置y轴刻度格式为百分比
ytickformat(gca, '%,.0f');  % 显示百分比格式（没有小数点）
% 第三个子图：Sx的变化
subplot(2, 2, 3);  % 2行2列的第三个子图
scatter(Uhuatu, 100*abs((mean_Sx)/Sx), 'b');  % 绘制Sx随U变化的散点图，蓝色
title('Sx随U变化'); % 设置标题
xlabel('U'); % X轴标签
ylabel('Sx'); % Y轴标签
% 设置y轴刻度格式为百分比
ytickformat(gca, '%,.0f');  % 显示百分比格式（没有小数点）
% 第四个子图：Sy的变化
subplot(2, 2, 4);  % 2行2列的第四个子图
scatter(Uhuatu,100*abs((mean_Sy)/Sy), 'm');  % 绘制Sy随U变化的散点图，紫色
title('Sy随U变化'); % 设置标题
xlabel('U'); % X轴标签
ylabel('Sy'); % Y轴标签
% 设置y轴刻度格式为百分比
ytickformat(gca, '%,.0f');  % 显示百分比格式（没有小数点）
% 设置总标题
exStr = num2str(ex);
eyStr = num2str(ey);
SxStr = num2str(Sx);
SyStr = num2str(Sy);
sgtitle(['仿真坐标代公式计算相对不确定度随安装距离变化,ex=', exStr, ';ey=', eyStr, ';Sx=', SxStr, ';Sy=', SyStr]);
 % 设置整个图形窗口的总标题
%k = 19/25; 
%U = 25;
%maxPoints = 34; 
%result = zeros(100, 5); 
%count = 0;
%
%figure
%scatter(data{:,1}, data{:,2}, [], 'b');
%hold on;
%
%scatter(data{:,4}, data{:,5}, [], 'g');

%legend("S机实测点","M机实测","S机仿真","M机仿真")
%axis equal;
%line([0, 360], [0.01, 0.01], 'linestyle', '--', 'color', 'r');
%line([0, 360], [-0.01, -0.01], 'linestyle', '--', 'color', 'r');

%title("同一根轴任意点法所求不对中量");
%xlabel("横坐标角度（data(i,3)）");
%ylabel("不对中量mm");
hold off;
