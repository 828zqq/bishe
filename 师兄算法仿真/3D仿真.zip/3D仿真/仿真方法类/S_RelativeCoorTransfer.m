function S_PSD = S_RelativeCoorTransfer(theta, S_PSD_0point,laser_trajectory_S)
%根据旋转角度，初始点和交点轨迹将交点绝对坐标改为S面上的相对坐标
% 初始化一个矩阵来存储旋转后的点

rotated_S_PSDpoints = zeros(length(theta), 3);  % 存储逆时针旋转后的点

for i = 1:length(theta)
    % 旋转矩阵 R_z(theta)
    R_z = [cos(theta(i)), sin(theta(i)), 0;
           -sin(theta(i)), cos(theta(i)), 0;
           0, 0, 1];
    
    % 旋转后的坐标
    rotated_S_PSDpoints(i, :) = (R_z * S_PSD_0point(:))';  % 使用矩阵乘法进行旋转
end

% 移除 z 坐标，仅保留 (x, y) 投影
projected_circle_points_xy_S = rotated_S_PSDpoints(:, 1:2);
projected_laser_trajectory_xy_S = laser_trajectory_S(:, 1:2);
%%%

%相对坐标系转化
S_PSD=projected_laser_trajectory_xy_S-projected_circle_points_xy_S;
for i = 1:length(theta)
    % 旋转角度 theta(i) 的旋转矩阵
    R_SPSD = [cos(theta(i)), sin(theta(i));
           -sin(theta(i)), cos(theta(i))];
    
    S_PSD(i,:)=S_PSD(i,:)*R_SPSD;
    
end