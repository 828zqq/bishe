classdef Plane2
    %   3维平面的A，B，C，D参数
    properties
        A
        B
        C
        D
    end

    methods
        function obj = Plane2(normal,point)
            %输入 向量，point3D
            % 检查输入参数数量
            if nargin ~= 2
                error('Plane:InvalidNumberOfInputs', ...
                    'Exactly two input arguments are required.');
            end
            
            %  获取法向量分量
            obj.A = normal(1);
            obj.B = normal(2);
            obj.C = normal(3);
           % 计算D
           obj.D = -(obj.A * point(1) + obj.B * point(2) + obj.C * point(3));
        end

        function newPlane = rotateByEulerAngles(point,anzhuang_point,obj, yaw, pitch, roll)
            % 根据给定的欧拉角 (yaw, pitch, roll) 旋转平面
            % 偏航角（Yaw） - 绕Z轴旋转
            % 俯仰角（Pitch） - 绕X轴旋转
            % 横滚角（Roll） - 绕Y轴旋转
            % 定义旋转矩阵 (右手坐标系)
            R_yaw = [cos(yaw), -sin(yaw), 0;
                     sin(yaw), cos(yaw), 0;
                     0, 0, 1];
            
            R_pitch = [1, 0, 0;
                       0, cos(pitch), -sin(pitch);
                       0, sin(pitch), cos(pitch)];
            
            R_roll = [cos(roll), 0, sin(roll);
                      0, 1, 0;
                      -sin(roll), 0, cos(roll)];
            
            % 按照 Yaw -> Roll-> Pitch 的顺序应用旋转
            R_total =  R_yaw* R_roll * R_pitch ; % 注意乘法顺序
            
            % 应用旋转矩阵到原始法向量上
            originalNormal = [obj.A, obj.B, obj.C];
            normal =originalNormal/norm(originalNormal);
       
             % 相对坐标系y轴
             v2 =  point - anzhuang_point;
             v2 = v2/norm(v2);
             %相对坐标系x轴
             v1 =  cross(v2,normal);
             %对初始激光向量[0,0,1]进行旋转
             newvector = R_total * [0;0;1];
             newNormal = [v1(:),v2(:),normal(:)]* newvector;
            
            % 创建新的平面对象
            newPlane = Plane2(newNormal,point);
       end
       function plotPlane(obj, ax, color)
    % 定义一个矩形区域来表示平面的一部分
    [X, Y] = meshgrid(-10:1:10, -10:1:10);
    Z = (-obj.A * X - obj.B * Y - obj.D) / obj.C;
    
    % 绘制平面
    surf(ax, X, Y, Z, 'FaceColor', color, 'EdgeColor', 'none');
    alpha(ax, 0.5); % 设置透明度
       end
    end
end