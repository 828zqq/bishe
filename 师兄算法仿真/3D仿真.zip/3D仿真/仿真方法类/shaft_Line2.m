classdef shaft_Line2
    %UNTITLED2 此处显示有关此类的摘要
    %   此处显示详细说明

    properties
        Spoint_anzhuang
        Mpoint_anzhuang
        direction_vector_Mzhou
        direction_vector_Szhou
        
    end

    methods
        % 构造函数，用于初始化对象属性
        function obj = shaft_Line2()
            % 可根据需要设置默认值，这里先初始化为空值
            obj.Spoint_anzhuang = [0,0,0];
            obj.Mpoint_anzhuang = [0,0,0];
            obj.direction_vector_Mzhou = [0,0,0];
            obj.direction_vector_Szhou = [0,0,0];
        end

        function obj = build_shaft_3D2(obj, ex, ey, Sx, Sy, U, Z)
            % 计算方向向量
            k = abs((Z - U) / U);
            %cos_ty=U/(U^2+Sy^2)^(1/2);
            %sin_ty=Sy/(U^2+Sy^2)^(1/2);
            %cos_tx=U/(U^2+Sx^2)^(1/2);
            %sin_tx=Sx/(U^2+Sx^2)^(1/2);
            %costheta=U/(Sx^2+Sy^2+U^2)^(1/2);
            %hy=Sy*(Z-U)/(Sy^2+(U)^2)^(1/2);
            %hx=Sx*(Z-U)/(Sx^2+(U)^2)^(1/2);
            hx=Sx*k;
            hy=Sy*k;

            % 定义S机M机安装在轴上的坐标，这里是以S机为基准，S机所在轴一定位于Z轴
            obj.Spoint_anzhuang = [0, 0, -U];
           % obj.Mpoint_anzhuang = [-ex-hx, -ey-hy, (Z-U)*costheta]; % 近似了，因为Z是空间上两PSD的距离，这段距离并不一定平行于Z轴
          obj.Mpoint_anzhuang = [-ex-hx, -ey-hy, (Z-U)]; 
            % 修正此处，将S_Zhou的定义改为使用U，与后续逻辑更匹配
            S_Zhou = [0, 0, 0];
            M_Zhou = [-ex, -ey, 0];
            direction_vector_S = S_Zhou - obj.Spoint_anzhuang;

            % 方向向量 direction_vector_Mzhou，并进行单位化
            direction_vector_M = obj.Mpoint_anzhuang - M_Zhou;
            if( norm(direction_vector_S)~=0)
            obj.direction_vector_Szhou = direction_vector_S / norm(direction_vector_S);
            end
            % 方向向量 direction_vector_Mzhou，并进行单位化
            if( norm(direction_vector_M)~=0)
            obj.direction_vector_Mzhou = direction_vector_M / norm(direction_vector_M);
            end
        end
        
    end
end