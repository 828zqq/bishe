classdef Vector3D
    %UNTITLED2 此处显示有关此类的摘要
    %   此处显示详细说明

    properties
        dx
        dy
        dz
        length
        line
    end

    methods
        function obj = Vector3D(point1, point2)
            %   计算方向向量
            obj.dx = point2(1) - point1(1);
            obj.dy = point2(2) - point1(2);
            obj.dz = point2(3) - point1(3);
            % 计算向量的长度
            obj.length = sqrt(obj.dx^2 + obj.dy^2 + obj.dz^2);
            obj.line=[obj.dx,obj.dy,obj.dz];
        end
        
    end
end