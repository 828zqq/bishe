function fangzhenyugongshiguiji=gongshiyufangzhenduibiguijitu2(S_PSD,M_PSD,theta,ex,ey,Sx,Sy,U,Z,data)
% 创建一个新的图形窗口
k=abs((Z-U)/U);
cos_theta = cos(theta);
sin_theta = sin(theta);
xs_shice = data.S_PSD_x;  % 假设第一列的列名是 'Var1'
ys_shice = data.S_PSD_y;  % 假设第二列的列名是 'Var2'
xm_shice = data.M_PSD_x;  % 假设第四列的列名是 'Var4'
ym_shice = data.M_PSD_y;  % 假设第五列的列名是 'Var5'
%theta_shice=data(:,3);
ys = -ey * cos_theta - ex * sin_theta + Sy * cos_theta + Sx * sin_theta;
xs = ey * sin_theta  - ex * cos_theta - Sy * sin_theta + Sx * cos_theta;

ym = ey * cos_theta + ex * sin_theta + k * Sy * cos_theta + k * Sx * sin_theta;
xm = ey * sin_theta - ex * cos_theta + k * Sy * sin_theta - k * Sx * cos_theta;
for i=1:length(theta)
    theta(i)=theta(i)*180/pi;
end
figure;


%plot(S_PSD(1:length(theta), 1), S_PSD(1:length(theta), 2),'b-s','DisplayName','S_PSD');
plot(S_PSD(1:length(theta), 1)-S_PSD(1, 1), S_PSD(1:length(theta), 2)-S_PSD(1, 2),'b-s','DisplayName','S机仿真');
hold on;
plot(xs-xs(1),ys-ys(1),'k-s','DisplayName','S机公式');
%plot(xs,ys,'k-s','DisplayName','S_PSD_公式');
%绘制第二个坐标图，例如用蓝色
hold on; % 保持当前图形，以便在上面继续绘制
%plot(M_PSD(1:length(theta), 1), M_PSD(1:length(theta), 2),'r-o','DisplayName','M_PSD');
plot(M_PSD(1:length(theta), 1)-M_PSD(1, 1), M_PSD(1:length(theta), 2)-M_PSD(1, 2),'r-o','DisplayName','M机仿真');
hold on;
plot(xm-xm(1),ym-ym(01),'g-o','DisplayName','M机公式');
%plot(xm,ym,'g-o','DisplayName','M_PSD_公式');
hold on;
%plot(xs_shice-xs_shice(1),ys_shice-ys_shice(1),'c-o','DisplayName','S机实测');
plot(xs_shice,ys_shice,'c-o','DisplayName','S机实测');
hold on;
%plot(xm_shice-1*xm_shice(1),ym_shice-1*ym_shice(1),'m-o','DisplayName','M机实测');
plot(xm_shice,ym_shice,'m-o','DisplayName','M机实测');
% 设置总标题

exStr = num2str(ex);
eyStr = num2str(ey);
SxStr = num2str(Sx*100/U);
SyStr = num2str(Sy*100/U);
sgtitle(['实测坐标求得平均不对中分量,ex=', exStr, ';ey=', eyStr, ';Sx=', SxStr, ';Sy=', SyStr]);


legend("S机仿真","S机公式","M机仿真","M机公式","S机实测","M机实测")
axis equal;

hold off;
fangzhenyugongshiguiji= gcf;
end
