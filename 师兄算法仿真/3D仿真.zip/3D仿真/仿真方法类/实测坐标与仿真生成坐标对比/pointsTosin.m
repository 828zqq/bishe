clc;
clear;

data = readtable("新的表格.xlsx");
xs = data{:,1};
ys = data{:,2};
xm = data{:,4};
ym = data{:,5};
o = data{:,3};  
o2 = data{:,6};  

% 已知的三个点 (x1, y1), (x2, y2), (x3, y3)

% y_data = [2.41, 3, -1]; % 替换为实际的 y 坐标
for i=1:length(o)
    if o(i)<0
        o(i)=360-abs(o(i));
    end
end
for i=1:length(o)
    if o2(i)<0
        o2(i)=360-abs(o2(i));
    end
end
%x_data = o*pi/180;% 替换为实际的 x 坐标
%x_data_m=o2*pi/180;
% 计算对应的 y 值
% y_data = A * sin(x_data + C) + D;
all_points = cell(4,1);

% 依次将y_data设置为xs、ys、xm、ym进行拟合及保存结果
for col = 1:4
    switch col
        case 1
            y_data = xs;
            x_data = o*pi/180;
        case 2
            y_data = ys;
            x_data = o*pi/180;
        case 3
            y_data = xm;
            x_data = o2*pi/180;
        case 4
            y_data = ym;
            x_data = o2*pi/180;
    end
    
    % 定义正弦函数模型
    sine_model =@(params, x) params(1) * sin(x + params(2)) + params(3) * cos(x + params(4)) + params(5);

    
   % 初始猜测值：[A1, C1, A2, C2, D]
    initial_guess = [0.5, 0, 0.5, 0, 0];
    
    % 使用 lsqcurvefit 进行非线性最小二乘拟合
     % 增加容忍度和最大迭代次数
    options = optimoptions('lsqcurvefit', 'Display', 'off', 'MaxIter', 1000, 'FunctionTolerance', 1e-6, 'Algorithm', 'trust-region-reflective');
    
    %[params, resnorm] = lsqcurvefit(sine_model, initial_guess, x_data, y_data);
    [params, resnorm] = lsqcurvefit(sine_model, initial_guess, x_data, y_data, [], [], options);
    
   % 提取拟合参数
    A1 = params(1);
    C1 = params(2);
    A2 = params(3);
    C2 = params(4);
    D = params(5);
    
    % 定义 x 轴范围（周期为 2*pi）
    x = linspace(0, 2 * pi, 361);
    
    % 计算对应的 y 值
    y = sine_model(params, x);
    x = x';
    y = y';
    points = [x, y];
    
    % 将本次拟合的points结果保存到all_points元胞数组中
    all_points{col} = points;
    
    % 绘制拟合结果（可以选择是否每次都绘制，这里保持原代码绘制逻辑）
    x_fit = linspace(0, 2 * pi, 25);

    y_fit = sine_model(params, x_fit);
        figure;
        plot(x_data, y_data, 'ro', 'MarkerSize', 8, 'LineWidth', 2); % 原始点
        hold on;
        plot(x, y, 'r--', 'LineWidth', 2); % 拟合曲线
        xlabel('x');
        ylabel('y');
        title(['Fitted Sine Function for Column ', num2str(col)]);
        legend('Data Points', 'Fitted Curve');
        grid on;
        hold off;
end
%theta = linspace( 2 * pi, 0, 25);
%theta = linspace( 0, 2*pi, 25);
% 将拟合结果从 all_points 导入到 SPSD 和 MPSD
SPSD(:, 1) = all_points{1}(:, 2);  % 存储 xs 的拟合结果
SPSD(:, 2) = all_points{2}(:, 2);  % 存储 ys 的拟合结果

MPSD(:, 1) = all_points{3}(:, 2);  % 存储 xm 的拟合结果
MPSD(:, 2) = all_points{4}(:, 2);  % 存储 ym 的拟合结果
%mean_alignment=anypoints(SPSD,MPSD,x,25,50);
%
plot(MPSD(:, 1),MPSD(:, 2),"k-");
hold on;
plot(SPSD(:, 1),SPSD(:, 2),"r-");
%axis equal;
%mean_alignment=anypoints(SPSD,MPSD,x,50,100);