clc;clear;
addpath('D:\开题\3D仿真\仿真方法类');
addpath('D:\开题\3D仿真');
%addpath('D:\开题\3D仿真');
%输入变量
clc;clear;
data = readtable("Z=50Sx=1左右坐标值.xlsx");

%easylaser
k = 25 /25; U = 25;
result = zeros(100,20); % 各个角度差下的不对中量
count = 0;
point = 23;
for i = 1:point
     o1=data(i,3).Variables ;%o12=data(i,6).Variables;
     if(o1<0) 
           o1=o1+360;
          %if(o1>275&&o1<265&&o1<85&&o1>95)
          %    continue;
          %end
     end
    %if(o12<0)
    %    o12=o12+360;
    %end
     %if(abs(o1-o12)>3)
     %    continue;
     %end
    for j =i+1:point+1

        count = count + 1;
        
        o2=data(j,3).Variables;
        %o22=data(j,6).Variables;
        if(o2<0)
           o2=o2+360;
           %if(o2>275&&o2<265&&o2<85&&o2>95)
           %    continue;
           %end
        end
        %if(o22<0)
        % o22=o22+360;
        %end
        %if(abs(o2-o22)>3)
        % continue;
        %end
        if(abs(o1-o2)>30&&abs(o1-o2)<330)
            Xs = data(i,1).Variables - data(j,1).Variables;
            Ys = data(i,2).Variables - data(j,2).Variables;
            Xm = data(i,4).Variables - data(j,4).Variables;
            Ym = data(i,5).Variables - data(j,5).Variables;
    
            a = sin(deg2rad(data(i,3).Variables)) - sin(deg2rad(data(j,3).Variables));
            b = cos(deg2rad(data(i,3).Variables)) - cos(deg2rad(data(j,3).Variables));
            ex = (-k*a*Ys-k*b*Xs+a*Ym-b*Xm)/(k+1)/(a^2+b^2);
            ey = (-k*b*Ys+k*a*Xs+b*Ym+a*Xm)/(k+1)/(a^2+b^2);
            Sx = 100*(a*Ys+b*Xs+a*Ym-b*Xm)/(k+1)/(a^2+b^2)/U;
            Sy = 100*(b*Ys-a*Xs+b*Ym+a*Xm)/(k+1)/(a^2+b^2)/U;
            %Sx = (a*Ys+b*Xs+a*Ym-b*Xm)/(k+1)/(a^2+b^2);
            %Sy = (b*Ys-a*Xs+b*Ym+a*Xm)/(k+1)/(a^2+b^2);
            result(count,1) = abs(data(i,3).Variables - data(j,3).Variables);
            if(result(count,1)>180)
                result(count,1)=360-result(count,1);
            end
            if ex == 0 && ey == 0 && Sx == 0 && Sy == 0
                continue;  % 跳过当前循环，避免存储零值
            end
            result(count,2) = ex;
            result(count,3) = ey;
            result(count,4) = Sx;
            result(count,5) = Sy;
       
        end
        
    end
end
ex = mean(result(result(:, 2)~=0, 2), 'omitnan');
ey = mean(result(result(:, 3)~=0, 3), 'omitnan');  % 第3列有效值的均值
Sx = mean(result(result(:, 4)~=0, 4), 'omitnan');  % 第4列有效值的均值
Sy = mean(result(result(:, 5)~=0, 5), 'omitnan');
U=25;Z=50;

Sx_kaikou=Sx*U/100;
Sy_kaikou=Sy*U/100;
%S机M机距离Z，以及S机到联轴器中心距离
ls=72.5;%S机激光距离
lm=72.5;%M机PSD到轴的距离
l_length=30;

% 生成圆周上的点
theta = linspace(0, 2*pi, 25);  % 圆周角度范围
shaft=shaft_Line();
shaft=shaft.build_shaft_3D(ex,ey,Sx_kaikou,Sy_kaikou,U,Z);
%生成S机平面、M机平面圆周点
M_ordered_circle_points=OrderedCirclePoints(shaft.direction_vector_Mzhou,shaft.Mpoint_anzhuang,lm,l_length);
S_ordered_circle_points=OrderedCirclePoints(shaft.direction_vector_Szhou,shaft.Spoint_anzhuang,ls,l_length);
%创建M机S机平面
Mplane=Plane(shaft.direction_vector_Mzhou,shaft.Mpoint_anzhuang);
Splane=Plane(shaft.direction_vector_Szhou,shaft.Spoint_anzhuang);

%平面发生偏斜：
%Mplane=rotateByEulerAngles(M_ordered_circle_points,shaft.Mpoint_anzhuang,obj,0,02*pi/180,0,02*pi/180, 0);
%Splane=rotateByEulerAngles(S_ordered_circle_points,shaft.Spoint_anzhuang,obj,0,02*pi/180,0,02*pi/180, 0);
%Mplane_shaft=[Mplane.A,Mplane.B,Mplane.C];

%构建激光方向向量
%S_M_laser = Vector3D(S_ordered_circle_points.Chang_0point,M_ordered_circle_points.Chang_0point);
%M_S_laser = Vector3D(M_ordered_circle_points.Duan_0point,S_ordered_circle_points.Duan_0point);
%S_M_laser = shaft.direction_vector_Szhou;
%M_S_laser = -shaft.direction_vector_Mzhou;
%激光发生偏斜
S_M_laser = VrotateByEulerAngles(S_ordered_circle_points.Chang_0point,shaft.Spoint_anzhuang,0,02*pi/180,-2*pi/180,Splane);
M_S_laser = VrotateByEulerAngles(M_ordered_circle_points.Duan_0point,shaft.Mpoint_anzhuang,0,-2*pi/180,-4*pi/180,Mplane);
%激光与平面交点集合
%M_Lasertrajectory=findIntersection_again(shaft.direction_vector_Szhou,S_M_laser.line,Mplane,theta,S_ordered_circle_points.ordered_circle_points_chang);
%S_Lasertrajectory=findIntersection_again(shaft.direction_vector_Mzhou,M_S_laser.line,Splane,theta,M_ordered_circle_points.ordered_circle_points_duan);
M_Lasertrajectory=findIntersection_again(shaft.direction_vector_Szhou,S_M_laser,Mplane,theta,S_ordered_circle_points.ordered_circle_points_chang);
S_Lasertrajectory=findIntersection_again(shaft.direction_vector_Mzhou,M_S_laser,Splane,theta,M_ordered_circle_points.ordered_circle_points_duan);%下面两行是激光平行于轴线
%坐标系转换到Mpsd和Spsd
M_PSD=M_RelativeCoorTransfer(shaft.direction_vector_Mzhou,M_ordered_circle_points.ordered_circle_points_chang,shaft.Mpoint_anzhuang,theta,M_Lasertrajectory);
S_PSD=S_RelativeCoorTransfer(theta,S_ordered_circle_points.Duan_0point,S_Lasertrajectory);
%将坐标代入到不对中量计算函数
mean_alignment=anypoints(S_PSD,M_PSD,theta,U,Z);
%对比仿真和公式坐标轨迹
%fangzhengongshiduibi=shiceyufangzhenduibizhenghetu2(S_PSD,M_PSD,theta,ex,ey,Sx_kaikou,Sy_kaikou,U,Z,data);%单独列出xy坐标分布
fangzhengongshiguiji=gongshiyufangzhenduibiguijitu2(S_PSD,M_PSD,theta,ex,ey,Sx_kaikou,Sy_kaikou,U,Z,data);%看轨迹
%随着安装距离U的增大，四个不对中量变化
