function fangzhenyugongshicha=xinjiucha_and_fangzhenxincha(S_PSD,M_PSD,theta,ex,ey,Sx,Sy,U,Z,lm)
% 创建一个新的图形窗口
k=abs((Z-U)/U);
cos_theta = cos(theta);
sin_theta = sin(theta);
xs_fangzhen=S_PSD(:,1)';
ys_fangzhen=S_PSD(:,2)';
xm_fangzhen=M_PSD(:,1)';
ym_fangzhen=M_PSD(:,2)';

%ys = -ey * cos_theta - ex * sin_theta + (Sy+Gy) * cos_theta + (Sx+Gx) * sin_theta;

%%新版公式
%cos_ty=U/(U^2+Sy^2)^(1/2);
%sin_ty=Sy/(U^2+Sy^2)^(1/2);
%cos_tx=U/(U^2+Sx^2)^(1/2);
%sin_tx=Sx/(U^2+Sx^2)^(1/2);
%Gy=lm*(1-cos_ty)*cos_theta/(cos_ty);
%Gx=lm*(1-cos_tx)*sin_theta/(cos_tx);
%ys = -ey * cos_theta - ex * sin_theta + (Sy+Gy).* cos_theta + (Sx+Gx) .* sin_theta;
%xs = ey * sin_theta  - ex * cos_theta - (Sy+Gy) .* sin_theta + (Sx+Gx) .* cos_theta;
%ym = ey * cos_theta + ex * sin_theta +  (Sy+Gy).* cos_theta + (Sx+Gx).* sin_theta;
%xm= ey * sin_theta - ex * cos_theta +  (Sy+Gy) .* sin_theta -  (Sx+Gx) .* cos_theta;

%新版公式2.0
S=(Sx^2+Sy^2)^(1/2);
sin_gama=Sx/S;
cos_gama=Sy/S;
cos_tS=U/(S^2+U^2)^(1/2);
costhetarotated=cos_theta*cos_gama+sin_theta*sin_gama;
deta_y=lm*(1-cos_tS)*costhetarotated/(cos_tS)+S;
KX=sin_gama*cos_theta-sin_theta*cos_gama;
KY=sin_gama*sin_theta+cos_theta*cos_gama;
ys = -ey * cos_theta - ex * sin_theta + deta_y.*KY;
xs = ey * sin_theta  - ex * cos_theta + deta_y.*KX;
ym = ey * cos_theta + ex * sin_theta + deta_y.*KY;
xm= ey * sin_theta - ex * cos_theta - deta_y.*KX;
%老公式
%ys_old =0;
%xs_old =0;
%ym_old =0;
%xm_old =0;
ys_old = -ey * cos_theta - ex * sin_theta + Sy* cos_theta+ Sx* sin_theta;
xs_old = ey * sin_theta  - ex * cos_theta - Sy * sin_theta + Sx * cos_theta;
ym_old = ey * cos_theta + ex * sin_theta +  Sy * cos_theta +  Sx * sin_theta;
xm_old = ey * sin_theta - ex * cos_theta +  Sy * sin_theta -  Sx * cos_theta;
for i=1:length(theta)
    theta(i)=theta(i)*180/pi;
end
figure;

%拟合后的曲线
%取点
%ys_nihe=[ys(1),ys(90),ys(270)];
%alpha_nihe=[theta(1),theta(90),theta(270)];
%params=threepoints_nihe2(ys_nihe, alpha_nihe,U);
% 获取拟合出的参数
%ey_IN = params(1);
%ex_IN = params(2);
%Sy_IN = params(3);
%Sx_IN = params(4);  % γ 值（弧度）
%H = params(5);
%
%ys_fit=H * ((sqrt(sqrt(Sy_IN^2 + Sx_IN^2)^2 + U^2) - U) / U) * ...
%        cos(asin(Sx_IN / sqrt(Sy_IN^2 +Sx_IN^2))-theta).^2 + ...
%        (-ex_IN * cos(theta) - ey_IN * sin(theta) + Sy_IN * cos(theta) + Sx_IN * sin(theta));

% 第一个子图
subplot(2, 2, 1);  % 2行2列的第一个子图
scatter(theta, xs_fangzhen-xs_fangzhen(1)-xs+xs(1), 'r');  % 绘制xs_fangzhen的散点图，红色

hold on;  % 保持当前图形，继续绘制其他数据

scatter(theta, xs-xs(1)-(xs_old-xs_old(1)), 'b');  % 绘制xs的散点图


title('xs仿真与公式对比'); % 设置标题
legend('xs仿真与新公式差值', 'xs新公式与老公式差值');  % 设置图例，标识不同的数据系列

% 第二个子图
subplot(2, 2, 2);  % 2行2列的第二个子图
scatter(theta, xm_fangzhen-xm_fangzhen(01)-xm+xm(1), 'r');  % 绘制xm_fangzhen的散点图，红色
hold on;  % 保持当前图形，继续绘制其他数据
scatter(theta, xm-xm(01)-(xm_old-xm_old(1)), 'b');  % 绘制xm的散点图

title('xm仿真与公式对比'); % 设置标题
legend('xm仿真与新公式差值', 'xm新公式与老公式差值');  % 设置图例，标识不同的数据系列
% 第三个子图
subplot(2, 2, 3);  % 2行2列的第三个子图
scatter(theta, ys_fangzhen-ys_fangzhen(01)-ys+ys(1), 'r');  % 绘制ys_fangzhen的散点图，蓝色
hold on;  % 保持当前图形，继续绘制其他数据
scatter(theta, ys-ys(01)-(ys_old-ys_old(1)), 'b');  % 绘制ys的散点图
 hold on;
% scatter(theta, ys-ys(1)-(ys_fit), 'k');  % 绘制xs的散点图
title('ys仿真与公式对比'); % 设置标题
legend('ys仿真与新公式差值', 'ys新公式与老公式差值','新公式与拟合公式差值');  % 设置图例，标识不同的数据系列

% 第四个子图
subplot(2, 2, 4);  % 2行2列的第四个子图
scatter(theta, ym_fangzhen-ym_fangzhen(01)-ym+ym(1), 'r');  % 绘制ym_fangzhen的散点图，黑色
hold on;  % 保持当前图形，继续绘制其他数据
scatter(theta, ym-ym(01)-(ym_old-ym_old(1)), 'b');  % 绘制ym的散点图

title('ym仿真与公式对比'); % 设置标题
legend('ym仿真与新公式差值', 'ym新公式与老公式差值');  % 设置图例，标识不同的数据系列

% 设置总标题
exStr = num2str(ex);
eyStr = num2str(ey);
SxStr = num2str(Sx*100/U);
SyStr = num2str(Sy*100/U);
sgtitle(['仿真与公式坐标对比,ex=', exStr, ';ey=', eyStr, ';Sx=', SxStr, ';Sy=', SyStr]);
 % 设置整个图形窗口的总标题
%k = 19/25; 
%U = 25;
%maxPoints = 34; 
%result = zeros(100, 5); 
%count = 0;
%
%figure
%scatter(data{:,1}, data{:,2}, [], 'b');
%hold on;
%
%scatter(data{:,4}, data{:,5}, [], 'g');

%legend("S机实测点","M机实测","S机仿真","M机仿真")
%axis equal;
%line([0, 360], [0.01, 0.01], 'linestyle', '--', 'color', 'r');
%line([0, 360], [-0.01, -0.01], 'linestyle', '--', 'color', 'r');

%title("同一根轴任意点法所求不对中量");
%xlabel("横坐标角度（data(i,3)）");
%ylabel("不对中量mm");
hold off;
fangzhenyugongshicha= gcf;
end
function params = threepoints_nihe2(ys, alpha_vals,U)
    % 输入:
    % ys - 包含 ys 值的向量 (长度为3)
    % alpha_vals - 对应的 α 值 (长度为3, 单位为弧度)
    % 输出:
    % params - 拟合出的 [ey, ex, A, γ, S] 参数

    % 定义模型函数
     model = @(params, alpha, U) ...
        params(5) * ((sqrt(sqrt(params(3)^2 + params(4)^2)^2 + U^2) - U) / U) * ...
        cos(asin(params(4) / sqrt(params(3)^2 + params(4)^2))-alpha).^2 + ...
        (-params(2) * cos(alpha) - params(1) * sin(alpha) + params(3) * cos(alpha) + params(4) * sin(alpha));
    

       
    
    % 初始猜测值 [ey, ex, Sy, Sx, H]
    initial_guess = [0.01, 0.01, 0.1, 0.1, 200]; 
    
    % 定义优化选项
    % 定义优化选项
    options = optimset('Display', 'iter', ...    % 显示每次迭代的信息
                       'TolFun', 1e-8, ...       % 函数值收敛容差
                       'TolX', 1e-8, ...         % 参数变化收敛容差
                       'MaxIter', 1000, ...      % 最大迭代次数
                       'MaxFunEvals', 2000);     % 最大函数评估次数
    
    % 使用 lsqcurvefit 进行拟合
    params = lsqcurvefit( ...
        @(params, alpha) model(params, alpha,U), ... % 模型函数
        initial_guess, ...                         % 初始值
        alpha_vals, ...                            % 输入 α
        ys, ...                                    % 输出 ys
        [], [], options);                          % 无边界限制
    
    % 输出拟合结果
    fprintf('Fitted ey: %f\n', params(1));
    fprintf('Fitted ex: %f\n', params(2));
    fprintf('Fitted Sy: %f\n', params(3)*100/U);
    fprintf('Fitted Sx: %f\n', params(4)*100/U);
    fprintf('Fitted H: %f\n', params(5));
    
end

