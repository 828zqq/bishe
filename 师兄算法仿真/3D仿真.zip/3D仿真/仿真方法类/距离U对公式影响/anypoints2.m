function [mean_ex,mean_ey,mean_Sx,mean_Sy]=anypoints2(S_PSD,M_PSD,theta,U,Z,ex_in,ey_in,Sx_in,Sy_in)
point = length(theta)-2;
count=0;
result = zeros(100,20);
k = abs((Z-U)/U);
for i = 1:point
     o1=theta(i)* 180/pi ;%o12=data(i,6).Variables;
     if(o1<0) 
           o1=o1+360;
          %if(o1>275&&o1<265&&o1<85&&o1>95)
          %    continue;
          %end
     end
    %if(o12<0)
    %    o12=o12+360;
    %end
     %if(abs(o1-o12)>3)
     %    continue;
     %end
    for j =i+1:point+1

        count = count + 1;
        
        o2=theta(j)* 180/pi;
        %o22=data(j,6).Variables;
        if(o2<0)
           o2=o2+360;
           %if(o2>275&&o2<265&&o2<85&&o2>95)
           %    continue;
           %end
        end
        %if(o22<0)
        % o22=o22+360;
        %end
        %if(abs(o2-o22)>3)
        % continue;
        %end
        if(abs(o1-o2)>30&&abs(o1-o2)<330)
            Xs = S_PSD(i,1) - S_PSD(j,1);
            Ys = S_PSD(i,2) - S_PSD(j,2);
            Xm = M_PSD(i,1) - M_PSD(j,1);
            Ym = M_PSD(i,2) - M_PSD(j,2);
    
            a = sin(theta(i)) - sin(theta(j));
            b = cos(theta(i)) - cos(theta(j));
            ex = (-k*a*Ys-k*b*Xs+a*Ym-b*Xm)/(k+1)/(a^2+b^2);
            ey = (-k*b*Ys+k*a*Xs+b*Ym+a*Xm)/(k+1)/(a^2+b^2);
            Sx = 100*(a*Ys+b*Xs+a*Ym-b*Xm)/(k+1)/(a^2+b^2)/U;
            Sy = 100*(b*Ys-a*Xs+b*Ym+a*Xm)/(k+1)/(a^2+b^2)/U;
           %Sx = (a*Ys+b*Xs+a*Ym-b*Xm)/(k+1)/(a^2+b^2);
           %Sy = (b*Ys-a*Xs+b*Ym+a*Xm)/(k+1)/(a^2+b^2);
           % 检查ex, ey, Sx, Sy 是否都不为零
            if ex == 0 && ey == 0 && Sx == 0 && Sy == 0
                continue;  % 跳过当前循环，避免存储零值
            end
            result(count,1) = abs(theta(i)* 180/pi - theta(j)* 180/pi);
            if(result(count,1)>180)
                result(count,1)=360-result(count,1);
            end
            result(count,2) = ex;
            result(count,3) = ey;
            result(count,4) = Sx;
            result(count,5) = Sy;
       
        end
        
    end
end
% 在计算完所有数据之后，删除每一行都为零的行
result(all(result(:, 2:5) == 0, 2), :) = [];
std_ex=max(abs(result(:,2)-ex_in)); 
std_ey=max(abs(result(:,3)-ey_in));
std_Sx=max(abs(result(:,4)-Sx_in));
std_Sy=max(abs(result(:,5)-Sy_in));
%mean_ex = mean(result(result(:, 2)~=0, 2), 'omitnan');
%mean_ey = mean(result(result(:, 3)~=0, 3), 'omitnan');  % 第3列有效值的均值
%mean_Sx = mean(result(result(:, 4)~=0, 4), 'omitnan');  % 第4列有效值的均值
%mean_Sy = mean(result(result(:, 5)~=0, 5), 'omitnan'); 
mean_ex=std_ex;
mean_ey=std_ey;
mean_Sx=std_Sx;
mean_Sy=std_Sy;


end