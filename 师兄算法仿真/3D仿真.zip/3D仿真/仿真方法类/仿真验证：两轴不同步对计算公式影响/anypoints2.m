% 任意点法计算不对中量

function mean_alignment=anypoints2(S_PSD,M_PSD,theta,U,Z)
point = length(theta)-4;
count=0;
count2=0;
count3=0;
result = zeros(100,20);
result2 = zeros(100,20);
result3 = zeros(100,20);
k = abs((Z-U)/U);
step=10;
for i = 1:step:point
     o1=theta(i)* 180/pi ;%o12=data(i,6).Variables;
     if(o1<0) 
           o1=o1+360;
          %if(o1>275&&o1<265&&o1<85&&o1>95)
          %    continue;
          %end
     end
    %if(o12<0)
    %    o12=o12+360;
    %end
     %if(abs(o1-o12)>3)
     %    continue;
     %end
    for j =i+1:step:point+1

        count = count + 1;
        
        o2=theta(j)* 180/pi;
        
        %o22=data(j,6).Variables;
        if(o2<0)
           o2=o2+360;
           %if(o2>275&&o2<265&&o2<85&&o2>95)
           %    continue;
           %end
        end
        %if(o22<0)
        % o22=o22+360;
        %end
        %if(abs(o2-o22)>3)
        % continue;
        %end
        if(abs(o1-o2)>30&&abs(o1-o2)<330)
            Xs = S_PSD(i,1) - S_PSD(j,1);
            Ys = S_PSD(i,2) - S_PSD(j,2);
            Xm = M_PSD(i,1) - M_PSD(j,1);
            Ym = M_PSD(i,2) - M_PSD(j,2);
            %theta(j)=(theta(j)*180/pi-2)*pi/180;%让o2偏移0.6°
            a = sin(theta(i)) - sin(theta(j));
            b = cos(theta(i)) - cos(theta(j));
            
            Sx = 100*(a*Ys+b*Xs+a*Ym-b*Xm)/(k+1)/(a^2+b^2)/U;
            
           %Sx = (a*Ys+b*Xs+a*Ym-b*Xm)/(k+1)/(a^2+b^2);
           %Sy = (b*Ys-a*Xs+b*Ym+a*Xm)/(k+1)/(a^2+b^2);
            result(count,1) = abs(theta(i)* 180/pi - theta(j)* 180/pi);
            if(result(count,1)>180)
                result(count,1)=360-result(count,1);
            end
           
            
          
            result(count,4) = Sx;
            
       
        end
        
    end
end
for i = 1:step:point
     o1=theta(i)* 180/pi ;%o12=data(i,6).Variables;
     if(o1<0) 
           o1=o1+360;
          %if(o1>275&&o1<265&&o1<85&&o1>95)
          %    continue;
          %end
     end
    %if(o12<0)
    %    o12=o12+360;
    %end
     %if(abs(o1-o12)>3)
     %    continue;
     %end
    for j =i+1:step:point+1

        count2 = count2 + 1;
        
        o2=theta(j)* 180/pi;
        
        %o22=data(j,6).Variables;
        if(o2<0)
           o2=o2+360;
           %if(o2>275&&o2<265&&o2<85&&o2>95)
           %    continue;
           %end
        end
        %if(o22<0)
        % o22=o22+360;
        %end
        %if(abs(o2-o22)>3)
        % continue;
        %end
        if(abs(o1-o2)>30&&abs(o1-o2)<330)
            Xs = S_PSD(i,1) - S_PSD(j,1);
            Ys = S_PSD(i,2) - S_PSD(j,2);
            if o1>50&&o1<310
               Xm = M_PSD(i-1,1) - M_PSD(j-1,1);
               Ym = M_PSD(i-1,2) - M_PSD(j-1,2);
            else
               Xm = M_PSD(i,1) - M_PSD(j,1);
               Ym = M_PSD(i,2) - M_PSD(j,2); 
            end
            %theta(j)=(theta(j)*180/pi-2)*pi/180;%让o2偏移0.6°
            a = sin(theta(i)) - sin(theta(j));
            b = cos(theta(i)) - cos(theta(j));
            
            Sx = 100*(a*Ys+b*Xs+a*Ym-b*Xm)/(k+1)/(a^2+b^2)/U;
            
           %Sx = (a*Ys+b*Xs+a*Ym-b*Xm)/(k+1)/(a^2+b^2);
           %Sy = (b*Ys-a*Xs+b*Ym+a*Xm)/(k+1)/(a^2+b^2);
            result2(count2,1) = abs(theta(i)* 180/pi - theta(j)* 180/pi);
            if(result2(count2,1)>180)
                result2(count2,1)=360-result2(count2,1);
            end
            
            
            
          
            result2(count2,4) = Sx;
            
       
        end
        
    end
end
for i = 1:step:point
     o1=theta(i)* 180/pi ;%o12=data(i,6).Variables;
     if(o1<0) 
           o1=o1+360;
          %if(o1>275&&o1<265&&o1<85&&o1>95)
          %    continue;
          %end
     end
    %if(o12<0)
    %    o12=o12+360;
    %end
     %if(abs(o1-o12)>3)
     %    continue;
     %end
    for j =i+1:step:point+1

        count3 = count3 + 1;
        
        o2=theta(j)* 180/pi;
        
        %o22=data(j,6).Variables;
        if(o2<0)
           o2=o2+360;
           %if(o2>275&&o2<265&&o2<85&&o2>95)
           %    continue;
           %end
        end
        %if(o22<0)
        % o22=o22+360;
        %end
        %if(abs(o2-o22)>3)
        % continue;
        %end
        if(abs(o1-o2)>30&&abs(o1-o2)<330)
            Xs = S_PSD(i,1) - S_PSD(j,1);
            Ys = S_PSD(i,2) - S_PSD(j,2);
            if o1>150&&o1<310
               Xm = M_PSD(i-2,1) - M_PSD(j-2,1);
               Ym = M_PSD(i-2,2) - M_PSD(j-2,2);
            else
               Xm = M_PSD(i,1) - M_PSD(j,1);
               Ym = M_PSD(i,2) - M_PSD(j,2); 
            end
            %theta(j)=(theta(j)*180/pi-2)*pi/180;%让o2偏移0.6°
            a = sin(theta(i)) - sin(theta(j));
            b = cos(theta(i)) - cos(theta(j));
            
            Sx = 100*(a*Ys+b*Xs+a*Ym-b*Xm)/(k+1)/(a^2+b^2)/U;
            
           %Sx = (a*Ys+b*Xs+a*Ym-b*Xm)/(k+1)/(a^2+b^2);
           %Sy = (b*Ys-a*Xs+b*Ym+a*Xm)/(k+1)/(a^2+b^2);
            result3(count3,1) = abs(theta(i)* 180/pi - theta(j)* 180/pi);
            if(result3(count3,1)>180)
                result3(count3,1)=360-result3(count3,1);
            end
          
            
            
          
            result3(count3,4) = Sx;
            
       
        end
        
    end
end
% 清理数据（去掉无效行）
result(all(result(:, 2:5) == 0, 2), :) = [];
result2(all(result2(:, 2:5) == 0, 2), :) = [];
result3(all(result3(:, 2:5) == 0, 2), :) = [];

% 提取角度差和不对中量
angle_result = abs(result(:, 1));  % 角度差
misalignment_result = result(:, 4);  % 不对中量
angle_result2 = abs(result2(:, 1));
misalignment_result2 = result2(:, 4);
angle_result3 = abs(result3(:, 1));
misalignment_result3 = result3(:, 4);

% 绘制散点图
figure;
scatter(angle_result, misalignment_result, 10, 'filled', 'MarkerFaceColor', 'b'); % 蓝色
hold on;
scatter(angle_result2, misalignment_result2, 10, 'filled', 'MarkerFaceColor', 'r'); % 红色
scatter(angle_result3, misalignment_result3, 10, 'filled', 'MarkerFaceColor', 'k'); % 黑色

% 计算并绘制凸包包络线
% 对每组数据进行凸包计算
[k1, v1] = convhull(angle_result, misalignment_result);
[k2, v2] = convhull(angle_result2, misalignment_result2);
[k3, v3] = convhull(angle_result3, misalignment_result3);

% 绘制凸包包络线
plot(angle_result(k1), misalignment_result(k1), 'b', 'LineWidth', 2);  % 蓝色包络线
plot(angle_result2(k2), misalignment_result2(k2), 'r', 'LineWidth', 2);  % 红色包络线
plot(angle_result3(k3), misalignment_result3(k3), 'k', 'LineWidth', 2);  % 黑色包络线

% 添加图例、网格和标题
legend("Sx", "Sx-偏1°", "Sx-偏2°", 'Location', 'best');
grid on;
grid minor;
title("仿真生成坐标任意点法所求不对中量");
xlabel("角度差°");
ylabel("不对中量mm");

hold off;

end