clc;clear;
addpath('D:\开题\3D仿真\仿真方法类');
addpath('D:\开题\3D仿真');
%输入变量
U=25;Z=50;
ex=-0.003;ey=0.008;Sx=0.9944;Sy=0.016;%S(mm/100mm) e(mm)
Sx_kaikou=Sx*U/100;
Sy_kaikou=Sy*U/100;
%S机M机距离Z，以及S机到联轴器中心距离
ls=72.5;%S机激光距离
lm=72.5;%M机PSD到轴的距离
l_length=30;

% 生成圆周上的点
theta = linspace(0, 2*pi, 361);  % 圆周角度范围
shaft=shaft_Line();
shaft=shaft.build_shaft_3D(ex,ey,Sx_kaikou,Sy_kaikou,U,Z);
%生成S机平面、M机平面圆周点
M_ordered_circle_points=OrderedCirclePoints(shaft.direction_vector_Mzhou,shaft.Mpoint_anzhuang,lm,l_length,theta);
S_ordered_circle_points=OrderedCirclePoints(shaft.direction_vector_Szhou,shaft.Spoint_anzhuang,ls,l_length,theta);
%创建M机S机平面
Mplane=Plane(shaft.direction_vector_Mzhou,shaft.Mpoint_anzhuang);
Splane=Plane(shaft.direction_vector_Szhou,shaft.Spoint_anzhuang);

%平面发生偏斜：
%Mplane=rotateByEulerAngles(M_ordered_circle_points,shaft.Mpoint_anzhuang,obj,0,02*pi/180,0,02*pi/180, 0);
%Splane=rotateByEulerAngles(S_ordered_circle_points,shaft.Spoint_anzhuang,obj,0,02*pi/180,0,02*pi/180, 0);
%Mplane_shaft=[Mplane.A,Mplane.B,Mplane.C];

%构建激光方向向量
%S_M_laser = Vector3D(S_ordered_circle_points.Chang_0point,M_ordered_circle_points.Chang_0point);
%M_S_laser = Vector3D(M_ordered_circle_points.Duan_0point,S_ordered_circle_points.Duan_0point);
%S_M_laser = shaft.direction_vector_Szhou;
%M_S_laser = -shaft.direction_vector_Mzhou;
%激光发生偏斜
S_M_laser = VrotateByEulerAngles(S_ordered_circle_points.Chang_0point,shaft.Spoint_anzhuang,0,0*pi/180,-0*pi/180,Splane);
M_S_laser = VrotateByEulerAngles(M_ordered_circle_points.Duan_0point,shaft.Mpoint_anzhuang,0,-1*pi/180,4*pi/180,Mplane);
%激光与平面交点集合
%M_Lasertrajectory=findIntersection_again(shaft.direction_vector_Szhou,S_M_laser.line,Mplane,theta,S_ordered_circle_points.ordered_circle_points_chang);
%S_Lasertrajectory=findIntersection_again(shaft.direction_vector_Mzhou,M_S_laser.line,Splane,theta,M_ordered_circle_points.ordered_circle_points_duan);
M_Lasertrajectory=findIntersection_again(shaft.direction_vector_Szhou,S_M_laser,Mplane,theta,S_ordered_circle_points.ordered_circle_points_chang);
S_Lasertrajectory=findIntersection_again(shaft.direction_vector_Mzhou,M_S_laser,Splane,theta,M_ordered_circle_points.ordered_circle_points_duan);%下面两行是激光平行于轴线
%坐标系转换到Mpsd和Spsd
M_PSD=M_RelativeCoorTransfer(shaft.direction_vector_Mzhou,M_ordered_circle_points.ordered_circle_points_chang,shaft.Mpoint_anzhuang,theta,M_Lasertrajectory);
S_PSD=S_RelativeCoorTransfer(theta,S_ordered_circle_points.Duan_0point,S_Lasertrajectory);
%将坐标代入到不对中量计算函数
mean_alignment=anypoints2(S_PSD,M_PSD,theta,U,Z);
%对比仿真和公式坐标轨迹
%fangzhengongshiduibi=shiceyufangzhenduibizhenghetu(S_PSD,M_PSD,theta,ex,ey,Sx_kaikou,Sy_kaikou,U,Z);%单独列出xy坐标分布
%fangzhengongshiguiji=gongshiyufangzhenduibiguijitu(S_PSD,M_PSD,theta,ex,ey,Sx_kaikou,Sy_kaikou,U,Z);%看轨迹
%随着安装距离U的增大，四个不对中量变化
