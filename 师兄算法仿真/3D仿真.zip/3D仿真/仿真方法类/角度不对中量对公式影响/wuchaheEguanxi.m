clc;clear;
addpath('D:\开题\3D仿真\仿真方法类');
addpath('D:\开题\3D仿真\仿真方法类\距离U对公式影响');
%addpath('D:\开题\3D仿真');
%输入变量
% 初始化空数组，存储结果
mean_ex = [];
mean_ey = [];
mean_Sx = [];
mean_Sy = [];
U = 100;  % 固定U的值
Z = 2*U;
% 定义不同的不对中量范围
ey_values = linspace(-2, 2, 50); % 示例：ey从-1到1变化
Sy_values = linspace(-2, 2, 50); % 示例：Sy从-0.5到0.5变化
for i = 1:length(ey_values)
        ey = ey_values(i);        
        % 执行仿真计算）
        ex=0;Sx=0;Sy=0;%S(mm/100mm) e(mm)
% 创建一个新的图形窗口
Sx_kaikou=Sx*U/100;
Sy_kaikou=Sy*U/100;
%S机M机距离Z，以及S机到联轴器中心距离
ls=150;%S机激光距离
lm=150;%M机PSD到轴的距离
l_length=30;
% 生成圆周上的点
theta = linspace(0, 2*pi, 25);  % 圆周角度范围
 [ex_val, ey_val, Sx_val, Sy_val] = fangzhenMethod(ex,ey,Sx,Sy,theta,ls,lm,l_length,U) ;
 % 假设我们已经得到了计算后的值 ex_val 和 ey_val
        % 现在计算不确定度并存储
         % 将返回的值存储在对应的数组中
    mean_ex = [mean_ex, ex_val];  % 存储ex的值
    mean_ey = [mean_ey, ey_val];  % 存储ey的值
    mean_Sx = [mean_Sx, Sx_val];  % 存储Sx的值
    mean_Sy = [mean_Sy, Sy_val];  % 存储Sy的值
end
Smean_ex = [];
Smean_ey = [];
Smean_Sx = [];
Smean_Sy = [];
for i = 1:length(Sy_values)
        Sy = Sy_values(i);        
        % 执行仿真计算）
        ex=0;Sx=0;ey=0;%S(mm/100mm) e(mm)
% 创建一个新的图形窗口
Sx_kaikou=Sx*U/100;
Sy_kaikou=Sy*U/100;
%S机M机距离Z，以及S机到联轴器中心距离
ls=150;%S机激光距离
lm=150;%M机PSD到轴的距离
l_length=30;
% 生成圆周上的点
theta = linspace(0, 2*pi, 25);  % 圆周角度范围
 [ex_val, ey_val, Sx_val, Sy_val] = fangzhenMethod(ex,ey,Sx,Sy,theta,ls,lm,l_length,U) ;
 % 假设我们已经得到了计算后的值 ex_val 和 ey_val
        % 现在计算不确定度并存储
         % 将返回的值存储在对应的数组中
    Smean_ex = [Smean_ex, ex_val];  % 存储ex的值
    Smean_ey = [Smean_ey, ey_val];  % 存储ey的值
    Smean_Sx = [Smean_Sx, Sx_val];  % 存储Sx的值
    Smean_Sy = [Smean_Sy, Sy_val];  % 存储Sy的值
end

figure;
% 第一个子图：ex的变化
subplot(2, 2, 1);  % 2行2列的第一个子图
scatter(ey_values, mean_ex, 'r');  % 绘制ex随ey变化的散点图，红色
title('ex随ey变化'); % 设置标题
xlabel('ey'); % X轴标签
ylabel('ex'); % Y轴标签

% 第二个子图：ey的变化
subplot(2, 2, 2);  % 2行2列的第二个子图
scatter(ey_values, mean_ey, 'g');  % 绘制ey随ey变化的散点图，绿色
title('ey随ey变化'); % 设置标题
xlabel('ey'); % X轴标签
ylabel('ey'); % Y轴标签

% 第三个子图：Sx的变化
subplot(2, 2, 3);  % 2行2列的第三个子图
scatter(ey_values, mean_Sx, 'b');  % 绘制Sx随U变化的散点图，蓝色
title('Sx随ey变化'); % 设置标题
xlabel('ey'); % X轴标签
ylabel('Sx'); % Y轴标签

% 第四个子图：Sy的变化
subplot(2, 2, 4);  % 2行2列的第四个子图
scatter(ey_values, mean_Sy, 'm');  % 绘制Sy随U变化的散点图，紫色
title('Sy随ey变化'); % 设置标题
xlabel('ey'); % X轴标签
ylabel('Sy'); % Y轴标签

% 设置总标题
exStr = num2str(ex);
eyStr = num2str(ey);
SxStr = num2str(Sx);
SyStr = num2str(Sy);
sgtitle('仿真坐标代公式计算标准差随不对中量变化,U=1000');
 % 设置整个图形窗口的总标题
%k = 19/25; 
%U = 25;
%maxPoints = 34; 
%result = zeros(100, 5); 
%count = 0;
%
%figure
%scatter(data{:,1}, data{:,2}, [], 'b');
%hold on;
%
%scatter(data{:,4}, data{:,5}, [], 'g');

%legend("S机实测点","M机实测","S机仿真","M机仿真")
%axis equal;
%line([0, 360], [0.01, 0.01], 'linestyle', '--', 'color', 'r');
%line([0, 360], [-0.01, -0.01], 'linestyle', '--', 'color', 'r');

%title("同一根轴任意点法所求不对中量");
%xlabel("横坐标角度（data(i,3)）");
%ylabel("不对中量mm");

figure;
% 第一个子图：ex的变化
subplot(2, 2, 1);  % 2行2列的第一个子图
scatter(Sy_values, 100*abs((Smean_ex)/ex), 'r');  % 绘制ex随U变化的散点图，红色
title('ex随Sy变化'); % 设置标题
xlabel('Sy'); % X轴标签
ylabel('ex'); % Y轴标签
% 设置y轴刻度格式为百分比
ytickformat(gca, '%,.0f');  % 设置y轴为百分比格式

% 第二个子图：ey的变化
subplot(2, 2, 2);  % 2行2列的第二个子图
scatter(Sy_values, 100*abs((Smean_ey)/ey), 'g');  % 绘制ey随U变化的散点图，绿色
title('ey随Sy变化'); % 设置标题
xlabel('Sy'); % X轴标签
ylabel('ey'); % Y轴标签
% 设置y轴刻度格式为百分比
ytickformat(gca, '%,.0f');  % 显示百分比格式（没有小数点）
% 第三个子图：Sx的变化
subplot(2, 2, 3);  % 2行2列的第三个子图
scatter(Sy_values, 100*abs((Smean_Sx)/Sx), 'b');  % 绘制Sx随U变化的散点图，蓝色
title('Sx随Sy变化'); % 设置标题
xlabel('U'); % X轴标签
ylabel('Sx'); % Y轴标签
% 设置y轴刻度格式为百分比
ytickformat(gca, '%,.0f');  % 显示百分比格式（没有小数点）
% 第四个子图：Sy的变化
subplot(2, 2, 4);  % 2行2列的第四个子图
scatter(Sy_values,100*abs((Smean_Sy)/Sy), 'm');  % 绘制Sy随U变化的散点图，紫色
title('Sy随Sy变化'); % 设置标题
xlabel('Sy'); % X轴标签
ylabel('Sy'); % Y轴标签
% 设置y轴刻度格式为百分比
ytickformat(gca, '%,.2f');  % 显示百分比格式（没有小数点）
% 设置总标题
exStr = num2str(ex);
eyStr = num2str(ey);
SxStr = num2str(Sx);
SyStr = num2str(Sy);
sgtitle('仿真坐标代公式计算相对不确定度随安装距离变化,U=1000');
 % 设置整个图形窗口的总标题
%k = 19/25; 
%U = 25;
%maxPoints = 34; 
%result = zeros(100, 5); 
%count = 0;
%
%figure
%scatter(data{:,1}, data{:,2}, [], 'b');
%hold on;
%
%scatter(data{:,4}, data{:,5}, [], 'g');

%legend("S机实测点","M机实测","S机仿真","M机仿真")
%axis equal;
%line([0, 360], [0.01, 0.01], 'linestyle', '--', 'color', 'r');
%line([0, 360], [-0.01, -0.01], 'linestyle', '--', 'color', 'r');

%title("同一根轴任意点法所求不对中量");
%xlabel("横坐标角度（data(i,3)）");
%ylabel("不对中量mm");
hold off;
