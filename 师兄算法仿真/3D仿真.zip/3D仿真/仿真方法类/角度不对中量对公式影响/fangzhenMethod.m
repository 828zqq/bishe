function [ex_val, ey_val, Sx_val, Sy_val]= fangzhenMethod(ex,ey,Sx,Sy,theta,ls,lm,l_length,U) 
%根据输入参数获取仿真坐标，然后求不对中量标准差
%S机M机距离Z，以及S机到联轴器中心距离
% ls S机激光距离
% lm M机PSD到轴的距离
% l_length=30;
% 生成圆周上的点
% theta = linspace(0, 2*pi, 25);   圆周角度范围
addpath('D:\开题\3D仿真\仿真方法类');
addpath('D:\开题\3D仿真\仿真方法类\距离U对公式影响');
mean_ex = [];
mean_ey = [];
mean_Sx = [];
mean_Sy = [];
Z=2*U;
Sx_kaikou=Sx*U/100;
Sy_kaikou=Sy*U/100;
shaft=shaft_Line();
shaft=shaft.build_shaft_3D(ex,ey,Sx_kaikou,Sy_kaikou,U,Z);
%生成S机平面、M机平面圆周点
M_ordered_circle_points=OrderedCirclePoints(shaft.direction_vector_Mzhou,shaft.Mpoint_anzhuang,lm,l_length);
S_ordered_circle_points=OrderedCirclePoints(shaft.direction_vector_Szhou,shaft.Spoint_anzhuang,ls,l_length);
%创建M机S机平面
Mplane=Plane(shaft.direction_vector_Mzhou,shaft.Mpoint_anzhuang);
Splane=Plane(shaft.direction_vector_Szhou,shaft.Spoint_anzhuang);
%构建激光方向向量
%S_M_laser = Vector3D(S_ordered_circle_points.Chang_0point,M_ordered_circle_points.Chang_0point);
%M_S_laser = Vector3D(M_ordered_circle_points.Duan_0point,S_ordered_circle_points.Duan_0point);
S_M_laser = shaft.direction_vector_Szhou;
M_S_laser = -shaft.direction_vector_Mzhou;
%激光与平面交点集合
%M_Lasertrajectory=findIntersection_again(shaft.direction_vector_Szhou,S_M_laser.line,Mplane,theta,S_ordered_circle_points.ordered_circle_points_chang);
%S_Lasertrajectory=findIntersection_again(shaft.direction_vector_Mzhou,M_S_laser.line,Splane,theta,M_ordered_circle_points.ordered_circle_points_duan);
M_Lasertrajectory=findIntersection_again(shaft.direction_vector_Szhou,S_M_laser,Mplane,theta,S_ordered_circle_points.ordered_circle_points_chang);
S_Lasertrajectory=findIntersection_again(shaft.direction_vector_Mzhou,M_S_laser,Splane,theta,M_ordered_circle_points.ordered_circle_points_duan);%下面两行是激光平行于轴线
%坐标系转换到Mpsd和Spsd
M_PSD=M_RelativeCoorTransfer(shaft.direction_vector_Mzhou,M_ordered_circle_points.ordered_circle_points_chang,shaft.Mpoint_anzhuang,theta,M_Lasertrajectory);
S_PSD=S_RelativeCoorTransfer(theta,S_ordered_circle_points.Duan_0point,S_Lasertrajectory);
 % 获取对齐的结果并存储
    [ex_val, ey_val, Sx_val, Sy_val] = anypoints2(S_PSD, M_PSD, theta, U, Z,ex,ey,Sx,Sy);
        