classdef Plane
    %   3维平面的A，B，C，D参数
    properties
        A
        B
        C
        D
    end

    methods
        function obj = Plane(normal,point)
            %输入 向量，point3D
            % 检查输入参数数量
            if nargin ~= 2
                error('Plane:InvalidNumberOfInputs', ...
                    'Exactly two input arguments are required.');
            end
            
            %  获取法向量分量
            obj.A = normal(1);
            obj.B = normal(2);
            obj.C = normal(3);
           % 计算D
           obj.D = -(obj.A * point(1) + obj.B * point(2) + obj.C * point(3));
        end
    end
end