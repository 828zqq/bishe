
%按张老师要求整合图片
function fangzhenyugongshi=shiceyufangzhenduibizhenghetu2(S_PSD,M_PSD,theta,ex,ey,Sx,Sy,U,Z,lm)
% 创建一个新的图形窗口
k=abs((Z-U)/U);
cos_theta = cos(theta);
sin_theta = sin(theta);
xs_fangzhen=S_PSD(:,1);
ys_fangzhen=S_PSD(:,2);
xm_fangzhen=M_PSD(:,1);
ym_fangzhen=M_PSD(:,2);
cos_ty=U/(U^2+Sy^2)^(1/2);
sin_ty=Sy/(U^2+Sy^2)^(1/2);
cos_tx=U/(U^2+Sx^2)^(1/2);
sin_tx=Sx/(U^2+Sx^2)^(1/2);
%Gy=lm*(1-cos_ty)*cos_theta/(cos_ty);
%Gx=lm*(1-cos_tx)*sin_theta/(cos_tx);
Gy=0;Gx=0;
%ys = -ey * cos_theta - ex * sin_theta + (Sy+Gy) * cos_theta + (Sx+Gx) * sin_theta;

%%新版公式
ys = -ey * cos_theta - ex * sin_theta + (Sy+Gy).* cos_theta + (Sx+Gx) .* sin_theta;
xs = ey * sin_theta  - ex * cos_theta - (Sy+Gy) .* sin_theta + (Sx+Gx) .* cos_theta;
ym = ey * cos_theta + ex * sin_theta +  (Sy+Gy).* cos_theta + (Sx+Gx).* sin_theta;
xm= ey * sin_theta - ex * cos_theta +  (Sy+Gy) .* sin_theta -  (Sx+Gx) .* cos_theta;

%老公式
ys_old = -ey * cos_theta - ex * sin_theta + Sy* cos_theta+ Sx* sin_theta;
xs_old = ey * sin_theta  - ex * cos_theta - Sy * sin_theta + Sx * cos_theta;
ym_old = ey * cos_theta + ex * sin_theta +  Sy * cos_theta +  Sx * sin_theta;
xm_old = ey * sin_theta - ex * cos_theta +  Sy * sin_theta -  Sx * cos_theta;
%ys_old = -ey * cos_theta - ex * sin_theta + Sy* cos_theta+ Sx* sin_theta;
%xs_old = ey * sin_theta  - ex * cos_theta - Sy * sin_theta + Sx * cos_theta;
%ym_old = ey * cos_theta + ex * sin_theta +  Sy * cos_theta +  Sx * sin_theta;
%xm_old = ey * sin_theta - ex * cos_theta +  Sy * sin_theta -  Sx * cos_theta;
for i=1:length(theta)
    theta(i)=theta(i)*180/pi;
end
figure;

% 第一个子图
subplot(2, 2, 1);  % 2行2列的第一个子图
scatter(theta, xs_fangzhen-xs_fangzhen(1), 'r');  % 绘制xs_fangzhen的散点图，红色

hold on;  % 保持当前图形，继续绘制其他数据

scatter(theta, xs-xs(1), 'b');  % 绘制xs的散点图
hold on;
scatter(theta, xs_old-xs_old(1), 'k'); 
title('xs仿真与公式对比'); % 设置标题
legend('xs仿真', 'xs新公式','xs老公式');  % 设置图例，标识不同的数据系列

% 第二个子图
subplot(2, 2, 2);  % 2行2列的第二个子图
scatter(theta, xm_fangzhen-xm_fangzhen(01), 'r');  % 绘制xm_fangzhen的散点图，红色
hold on;  % 保持当前图形，继续绘制其他数据
scatter(theta, xm-xm(01), 'b');  % 绘制xm的散点图
hold on;
scatter(theta, xm_old-xm_old(1), 'k'); 
title('xm仿真与公式对比'); % 设置标题
legend('xm仿真', 'xm新公式','xm老公式');  % 设置图例，标识不同的数据系列
% 第三个子图
subplot(2, 2, 3);  % 2行2列的第三个子图
scatter(theta, ys_fangzhen-ys_fangzhen(01), 'r');  % 绘制ys_fangzhen的散点图，蓝色
hold on;  % 保持当前图形，继续绘制其他数据
scatter(theta, ys-ys(01), 'b');  % 绘制ys的散点图
hold on;
scatter(theta, ys_old-ys_old(1), 'k'); 
title('ys仿真与公式对比'); % 设置标题
legend('ys仿真', 'ys新公式','ys老公式');  % 设置图例，标识不同的数据系列

% 第四个子图
subplot(2, 2, 4);  % 2行2列的第四个子图
scatter(theta, ym_fangzhen-ym_fangzhen(01), 'r');  % 绘制ym_fangzhen的散点图，黑色
hold on;  % 保持当前图形，继续绘制其他数据
scatter(theta, ym-ym(01), 'b');  % 绘制ym的散点图
hold on;
scatter(theta, ym_old-ym_old(1), 'k'); 
title('ym仿真与公式对比'); % 设置标题
legend('ym仿真', 'ym新公式','ym老公式');  % 设置图例，标识不同的数据系列

% 设置总标题
exStr = num2str(ex);
eyStr = num2str(ey);
SxStr = num2str(Sx*100/U);
SyStr = num2str(Sy*100/U);
sgtitle(['仿真与公式坐标对比,ex=', exStr, ';ey=', eyStr, ';Sx=', SxStr, ';Sy=', SyStr]);
 % 设置整个图形窗口的总标题
%k = 19/25; 
%U = 25;
%maxPoints = 34; 
%result = zeros(100, 5); 
%count = 0;
%
%figure
%scatter(data{:,1}, data{:,2}, [], 'b');
%hold on;
%
%scatter(data{:,4}, data{:,5}, [], 'g');

%legend("S机实测点","M机实测","S机仿真","M机仿真")
%axis equal;
%line([0, 360], [0.01, 0.01], 'linestyle', '--', 'color', 'r');
%line([0, 360], [-0.01, -0.01], 'linestyle', '--', 'color', 'r');

%title("同一根轴任意点法所求不对中量");
%xlabel("横坐标角度（data(i,3)）");
%ylabel("不对中量mm");
hold off;
fangzhenyugongshi= gcf;
end
