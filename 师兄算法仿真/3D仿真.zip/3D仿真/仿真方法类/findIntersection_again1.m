function laser_trajectory=findIntersection_again1(axis,vector,plane,theta,ordered_circle_points)
           addpath('D:\开题\3D仿真2\仿真方法类');
        % 初始化存储轨迹坐标的矩
           laser_trajectory = [];

           for i = 1:length(theta)
               % 旋转角度 theta(i) 的旋转矩阵 R(v, theta)
               % 1. 旋转 M_S_laser 的起点 P_0
               
               rotated_point_0 = ordered_circle_points(i,:);  % 旋转后的起点
           
               % 2. 旋转 M_S_laser 的方向向量
               p_dir = vector/norm(vector);  % 激光方向向量
               p_dir_rotated = rotate_point(p_dir, axis, theta(i));  % 旋转后的方向向量
           
               % 3. 计算旋转后的激光轨迹的端点
               rotated_end_point = rotated_point_0 + p_dir_rotated;  % 旋转后的激光轨迹单位向量终点
           
               % 计算该旋转直线与平面 Z = -U 的交点
               % 平面方程: z = -U, 直线方程: (x, y, z) = rotated_point_0 + t * (rotated_end_point - rotated_point_0)
               % 将直线方程带入平面方程得到交点 t
               
               denominator = plane.A * (rotated_end_point(1) - rotated_point_0(1)) + plane.B * (rotated_end_point(2) - rotated_point_0(2)) + plane.C * (rotated_end_point(3) - rotated_point_0(3));
               if denominator ~= 0
                     % 根据平面与直线方程计算交点参数 t
                     t = -(plane.A * rotated_point_0(1) + plane.B * rotated_point_0(2) + plane.C * rotated_point_0(3) + plane.D) / denominator;
                     % 利用求得的 t 值计算交点的 x、y、z 坐标
                     intersection_x = rotated_point_0(1) + t * (rotated_end_point(1) - rotated_point_0(1));
                     intersection_y = rotated_point_0(2) + t * (rotated_end_point(2) - rotated_point_0(2));
                     intersection_z = rotated_point_0(3) + t * (rotated_end_point(3) - rotated_point_0(3));
                     intersection_point = [intersection_x, intersection_y, intersection_z]; % 交点坐标
                     % 存储交点轨迹
                     laser_trajectory = [laser_trajectory; intersection_point];
               end
           end

end
function rotated_point = rotate_point(point, axis, angle)
    % 使用 Rodrigues' 旋转公式绕给定轴旋转
    axis = axis / norm(axis);  % 确保方向向量是单位向量
    cos_theta = cos(angle);
    sin_theta = sin(-angle);
    
    % 旋转公式
    rotated_point = point * cos_theta + cross(axis, point) * sin_theta + axis * dot(axis, point) * (1 - cos_theta);
end
