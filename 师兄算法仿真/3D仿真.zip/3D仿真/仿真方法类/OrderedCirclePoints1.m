classdef OrderedCirclePoints1
    % 定义抽象类，用于表示OrderedCirclePoints逻辑的抽象结构
    properties
        Chang_0point
        Duan_0point
        ordered_circle_points_chang
        ordered_circle_points_duan
        
        
    end
    methods 
        % 抽象方法，类似于Python抽象类中的抽象方法，子类必须实现
        function obj= OrderedCirclePoints1(direction_vector_Mzhou,Mpoint_anzhuang,lm,l_length,theta)
             %根据M机的相关参数画出以y值最大时为起点的有序的M机PSD和激光的圆周点坐标
             direction_vector_Mzhou = direction_vector_Mzhou / norm(direction_vector_Mzhou);
             
             
           
                 % 如果参考向量与旋转轴接近平行，换用另一个参考向量
                 reference_vector = [0, 1, 0];
          
             
             % 3. 通过叉积生成第一个正交向量 U1
             U1 = cross(reference_vector,direction_vector_Mzhou);
            % U1 = U1 / norm(U1);  % 单位化
             
             % 4. 通过叉积生成初始点所在向量
             U2 = cross(direction_vector_Mzhou, U1);
             U2 = U2 / norm(U2);  % 单位化
             % 生成圆周上的点
          
             circle_points_chang = Mpoint_anzhuang + (lm+l_length) * U2;
             circle_points_duan = Mpoint_anzhuang + (lm) * U2;
             % 计算 y 坐标的最大值及其索引
             %[~, idx_max_y_chang] = max(circle_points_chang(:, 2));
             %[~, idx_max_y_duan] = max(circle_points_duan(:, 2));
             
             
             % 获取 y 最大值对应的点
             %obj.Chang_0point = circle_points_chang(idx_max_y_chang, :);
             %obj.Duan_0point = circle_points_duan(idx_max_y_duan, :);
             obj.Chang_0point = circle_points_chang(1, :);
             obj.Duan_0point = circle_points_duan(1, :);
             %%%%%%
             
             %旋转MM_PSD_0point 和M_laser_0point
             r = obj.Chang_0point - Mpoint_anzhuang;
             r2= obj.Duan_0point - Mpoint_anzhuang;
             for i = 1:length(theta)
                 % 当前角度
                 angle = theta(i);
                 
                 % 旋转轴的反对称矩阵
                 K2 = [0, -direction_vector_Mzhou(3), direction_vector_Mzhou(2);
                      direction_vector_Mzhou(3), 0, -direction_vector_Mzhou(1);
                      -direction_vector_Mzhou(2), direction_vector_Mzhou(1), 0];
                
                 % 旋转矩阵
                 R = eye(3) + sin(-angle) * K2 + (1 - cos(-angle)) * (K2 * K2);
                 
                 % 旋转后的点（相对于旋转中心）
                 rotated_r = R * r';
                  rotated_r2 = R * r2';
                %rotated_r=rotate_point(r,direction_vector_Mzhou,angle);
                %rotated_r2=rotate_point(r2,direction_vector_Mzhou,angle);
                 % 恢复到全局坐标
                 obj.ordered_circle_points_chang(i, :) = Mpoint_anzhuang + rotated_r';
                 obj.ordered_circle_points_duan(i, :) = Mpoint_anzhuang + rotated_r2';
             end
        end
        %function rotated_point = rotate_point(point, axis, angle)
        %   % 使用 Rodrigues' 旋转公式绕给定轴旋转
        %   axis = axis / norm(axis);  % 确保方向向量是单位向量
        %   cos_theta = cos(angle);
        %   sin_theta = sin(-angle);
        %   
        %   % 旋转公式
        %   rotated_point = point * cos_theta + cross(axis, point) * sin_theta + axis * dot(axis, point) * (1 - cos_theta);
        %end
        
    end
end
