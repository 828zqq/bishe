function laser_trajectory=findIntersection(point,vector,plane,theta,ordered_circle_points)
           addpath('D:\开题\3D仿真\仿真方法类');
        % 初始化存储轨迹坐标的矩阵
           laser_trajectory = [];
           for i = 1:length(theta)
              
                   
               % 旋转角度 theta(i) 的旋转矩阵,z轴顺时针
                    R_z = [cos(theta(i)), sin(theta(i)), 0;
                      -sin(theta(i)), cos(theta(i)), 0;
                      0, 0, 1];
            
                 

          
     
               
               % 旋转后的激光起点和方向向量
               
               %vectorarray=[vector.dx,vector.dy,vector.dz];
               S_laser_0point_rotated = (R_z * point(:))'; % 转置为行向量
               S_M_laser_rotated = (R_z * vector(:))'; % 转置为行向量
               
               
               
                % 计算平面交点
               % 激光路径参数方程 P(λ) = S_laser_0point_rotated + λ * S_M_laser_rotated
               % 将 P(λ) 代入平面方程 Ax + By + Cz + D = 0 求解 λ
               numerator = -(plane.A* S_laser_0point_rotated(1) + plane.B * S_laser_0point_rotated(2) + plane.C * S_laser_0point_rotated(3) + plane.D);
               denominator = plane.A * S_M_laser_rotated(1) + plane.B * S_M_laser_rotated(2) + plane.C * S_M_laser_rotated(3);
               
               if denominator ~= 0
                   % 计算交点参数 λ
                   lambda = numerator / denominator;
                   
                   % 计算交点坐标
                   P_intersect = S_laser_0point_rotated + lambda * S_M_laser_rotated;
                   
                   % 将交点添加到轨迹矩阵
                   laser_trajectory = [laser_trajectory; P_intersect];
              end
           end
           laser_trajectory_S = [];

           for i = 1:length(theta)
               % 旋转角度 theta(i) 的旋转矩阵 R(v, theta)
               % 1. 旋转 M_S_laser 的起点 P_0
               
               rotated_point_0 = ordered_circle_points_MLD(i,:);  % 旋转后的起点
           
               % 2. 旋转 M_S_laser 的方向向量
               p_dir = M_S_laser/norm(M_S_laser);  % 激光方向向量
               p_dir_rotated = rotate_point(p_dir, direction_vector_Mzhou, theta(i));  % 旋转后的方向向量
           
               % 3. 计算旋转后的激光轨迹的端点
               rotated_end_point = rotated_point_0 + p_dir_rotated;  % 旋转后的激光轨迹单位向量终点
           
               % 计算该旋转直线与平面 Z = -U 的交点
               % 平面方程: z = -U, 直线方程: (x, y, z) = rotated_point_0 + t * (rotated_end_point - rotated_point_0)
               % 将直线方程带入平面方程得到交点 t
               
               t = -(A * rotated_point_0(1) + B * rotated_point_0(2) + C * rotated_point_0(3) + D) / denominator;
            % 利用求得的 t 值计算交点的 x、y、z 坐标
               intersection_x = rotated_point_0(1) + t * (rotated_end_point(1) - rotated_point_0(1));
               intersection_y = rotated_point_0(2) + t * (rotated_end_point(2) - rotated_point_0(2));
               intersection_z = rotated_point_0(3) + t * (rotated_end_point(3) - rotated_point_0(3));
               intersection_point = [intersection_x, intersection_y, intersection_z]; % 交点坐标
               % 存储交点轨迹
               laser_trajectory = [laser_trajectory_S; intersection_point];
           end

end
function rotated_point = rotate_point(point, axis, angle)
    % 使用 Rodrigues' 旋转公式绕给定轴旋转
    axis = axis / norm(axis);  % 确保方向向量是单位向量
    cos_theta = cos(angle);
    sin_theta = sin(-angle);
    
    % 旋转公式
    rotated_point = point * cos_theta + cross(axis, point) * sin_theta + axis * dot(axis, point) * (1 - cos_theta);
end
