function fangzhenyugongshiguiji=gongshiyufangzhenduibiguijitu2(S_PSD,M_PSD,theta,ex,ey,Sx,Sy,U,Z,lm)
% 创建一个新的图形窗口
k=abs((Z-U)/U);
cos_theta = cos(theta);
sin_theta = sin(theta);
%xs_fangzhen=S_PSD(:,1);
%ys_fangzhen=S_PSD(:,2);
%xm_fangzhen=M_PSD(:,1);
%ym_fangzhen=M_PSD(:,2);
cos_ty=U/(U^2+Sy^2)^(1/2);
%sin_ty=Sy/(U^2+Sy^2)^(1/2);
cos_tx=U/(U^2+Sx^2)^(1/2);
%sin_tx=Sx/(U^2+Sx^2)^(1/2);
Gy=lm*(1-cos_ty)*sin_theta/(cos_ty);
Gx=lm*(1-cos_tx)*sin_theta/(cos_tx);
%ys = -ey * cos_theta - ex * sin_theta + (Sy+Gy) * cos_theta + (Sx+Gx) * sin_theta;

%%新版公式
ys = -ey * cos_theta - ex * sin_theta + (Sy+Gy).* cos_theta + (Sx+Gx) .* sin_theta;
xs = ey * sin_theta  - ex * cos_theta - (Sy+Gy) .* sin_theta + (Sx+Gx) .* cos_theta;
ym = ey * cos_theta + ex * sin_theta +  (Sy+Gy).* cos_theta + (Sx+Gx).* sin_theta;
xm= ey * sin_theta - ex * cos_theta +  (Sy+Gy) .* sin_theta -  (Sx+Gx) .* cos_theta;


%老公式
%ys_old = -ey * cos_theta - ex * sin_theta + Sy* cos_theta+ Sx* sin_theta;
%xs_old = ey * sin_theta  - ex * cos_theta - Sy * sin_theta + Sx * cos_theta;
%ym_old = ey * cos_theta + ex * sin_theta +  Sy * cos_theta +  Sx * sin_theta;
%xm_old = ey * sin_theta - ex * cos_theta +  Sy * sin_theta -  Sx * cos_theta;


for i=1:length(theta)
    theta(i)=theta(i)*180/pi;
end
% 椭圆拟合并求圆心
    [S_center, S_axes] = fit_ellipse(S_PSD(:, 1), S_PSD(:, 2));
    [M_center, M_axes] = fit_ellipse(M_PSD(:, 1), M_PSD(:, 2));

    % 打印圆心
    fprintf('S_PSD 圆心: (%.4f, %.4f)\n', S_center(1), S_center(2));
    fprintf('M_PSD 圆心: (%.4f, %.4f)\n', M_center(1), M_center(2));

    ex_temp=(M_center(1)+S_center(1))/2;
    ey_temp=(S_center(2)-M_center(2))/2;
    fprintf('ex: (%.4f)\n', ex_temp);
    fprintf('ey: (%.4f)\n', ey_temp);
    fprintf('S_PSD 圆心修正: (%.4f, %.4f)\n', S_center(1)-ex_temp, S_center(2)-ey_temp);
    fprintf('M_PSD 圆心修正: (%.4f, %.4f)\n', M_center(1)-ex_temp, M_center(2)+ey_temp);
    fprintf('Sx: (%.4f)\n', (M_center(1)-S_center(1))*100/(2*U));
    fprintf('Sy: (%.4f)\n', -1*(M_center(2)+S_center(2))*100/(2*U));
figure;
plot(S_PSD(1:length(theta), 1), S_PSD(1:length(theta), 2),'b-s','DisplayName','S_PSD');
%plot(S_PSD(1:length(theta), 1)-S_PSD(1, 1), S_PSD(1:length(theta), 2)-S_PSD(1, 2),'b-s','DisplayName','S_PSD');
%hold on;
%plot(xs-xs(1),ys-ys(1),'k-s','DisplayName','S_PSD_公式');
%plot(xs,ys,'k-s','DisplayName','S_PSD_公式');
%绘制第二个坐标图，例如用蓝色
hold on; % 保持当前图形，以便在上面继续绘制
plot(M_PSD(1:length(theta), 1), M_PSD(1:length(theta), 2),'r-o','DisplayName','M_PSD');
%plot(M_PSD(1:length(theta), 1)-M_PSD(1, 1), M_PSD(1:length(theta), 2)-M_PSD(1, 2),'r-o','DisplayName','M_PSD');
%hold on;
%plot(xm-xm(1),ym-ym(01),'g-o','DisplayName','M_PSD_公式');
%plot(xm,ym,'g-o','DisplayName','M_PSD_公式');

% 设置总标题
exStr = num2str(ex);
eyStr = num2str(ey);
SxStr = num2str(Sx*100/U);
SyStr = num2str(Sy*100/U);
sgtitle(['仿真与公式轨迹对比,ex=', exStr, ';ey=', eyStr, ';Sx=', SxStr, ';Sy=', SyStr]);
 % 设置整个图形窗口的总标题
%k = 19/25; 
%U = 25;
%maxPoints = 34; 
%result = zeros(100, 5); 
%count = 0;
%
%figure
%scatter(data{:,1}, data{:,2}, [], 'b');
%hold on;
%
%scatter(data{:,4}, data{:,5}, [], 'g');

legend("S机仿真","S机公式","M机仿真","M机公式")
axis equal;
%line([0, 360], [0.01, 0.01], 'linestyle', '--', 'color', 'r');
%line([0, 360], [-0.01, -0.01], 'linestyle', '--', 'color', 'r');

%title("同一根轴任意点法所求不对中量");
%xlabel("横坐标角度（data(i,3)）");
%ylabel("不对中量mm");
hold off;
fangzhenyugongshiguiji= gcf;
end
function [center, axes] = fit_ellipse(x, y)
    % 使用最小二乘法拟合椭圆
    A = [x.^2, x.*y, y.^2, x, y];
    b = -ones(size(x));
    params = A \ b;

    % 提取椭圆参数
    A = params(1);
    B = params(2);
    C = params(3);
    D = params(4);
    E = params(5);

    % 计算圆心
    center_x = (B * E - 2 * C * D) / (4 * A * C - B^2);
    center_y = (B * D - 2 * A * E) / (4 * A * C - B^2);
    center = [center_x, center_y];

    % 计算椭圆的长轴和短轴
    numerator = 2 * (A * E^2 + C * D^2 - B * D * E + (B^2 - 4 * A * C));
    denominator1 = (B^2 - 4 * A * C) * ((C - A) + sqrt((A - C)^2 + B^2));
    denominator2 = (B^2 - 4 * A * C) * ((A - C) + sqrt((A - C)^2 + B^2));
    axes = [sqrt(abs(numerator / denominator1)), sqrt(abs(numerator / denominator2))];
end
