function [k_fit, h_fit, a_fit, b_fit, phi_fit, theta_fit, r_fit, is_optimal] = fit_model_points_new_biangongshi(alpha, y_data, x_data, plot_results, x, y)
    % FIT_MODEL 拟合给定的模型
    %
    % 输入参数：
    %   alpha: 数据点的 alpha 值（列向量）
    %   y_data: 数据点的 y 值（列向量）
    %   x_data: 数据点的 x 值（列向量）
    %   plot_results: 是否绘制拟合结果（true/false）
    %   x, y: 用于可视化的数据点
    %
    % 输出参数：
    %   k_fit, h_fit, a_fit, b_fit, phi_fit, theta_fit, r_fit: 拟合后的参数值
    %   is_optimal: 是否为最优解（true/false）

    % 参数设置
    threshold = 0.001; % 残差/样本数的阈值
    num_restarts = 50; % 多起点优化的重启次数

    % 定义目标函数（最小化残差平方和）
    model_y = @(params, alpha) params(1) + params(3) * sin(params(5) + alpha) * sin(params(6)) + params(4) * cos(params(5) + alpha) * cos(params(6)) - params(7) * cos(alpha);
    model_x = @(params, alpha) params(2) + params(3) * sin(params(5) + alpha) * cos(params(6)) - params(4) * cos(params(5) + alpha) * sin(params(6)) - params(7) * sin(alpha);
    objective = @(params) sum((model_y(params, alpha) - y_data).^2) + sum((model_x(params, alpha) - x_data).^2);

    % 定义约束条件
    constraint1 = @(params) params(1) + params(3) * sin(params(5)) * sin(params(6)) + params(4) * cos(params(5)) * cos(params(6)) - params(7);
    constraint2 = @(params) params(2) + params(3) * sin(params(5)) * cos(params(6)) - params(4) * cos(params(5)) * sin(params(6));

    % 假设 alpha, x_data 和 y_data 已经定义，并且至少包含一个元素。
% 使用 alpha(1) 来表示第一个角度的数据点

% 修改后的约束条件，使得模型在 alpha(1) 角度下必须经过 (x_data(1), y_data(1))
% constraint1 = @(params) params(1) + params(3) * sin(params(5) + alpha(1)) * sin(params(6)) + params(4) * cos(params(5) + alpha(1)) * cos(params(6)) - params(7)* cos(alpha(1)) - y_data(1);
% constraint2 = @(params) params(2) + params(3) * sin(params(5) + alpha(1)) * cos(params(6)) - params(4) * cos(params(5) + alpha(1)) * sin(params(6)) - params(7) * sin(alpha(1))- x_data(1);

    % 参数范围


    % 多起点优化
    best_params = [];
    best_residual = Inf;

    for i = 1:num_restarts
        % 随机生成初始点
        initial_guess = rand(1, 7) .* [2, 1, 120, 120, pi, pi, 120]; % 随机范围可根据问题调整

        % 参数范围（7 个参数）
        lb = [-Inf, -Inf, 0, 0, 0, 0, 300]; % 下界
        ub = [Inf, Inf, Inf, Inf, 2*pi, 2*pi, Inf];  % 上界
        % 使用 fmincon 进行优化
        options = optimoptions('fmincon', 'Display', 'off', 'Algorithm', 'SQP');
        fitted_params = fmincon(objective, initial_guess, [], [], [], [],lb,ub , @(params) deal([], [constraint1(params); constraint2(params)]), options);
            % fitted_params = fmincon(objective, initial_guess, [], [], [], [],lb,ub , @(params) deal([], []), options);

        % 计算残差
        residual = objective(fitted_params);

        % 更新最优解
        if residual < best_residual
            best_params = fitted_params;
            best_residual = residual;
        end
    end

    % 计算残差/样本数
    sample_size = length(alpha);
    residual_per_sample = best_residual / sample_size;

    % 判断是否为最优解
    is_optimal = residual_per_sample < threshold;
    if ~is_optimal
        warning('拟合结果可能不是最优解，残差/样本数 = %.4f', residual_per_sample);
    end

    % 提取拟合结果
    k_fit = best_params(1);
    h_fit = best_params(2);
    a_fit = best_params(3);
    b_fit = best_params(4);
    phi_fit = best_params(5);
    theta_fit = best_params(6);
    r_fit = best_params(7);
%这里根据画图需要，暂时省略
    % 输出拟合结果
    %disp('拟合结果:');
    disp(['k = ', num2str(k_fit)]);
    disp(['h = ', num2str(h_fit)]);
    disp(['a = ', num2str(a_fit)]);
    disp(['b = ', num2str(b_fit)]);
    disp(['phi = ', num2str(phi_fit)]);
    disp(['theta = ', num2str(theta_fit)]);
    disp(['r = ', num2str(r_fit)]);
    disp(['残差/样本数 = ', num2str(residual_per_sample)]);
    disp(['是否为最优解: ', num2str(is_optimal)]);
%
    %% 绘制拟合结果
    if plot_results
        figure;
        plot(x, y, 'ro', 'DisplayName', '输入点'); hold on;
        plot(h_fit, k_fit, 'bx', 'MarkerSize', 10, 'LineWidth', 2, 'DisplayName', '拟合圆心');

        % 绘制拟合椭圆
        phi = linspace(0, 2*pi, 100);
        x_ellipse = h_fit + a_fit * sin(phi_fit + phi) * cos(theta_fit) - b_fit * cos(phi_fit + phi) * sin(theta_fit)-r_fit*sin(phi);
        y_ellipse = k_fit + a_fit * sin(phi_fit + phi) * sin(theta_fit) + b_fit * cos(phi_fit + phi) * cos(theta_fit)-r_fit*cos(phi);
        plot(x_ellipse, y_ellipse, 'b-', 'DisplayName', '拟合椭圆');

        % 设置图形属性
        axis equal;
        legend;
        title('结合几何角度的椭圆拟合');
        xlabel('x');
        ylabel('y');
        grid on;

        % 绘制拟合曲线
        alpha_fit = linspace(min(alpha), max(alpha), 100);
        y_fit = model_y(best_params, alpha_fit);
        x_fit = model_x(best_params, alpha_fit);

        figure;
        subplot(2, 1, 1);
        plot(alpha, y_data, 'bo', 'DisplayName', '数据点 (y)');
        hold on;
        plot(alpha_fit, y_fit, 'r-', 'DisplayName', '拟合曲线 (y)');
        xlabel('\alpha');
        ylabel('y');
        legend;
        title('y(\alpha) 拟合结果');
        grid on;

        subplot(2, 1, 2);
        plot(alpha, x_data, 'bo', 'DisplayName', '数据点 (x)');
        hold on;
        plot(alpha_fit, x_fit, 'r-', 'DisplayName', '拟合曲线 (x)');
        xlabel('\alpha');
        ylabel('x');
        legend;
        title('x(\alpha) 拟合结果');
        grid on;
    end
end