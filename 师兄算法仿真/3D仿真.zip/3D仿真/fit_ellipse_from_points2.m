function fit_ellipse = fit_ellipse_from_points2(points, alpha)
    % 提取坐标和角度
    x = points(:, 1);
    y = points(:, 2);
    alpha_deg = alpha(:);
    
    % 初始猜测参数: [h, k, a, b, theta]
    initial_h = mean(x);
    initial_k = mean(y);
    initial_a = (max(x) - min(x)) / 2;
    initial_b = (max(y) - min(y)) / 2;
    initial_theta = 0;
    params0 = [initial_h, initial_k, initial_a, initial_b, initial_theta];
    
    % 非线性最小二乘优化
    options = optimoptions('lsqnonlin', 'Display', 'iter', 'Algorithm', 'levenberg-marquardt');
    params = lsqnonlin(@(p) error_func(p, x, y, alpha_deg), params0, [], [], options);
    
    % 提取优化后的参数
    h = params(1);
    k = params(2);
    a = params(3);
    b = params(4);
    theta = params(5); % 椭圆的旋转角度（逆时针从x轴计算）
    
    % 输出结果
    fprintf('椭圆中心: (%.4f, %.4f)\n', h, k);
    fprintf('长轴: %.4f, 短轴: %.4f\n', a, b);
    fprintf('旋转角度 (逆时针从x轴): %.4f°\n', rad2deg(theta));
    
    % 绘制结果
    figure;
    plot(x, y, 'ro', 'DisplayName', '输入点'); hold on;
    plot(h, k, 'bx', 'MarkerSize', 10, 'LineWidth', 2, 'DisplayName', '拟合椭圆中心');
    
    % 绘制拟合椭圆
    t = linspace(0, 2*pi, 100);
    x_ellipse = h + a * sin(t) * cos(theta) + b * cos(t) * sin(theta);
    y_ellipse = k - a * sin(t) * sin(theta) + b * cos(t) * cos(theta);
    plot(x_ellipse, y_ellipse, 'b-', 'DisplayName', '拟合椭圆');
    
    % 设置图形属性
    axis equal;
    legend;
    title('结合几何角度的椭圆拟合');
    xlabel('x');
    ylabel('y');
    grid on;
    
    % 返回椭圆中心
    yuanxin = [h, k];
    fit_ellipse = yuanxin;
end

% 误差函数（坐标误差 + 角度误差）
function err = error_func(params, x, y, alpha_deg)
    h = params(1);
    k = params(2);
    a = params(3);
    b = params(4);
    theta = params(5);
    
    % 坐标误差：点到椭圆的代数距离
    dx = x - h;
    dy = y - k;
    costheta = cos(theta);
    sintheta = sin(theta);
    x_rot = dx * costheta + dy * sintheta;
    y_rot = -dx * sintheta + dy * costheta;
    coord_err = (x_rot.^2 / a^2 + y_rot.^2 / b^2 - 1).^2;
    
    % 角度误差：理论角度与实际角度的偏差
    alpha_rad = deg2rad(alpha_deg);
    phi = alpha_rad; % 几何角度转换为参数角度
    x_fit = h + a * sin(phi) * cos(theta) + b * cos(phi) * sin(theta);
    y_fit = k - a * sin(phi) * sin(theta) + b * cos(phi) * cos(theta);
    angle_err = (x - x_fit).^2 + (y - y_fit).^2;
    
    % 总误差（权重可根据需求调整）
    err = coord_err + 0*angle_err; % 这里可以根据需要调整误差的权重
end
