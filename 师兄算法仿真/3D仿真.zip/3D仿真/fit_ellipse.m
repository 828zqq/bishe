function [a, b, theta, h, k] = fit_ellipse(x_data, y_data, t_data)
    % 输入：
    % x_data    - x 坐标数据点 (n x 1)
    % y_data    - y 坐标数据点 (n x 1)
    % t_data    - 参数角度 t 数据点 (n x 1)
    % 
    % 输出：
    % a         - 长轴半径
    % b         - 短轴半径
    % theta     - 旋转角度 (单位: 弧度)
    % h         - 圆心 x 坐标
    % k         - 圆心 y 坐标

    % 定义拟合函数，椭圆的参数方程，t 变为 t - pi/2
    ellipse_model = @(params, t) ...
        params(4) + params(1) * sin(t) * cos(params(3)) + params(2) * cos(t) * sin(params(3));  % x(t)
    ellipse_model_y = @(params, t) ...
        params(5) - params(1) * sin(t) * sin(params(3)) + params(2) * cos(t) * cos(params(3));  % y(t)

    % 初始参数猜测 [a, b, theta, h, k]
    params_init = [10, 10, pi/4, 0, 0];  % 初始猜测：a, b, theta, h, k

    % 定义参数的上下界
    lb = [-Inf, -Inf, -2*pi, -Inf, -Inf];  % a, b > 0; theta 无限制; h, k 可为负
    ub = [Inf, Inf, 2*pi, Inf, Inf];  % a, b 无上限; theta 在 [-pi, pi] 范围内; h, k 可为正

    % 最小二乘法拟合
    options = optimset('Display', 'off');
    params_fit = lsqcurvefit(@(params, t) [ellipse_model(params, t), ellipse_model_y(params, t)], ...
                             params_init, t_data, [x_data, y_data],lb, ub, options );

    % 提取拟合结果
    a = params_fit(1);  % 长轴半径
    b = params_fit(2);  % 短轴半径
    a=abs(a);b=abs(b);
    theta = params_fit(3);  % 旋转角度
    h = params_fit(4);  % 圆心 x 坐标
    k = params_fit(5);  % 圆心 y 坐标
    fprintf('椭圆的参数：\n');
    fprintf('长轴半径 a = %.2f\n', a);
    fprintf('短轴半径 b = %.2f\n', b);
    fprintf('旋转角度 theta = %.2f rad (%.2f 度)\n', theta, rad2deg(theta));
    fprintf('圆心坐标 h = %.2f, k = %.2f\n', h, k);
    t = linspace(0, 2*pi, 100);  % 用于绘制椭圆的参数 t
    x_sfit = h + a * sin(t) * cos(theta) + b * cos(t) * sin(theta);
    y_sfit = k - a * sin(t) * sin(theta) + b * cos(t) * cos(theta);
    figure;
    plot(x_data, y_data, 'ro', 'MarkerFaceColor', 'r');  % 原始数据点
    hold on;
    plot(x_sfit, y_sfit, 'b-', 'LineWidth', 2);  % 拟合椭圆
    axis equal;
    title('椭圆拟合');
    xlabel('X');
    ylabel('Y');
    legend('原始数据点', '拟合椭圆');


end
