function [k_fit, h_fit, r1_fit, phi_fit, is_optimal] = fit_model_new_circles(alpha, y_data, x_data, plot_results, x, y)
    % FIT_MODEL 拟合新模型（修改后版本，仅使用r1）
    % 修改后的参数：k, h, r1, phi（共4个参数）

    % 参数设置
    threshold = 0.001;
    num_restarts = 50;

    % 定义新目标函数（r2已被移除）
    model_y = @(params, alpha) params(1) + params(3)*sin(params(4) + alpha) - params(3)*sin(alpha);  % r1替换原r2
    model_x = @(params, alpha) params(2) + params(3)*cos(params(4) + alpha) - params(3)*cos(-alpha);  % r1替换原r2
    objective = @(params) sum((model_y(params, alpha) - y_data).^2) + sum((model_x(params, alpha) - x_data).^2);

    % 参数范围（4个参数：k, h, r1, phi）
    lb = [-Inf, -Inf, 0, -2*pi];   % 移除r2约束
    ub = [Inf, Inf, Inf, 2*pi]; 

    % 多起点优化
    best_params = [];
    best_residual = Inf;

    for i = 1:num_restarts
        % 生成初始猜测（参数数量减少到4个）
        initial_guess = rand(1,4) .* [2, 1, 120, pi];  % 移除r2初始化
        
        % 使用fmincon优化
        options = optimoptions('fmincon', 'Display', 'off', 'Algorithm', 'interior-point');
        fitted_params = fmincon(objective, initial_guess, [], [], [], [], lb, ub, [], options);
        
        % 更新最优解
        if objective(fitted_params) < best_residual
            best_params = fitted_params;
            best_residual = objective(fitted_params);
        end
    end

    % 结果评估
    sample_size = length(alpha);
    residual_per_sample = best_residual / sample_size;
    is_optimal = residual_per_sample < threshold;

    % 提取参数（参数索引已调整）
    k_fit = best_params(1);
    h_fit = best_params(2);
    r1_fit = best_params(3);
    phi_fit = best_params(4);

    % 输出警告
    if ~is_optimal
        warning('残差/样本数=%.4f，建议增加重启次数或检查数据', residual_per_sample);
    end
end