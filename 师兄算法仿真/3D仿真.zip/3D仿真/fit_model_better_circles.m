function [k_fit, h_fit, r1_fit, r2_fit, phi_fit, is_optimal] = fit_model_new_circles(alpha, y_data, x_data, plot_results, x, y)
    % FIT_MODEL 拟合新模型
    % 修改后的参数：k, h, r1, r2, phi（共5个参数）
    
    % 参数设置
    threshold = 0.001;
    num_restarts = 20;
    
    % 定义新目标函数（x和y方向残差平方和）
    model_y = @(params, alpha) params(1) + params(3)*cos(params(5) + alpha) - params(4)*cos(-alpha); % 新公式
    model_x = @(params, alpha) params(2) + params(3)*sin(params(5) + alpha) + params(4)*sin(-alpha);  % 新公式
    objective = @(params) sum((model_y(params, alpha) - y_data).^2) + sum((model_x(params, alpha) - x_data).^2);

    % 参数范围（5个参数：k, h, r1, r2, phi）
    lb = [-Inf, -Inf, 0, 0, -2*pi];  % r1/r2需非负
    ub = [Inf, Inf, Inf, Inf, 2*pi]; 
    
    % 多起点优化
    best_params = [];
    best_residual = Inf;
    
    for i = 1:num_restarts
        % 生成初始猜测（参数数量减少到5个）
        initial_guess = rand(1,5) .* [2, 1, 120, 120, pi]; 
        
        % 使用fmincon优化（网页的数值求解方法）
        options = optimoptions('fmincon', 'Display', 'off', 'Algorithm', 'interior-point');
        fitted_params = fmincon(objective, initial_guess, [], [], [], [], lb, ub, [], options);
        
        % 更新最优解
        if objective(fitted_params) < best_residual
            best_params = fitted_params;
            best_residual = objective(fitted_params);
        end
    end
    
    % 结果评估
    sample_size = length(alpha);
    residual_per_sample = best_residual / sample_size;
    is_optimal = residual_per_sample < threshold;
    
    % 提取参数（参数索引已调整）
    k_fit = best_params(1);
    h_fit = best_params(2);
    r1_fit = best_params(3);
    r2_fit = best_params(4);
    phi_fit = best_params(5);
    
    % 输出警告（如非最优）
    if ~is_optimal
        warning('残差/样本数=%.4f，建议增加重启次数或检查数据', residual_per_sample);
    end
end