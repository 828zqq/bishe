clc;clear;


% 输入点的坐标和角度（单位：度）
points = [0,0,0;-0.62,1.38, 249.8;   % 点1，r=5，θ=30度
0.17, 0.79, 120;   % 点2，r=4，θ=120度
-1.54,1.85, 200];  
% 输入点的坐标和角度（单位：度）


% 提取 x, y 坐标和角度信息
x = points(:, 1);
y = points(:, 2);
theta_deg = points(:, 3);  % 角度，单位：度

% 将角度从原始坐标系（从 y 轴开始）转换为标准极坐标系（从 x 轴开始）
theta_deg_prime = 90 - theta_deg;  % 转换后的角度，单位：度
theta_rad = deg2rad(theta_deg_prime);  % 转换为弧度

% 计算每个点的极坐标（r）并绘制
r = sqrt(x.^2 + y.^2);  % 计算每个点到原点的距离

% 使用极坐标和转换后的角度重新计算点的位置（这一步用于确认坐标是否准确）
x_calculated = r .* cos(theta_rad);
y_calculated = r .* sin(theta_rad);

% 可视化原始点与计算的点
figure;
hold on;
plot(x, y, 'ro');  % 原始点
plot(x_calculated, y_calculated, 'bo');  % 重新计算的点
axis equal;
grid on;
title('原始数据点和极坐标转换后的点');

% 使用最小二乘法拟合椭圆
% 标准形式: Ax^2 + By^2 + Cxy + Dx + Ey + F = 0
% 设定设计矩阵 X
X = [x.^2, y.^2, x.*y, x, y, ones(length(x), 1)];

% 最小二乘法拟合
params = X \ -ones(length(x), 1);  % 求解拟合参数

% 提取拟合的椭圆参数
A = params(1);
B = params(3);
C = params(2);
D = params(4);
E = params(5);
F = params(6);

% 计算椭圆的圆心 (x_0, y_0)
denominator = 4 * A * C - B^2;  % 公共分母

% 圆心坐标
x_center = (B * E - 2 * C * D) / denominator;
y_center = (B * D - 2 * A * E) / denominator;

% 输出圆心位置
disp('椭圆的圆心坐标：');
disp(['x_center = ', num2str(x_center)]);
disp(['y_center = ', num2str(y_center)]);

% 计算椭圆的旋转角度
theta_0 = 0.5 * atan2(B, A - C);  % 旋转角度

% 计算椭圆的长轴和短轴
% 计算判别式
discriminant = (B^2 - 4 * A * C);
if discriminant > 0
    % 长轴和短轴计算
    term1 = -2 * (A * F + C * E + B * D);
    term2 = sqrt(discriminant^2 - 4 * (A^2 + C^2) * (A * F - D * C + E * B));
    
    % 长轴和短轴的计算
    semi_major_axis = sqrt(abs(term1 + term2) / (discriminant));
    semi_minor_axis = sqrt(abs(term1 - term2) / (discriminant));
else
    semi_major_axis = 0;  % 不是有效的椭圆
    semi_minor_axis = 0;
end

disp(['椭圆长轴：', num2str(semi_major_axis)]);
disp(['椭圆短轴：', num2str(semi_minor_axis)]);
disp(['椭圆旋转角度：', num2str(rad2deg(theta_0))]);

% 可视化拟合椭圆和原始点
figure;
hold on;
plot(x, y, 'ro');   % 原始点

% 绘制椭圆
theta = linspace(0, 2*pi, 100);
ellipse_x = semi_major_axis * cos(theta);  % 长轴
ellipse_y = semi_minor_axis * sin(theta);  % 短轴

% 旋转矩阵
rotation_matrix = [cos(theta_0), -sin(theta_0); sin(theta_0), cos(theta_0)];
ellipse_points = rotation_matrix * [ellipse_x; ellipse_y];  % 旋转椭圆

% 平移椭圆到圆心位置
ellipse_x_rot = ellipse_points(1, :) + x_center;
ellipse_y_rot = ellipse_points(2, :) + y_center;

plot(ellipse_x_rot, ellipse_y_rot, 'b');  % 拟合的椭圆
axis equal;
grid on;
title('椭圆拟合和圆心位置');
