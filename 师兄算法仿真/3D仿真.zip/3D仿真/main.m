clc;clear;
addpath('D:\开题\3D仿真\仿真方法类');
addpath('D:\开题\3D仿真');
% table_data = readtable('super0407.xlsx');
%输入变量

U=100;
Z=2*U;
ex=1;ey=0.6;Sx=1.1;Sy=0.7;%S(mm/100mm) e(mm)
Sx_kaikou=Sx*U/100;
Sy_kaikou=Sy*U/100;
%S机M机距离Z，以及S机到联轴器中心距离
ls=150;%S机激光距离
lm=150;%M机PSD到轴的距离
l_length=30;

% 生成圆周上的点
theta = linspace(0, 360, 361);  % 圆周角度范围
theta=theta*pi/180;
shaft=shaft_Line2();
shaft=shaft.build_shaft_3D2(ex,ey,Sx_kaikou,Sy_kaikou,U,Z);
%生成S机平面、M机平面圆周点
M_ordered_circle_points=OrderedCirclePoints1(shaft.direction_vector_Mzhou,shaft.Mpoint_anzhuang,lm,l_length,theta);
S_ordered_circle_points=OrderedCirclePoints1(shaft.direction_vector_Szhou,shaft.Spoint_anzhuang,ls,l_length,theta);
%创建M机S机平面
Mplane=Plane(shaft.direction_vector_Mzhou,shaft.Mpoint_anzhuang);
Splane=Plane(shaft.direction_vector_Szhou,shaft.Spoint_anzhuang);

%平面发生偏斜：
%Mplane=rotateByEulerAngles(M_ordered_circle_points,shaft.Mpoint_anzhuang,obj,0,02*pi/180,0,02*pi/180, 0);
%Splane=rotateByEulerAngles(S_ordered_circle_points,shaft.Spoint_anzhuang,obj,0,02*pi/180,0,02*pi/180, 0);
%Mplane_shaft=[Mplane.A,Mplane.B,Mplane.C];

%构建激光方向向量
S_M_laser = Vector3D(S_ordered_circle_points.Chang_0point,M_ordered_circle_points.Chang_0point).line;
M_S_laser = Vector3D(M_ordered_circle_points.Duan_0point,S_ordered_circle_points.Duan_0point).line;
%S_M_laser = shaft.direction_vector_Szhou;
%M_S_laser = -shaft.direction_vector_Mzhou;
%%激光发生偏斜
%S_M_laser = VrotateByEulerAngles(S_ordered_circle_points.Chang_0point,shaft.Spoint_anzhuang,0,0*pi/180,0*pi/180,Splane);
%M_S_laser = VrotateByEulerAngles(M_ordered_circle_points.Duan_0point,shaft.Mpoint_anzhuang,0,0*pi/180,0*pi/180,Mplane);
%激光与平面交点集合
%M_Lasertrajectory=findIntersection_again1(shaft.direction_vector_Szhou,S_M_laser.line,Mplane,theta,S_ordered_circle_points.ordered_circle_points_chang);
%S_Lasertrajectory=findIntersection_again1(shaft.direction_vector_Mzhou,M_S_laser.line,Splane,theta,M_ordered_circle_points.ordered_circle_points_duan);
M_Lasertrajectory=findIntersection_again1(shaft.direction_vector_Szhou,S_M_laser,Mplane,theta,S_ordered_circle_points.ordered_circle_points_chang);
S_Lasertrajectory=findIntersection_again1(shaft.direction_vector_Mzhou,M_S_laser,Splane,theta,M_ordered_circle_points.ordered_circle_points_duan);%下面两行是激光平行于轴线
%坐标系转换到Mpsd和Spsd
M_PSD=M_RelativeCoorTransfer(shaft.direction_vector_Mzhou,M_ordered_circle_points.ordered_circle_points_chang,shaft.Mpoint_anzhuang,theta,M_Lasertrajectory);
S_PSD=S_RelativeCoorTransfer(theta,S_ordered_circle_points.Duan_0point,S_Lasertrajectory);
%将坐标代入到不对中量计算函数
%mean_alignment=anypoints(S_PSD,M_PSD,theta,U,Z);
%对比仿真和公式坐标轨迹
%fangzhengongshiduibi=shiceyufangzhenduibizhenghetu3(S_PSD,M_PSD,theta,ex,ey,Sx_kaikou,Sy_kaikou,U,Z,lm);%单独列出xy坐标分布
%fangzhengongshiguiji=gongshiyufangzhenduibiguijitu2(S_PSD,M_PSD,theta,ex,ey,Sx_kaikou,Sy_kaikou,U,Z,lm);%看轨

%查看轨迹圆心和轴半长
%angle=theta*180/pi;
%S_PSDyuanxin=fit_ellipse_from_points(S_PSD,angle);
%M_PSDyuanxin=fit_ellipse_from_points(M_PSD,angle);
M_PSD(:,1)=-M_PSD(:,1);
for i = 1:length(theta)
    % 旋转角度 theta(i) 的旋转矩阵
    R_MPSD = [cos(theta(i)), -sin(theta(i));
           sin(theta(i)), cos(theta(i))];
    R_SPSD = [cos(theta(i)), -sin(theta(i));
           sin(theta(i)), cos(theta(i))];
    
    S_PSD(i,:)=S_PSD(i,:)*R_SPSD;
    M_PSD(i,:)=M_PSD(i,:)*R_MPSD;
end
% 打印圆心
    
    %ex_temp=(S_PSDyuanxin(1)+M_PSDyuanxin(1))/2;
    %ey_temp=(S_PSDyuanxin(2)-M_PSDyuanxin(2))/2;
    %fprintf('ex: (%.4f)\n', ex_temp);
    %fprintf('ey: (%.4f)\n', ey_temp);
    %
    %fprintf('Sx: (%.4f)\n', (-S_PSDyuanxin(1)+M_PSDyuanxin(1))*100/(2*U));
    %fprintf('Sy: (%.4f)\n', -1*(S_PSDyuanxin(2)+M_PSDyuanxin(2))*100/(2*U));
     % S_PSD 的总行数
% random_indices = randperm(num_points, 4);
random_indices =[360,183,90];

 alpha=theta;
noise =randi([-1,1],size(random_indices))*0.5;
% 从 S_PSD 中随机选取三行
x_s = S_PSD(random_indices, 1)'+randi([-1,1],size(random_indices))*0.45; % 随机选取的 x 坐标（第一列）
y_s = S_PSD(random_indices, 2)'+randi([-1,1],size(random_indices))*0.45; % 随机选取的 y 坐标（第二列）

x_m = M_PSD(random_indices, 1)'+randi([-1,1],size(random_indices))*0.45;
y_m = M_PSD(random_indices, 2)'+randi([-1,1],size(random_indices))*0.45;
% 随机选取的 x 坐标（第一列），加减10%的随机值
% x_s = S_PSD(random_indices, 1)' + (rand(size(random_indices))*0.4 - 0.2).*S_PSD(random_indices, 1)';
% % 随机选取的 y 坐标（第二列），加减10%的随机值
% y_s = S_PSD(random_indices, 2)' + (rand(size(random_indices))*0.4 - 0.2).*S_PSD(random_indices, 2)';
% 
% x_m = M_PSD(random_indices, 1)' + (rand(size(random_indices))*0.4 - 0.2).*M_PSD(random_indices, 1)';
% y_m = M_PSD(random_indices, 2)' + (rand(size(random_indices))*0.4 - 0.1).*M_PSD(random_indices, 2)';
%

t_data = alpha(random_indices);
% t_data=alpha;
%t_data_m=flip(t_data);
t_data_m=t_data;
%[k_fit, h_fit, a_fit, b_fit, phi_fit, theta_fit] = fit_model_points(t_data, y_s, x_s, true,S_PSD(:,1),S_PSD(:,2));
%[k_fit_m, h_fit_m, a_fit_m, b_fit_m, phi_fit_m, theta_fit_m] = fit_model_points(t_data, y_m, x_m, true,M_PSD(:,1),M_PSD(:,2));
%新法子 遗传算法
% [k_fit, h_fit, a_fit, b_fit, phi_fit, theta_fit, is_optimal_s] = fit_model_points_new(t_data, y_s, x_s, true, S_PSD(:,1), S_PSD(:,2));
% [k_fit_m, h_fit_m, a_fit_m, b_fit_m, phi_fit_m, theta_fit_m, is_optimal_m] = fit_model_points_new(t_data, y_m, x_m, true, M_PSD(:,1), M_PSD(:,2));
%新法子 改了公式
[k_fit, h_fit, a_fit, b_fit, phi_fit, theta_fit,r_fit, is_optimal_s] = fit_model_points_new_biangongshi(t_data, y_s, x_s, true, S_PSD(:,1), S_PSD(:,2));

[k_fit_m, h_fit_m, a_fit_m, b_fit_m, phi_fit_m, theta_fit_m,r_fit_m, is_optimal_m] = fit_model_points_new_biangongshi(t_data_m, y_m, x_m, true, M_PSD(:,1), M_PSD(:,2));
%新法子， 圆形轨迹最小二乘拟合
% [k_fit, h_fit, r1_fit, phi_fit, is_optimal] = fit_model_better_circles(t_data, y_s, x_s, true, S_PSD(:,1), S_PSD(:,2));
% [k_fit_m, h_fit_m, r1_fit_m,  phi_fit_m, is_optimal_m] = fit_model_better_circles(t_data_m, y_m, x_m, true, M_PSD(:,1), M_PSD(:,2));
% % 计算 x_sfit 和 y_sfit
%alpha=theta';
%x_sfit = h_fit + a_fit * cos(phi_fit + alpha) * cos(theta_fit) - b_fit * sin(phi_fit + alpha) * sin(theta_fit);
%y_sfit = k_fit + a_fit * cos(phi_fit + alpha) * sin(theta_fit) + b_fit * sin(phi_fit + alpha) * cos(theta_fit);
%
%% 计算 x_mfit 和 y_mfit
%x_mfit = h_fit_m + a_fit_m * cos(phi_fit_m + alpha) * cos(theta_fit_m) - b_fit * sin(phi_fit_m + alpha) * sin(theta_fit_m);
%y_mfit = k_fit_m + a_fit_m * cos(phi_fit_m + alpha) * sin(theta_fit_m) + b_fit_m * sin(phi_fit_m + alpha) * cos(theta_fit_m);
%S_PSD=[x_sfit,y_sfit];M_PSD=[x_mfit,y_mfit];

 % 拟合后求圆心
%alpha=theta;
%t_data = alpha(:)' ;  % 参数 
%%t_data=flip(t_data);
%t_data_m=t_data;
%M_PSD(:,1)=-M_PSD(:,1);
%for i = 1:length(theta)
%    % 旋转角度 theta(i) 的旋转矩阵
%    R_SPSD = [cos(theta(i)), -sin(theta(i));
%           sin(theta(i)), cos(theta(i))];
%    
%    S_PSD(i,:)=S_PSD(i,:)*R_SPSD;
%    M_PSD(i,:)=M_PSD(i,:)*R_SPSD;
%end
%x_s = S_PSD(:,1)';  % x 坐标
%y_s = S_PSD(:,2)';  % y 坐标
%x_m = M_PSD(:,1)';  % x 坐标
%y_m = M_PSD(:,2)';  % y 坐标

%[k_fit, h_fit, a_fit, b_fit, phi_fit, theta_fit] = fit_model_points(t_data, y_s, x_s, true,S_PSD(:,1),S_PSD(:,2));
%[k_fit_m, h_fit_m, a_fit_m, b_fit_m, phi_fit_m, theta_fit_m] = fit_model_points(t_data_m, y_m, x_m, true,M_PSD(:,1),M_PSD(:,2));
%用带角度参数的椭圆参数方程拟合
%alpha=theta;
%t_data = alpha(:)' ;  % 参数 t
%t_data_m=flip(t_data);
%x_s = S_PSD(:,1)';  % x 坐标
%y_s = S_PSD(:,2)';  % y 坐标
%x_m = M_PSD(:,1)';  % x 坐标
%y_m = M_PSD(:,2)';  % y 坐标
%
% 调用拟合函数
%[a, b, thetas, h, k] = fit_ellipse(x_s, y_s, t_data);
%[am, bm, thetam, hm, km] = fit_ellipse(x_m, y_m, t_data);
%x_sfit = h + a * sin(theta) * cos(thetas) + b * cos(theta) * sin(thetas);
%y_sfit = k - a * sin(theta) * sin(thetas) + b * cos(theta) * cos(thetas);
%x_mfit = hm + am * sin(theta) * cos(thetam) + bm * cos(theta) * sin(thetam);
%y_mfit = km - am * sin(theta) * sin(thetam) + bm * cos(theta) * cos(thetam);

% 打印圆心 
%非对称算法
  % tedingzhi_k=((k_fit_m+k_fit)*U-Z*k_fit)/(k_fit+k_fit_m);
  % tedingzhi_h=((h_fit_m+h_fit)*U-Z*h_fit)/(h_fit+h_fit_m);
  % h_fit_m=h_fit_m*(U+tedingzhi_h)/(Z-U+tedingzhi_h);
  % k_fit_m=k_fit_m*(U+tedingzhi_k)/(Z-U+tedingzhi_k);
    ex_temp=-(h_fit-h_fit_m)/2;
    ey_temp=-(k_fit-k_fit_m)/2;
    fprintf('ex: (%.4f)\n', ex_temp);
    fprintf('ey: (%.4f)\n', ey_temp);
    
    fprintf('Sx: (%.4f)\n', (h_fit+h_fit_m)*100/(2*U));
    fprintf('Sy: (%.4f)\n', 1*(k_fit+k_fit_m)*100/(2*U));


%fangzhengongshicha=xinjiucha_and_fangzhenxincha(S_PSD,M_PSD,theta,ex,ey,Sx_kaikou,Sy_kaikou,U,Z,lm);
%fangzhengongshicha2=shijizuobiaoyufangzhenwucha(S_PSD,M_PSD,theta,ex,ey,Sx_kaikou,Sy_kaikou,U,Z,lm,table_data);
%随着安装距离U的增大，四个不对中量变化
