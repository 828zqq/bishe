syms l1 U U2 ex Sx ey Sy
Mpoint = [-ex - Sx, -ey - Sy, U2];
result = cross(Mpoint, [0, 1, 0]);
final_result = cross(result, Mpoint);