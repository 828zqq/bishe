function allSelectedIndices = selectPointsForEachStart(angles, threshold)
    % 输入检查
    if length(angles) < 3
        error('输入数组中的元素少于3个，无法进行筛选');
    end
    
    n = length(angles); % 数组长度
    allSelectedIndices = []; % 使用cell数组存储每个起点对应的选中点的索引
    
    for startIdx = 1:n
        selectedIndices = [];
        selectedIndices = [selectedIndices, startIdx]; % 将当前起点添加到选定点列表中
        foundCount = 1; % 已找到满足条件的点的数量
        
        lastSelectedAngleIndex = startIdx;
        
        for currentIdx = startIdx+1:n
            if abs(angles(currentIdx) - angles(lastSelectedAngleIndex)) > threshold
                selectedIndices = [selectedIndices, currentIdx];
                lastSelectedAngleIndex = currentIdx;
                foundCount = foundCount + 1;
                if foundCount == 3 % 如果已经找到了3个点，则停止寻找
                    break;
                end
            end
        end
        
        % 如果没有找到3个满足条件的点，给出警告并记录已找到的点
        
        if foundCount == 3
            allSelectedIndices = [allSelectedIndices; selectedIndices]; % 添加满足条件的索引组
        end
    
    disp('所有选定点对应的原数组序号组是：');
    for i = 1:size(allSelectedIndices, 1)
        fprintf('序号组 %d: %s\n', i, mat2str(allSelectedIndices(i,:)));
    end
end