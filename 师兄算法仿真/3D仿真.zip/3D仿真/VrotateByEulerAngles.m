function absVector = VrotateByEulerAngles(points,anzhuang_point,yaw,pitch,roll,plane)
    % 输入：
    %   Points - 平面上的一个点
            % 偏航角（Yaw） - 绕Z轴旋转
            % 俯仰角（Pitch） - 绕X轴旋转
            % 横滚角（Roll） - 绕Y轴旋转
            % 定义旋转矩阵 (右手坐标系)
   absVector = zeros(length(points), 3);  % 存储逆时针旋转后的点
    %   normal 相对坐标系的z轴
         normal =-[plane.A,plane.B,plane.C];
         normal = normal/norm(normal);
     % 构造旋转矩阵 R
    Rz = [cos(yaw), -sin(yaw), 0;
          sin(yaw), cos(yaw), 0;
          0, 0, 1];
    
    Rx = [1, 0, 0;
          0, cos(pitch), -sin(pitch);
          0, sin(pitch), cos(pitch)];
    
    Ry = [cos(roll), 0, sin(roll);
          0, 1, 0;
          -sin(roll), 0, cos(roll)];
    
    R = Rz  * Ry * Rx;%按右手坐标系排序
         for i = 1:size(points,1)
     % 相对坐标系y轴
       v2 =  points(i,:) - anzhuang_point;
       v2 = v2/norm(v2);
     %相对坐标系x轴
       v1 =  cross(v2,normal);
      %对初始激光向量[0,0,1]进行旋转
      newvector = R * [0;0;1];
     absVector(i,:) = [v1(:),v2(:),normal(:)]* newvector;
 
         end
             absVector=absVector(1,:);
end