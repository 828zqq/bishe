clc;clear;
addpath('D:\开题\3D仿真\仿真方法类');
addpath('D:\开题\3D仿真');
table_data = readtable('0114easylaser实测y坐标.xlsx');
%输入变量

U=100;Z=200;
ex=-0.05;ey=-0.12;Sx=-0.96;Sy=-0.41;%S(mm/100mm) e(mm)
Sx_kaikou=Sx*U/100;
Sy_kaikou=Sy*U/100;
%S机M机距离Z，以及S机到联轴器中心距离
ls=152;%S机激光距离
lm=152;%M机PSD到轴的距离
l_length=30;

% 生成圆周上的点
theta = linspace(0, 360, 361);  % 圆周角度范围
theta=theta*pi/180;
shaft=shaft_Line2();
shaft=shaft.build_shaft_3D2(ex,ey,Sx_kaikou,Sy_kaikou,U,Z);
%生成S机平面、M机平面圆周点
M_ordered_circle_points=OrderedCirclePoints1(shaft.direction_vector_Mzhou,shaft.Mpoint_anzhuang,lm,l_length,theta);
S_ordered_circle_points=OrderedCirclePoints1(shaft.direction_vector_Szhou,shaft.Spoint_anzhuang,ls,l_length,theta);
%创建M机S机平面
Mplane=Plane(shaft.direction_vector_Mzhou,shaft.Mpoint_anzhuang);
Splane=Plane(shaft.direction_vector_Szhou,shaft.Spoint_anzhuang);

%平面发生偏斜：
%Mplane=rotateByEulerAngles(M_ordered_circle_points,shaft.Mpoint_anzhuang,obj,0,02*pi/180,0,02*pi/180, 0);
%Splane=rotateByEulerAngles(S_ordered_circle_points,shaft.Spoint_anzhuang,obj,0,02*pi/180,0,02*pi/180, 0);
%Mplane_shaft=[Mplane.A,Mplane.B,Mplane.C];

%构建激光方向向量
S_M_laser = Vector3D(S_ordered_circle_points.Chang_0point,M_ordered_circle_points.Chang_0point).line;
M_S_laser = Vector3D(M_ordered_circle_points.Duan_0point,S_ordered_circle_points.Duan_0point).line;
%S_M_laser = shaft.direction_vector_Szhou;
%M_S_laser = -shaft.direction_vector_Mzhou;
%%激光发生偏斜
%S_M_laser = VrotateByEulerAngles(S_ordered_circle_points.Chang_0point,shaft.Spoint_anzhuang,0,0*pi/180,0*pi/180,Splane);
%M_S_laser = VrotateByEulerAngles(M_ordered_circle_points.Duan_0point,shaft.Mpoint_anzhuang,0,0*pi/180,0*pi/180,Mplane);
%激光与平面交点集合
%M_Lasertrajectory=findIntersection_again1(shaft.direction_vector_Szhou,S_M_laser.line,Mplane,theta,S_ordered_circle_points.ordered_circle_points_chang);
%S_Lasertrajectory=findIntersection_again1(shaft.direction_vector_Mzhou,M_S_laser.line,Splane,theta,M_ordered_circle_points.ordered_circle_points_duan);
M_Lasertrajectory=findIntersection_again1(shaft.direction_vector_Szhou,S_M_laser,Mplane,theta,S_ordered_circle_points.ordered_circle_points_chang);
S_Lasertrajectory=findIntersection_again1(shaft.direction_vector_Mzhou,M_S_laser,Splane,theta,M_ordered_circle_points.ordered_circle_points_duan);%下面两行是激光平行于轴线
%坐标系转换到Mpsd和Spsd
M_PSD=M_RelativeCoorTransfer(shaft.direction_vector_Mzhou,M_ordered_circle_points.ordered_circle_points_chang,shaft.Mpoint_anzhuang,theta,M_Lasertrajectory);
S_PSD=S_RelativeCoorTransfer(theta,S_ordered_circle_points.Duan_0point,S_Lasertrajectory);
%将坐标代入到不对中量计算函数
%mean_alignment=anypoints(S_PSD,M_PSD,theta,U,Z);
%对比仿真和公式坐标轨迹
%fangzhengongshiduibi=shiceyufangzhenduibizhenghetu3(S_PSD,M_PSD,theta,ex,ey,Sx_kaikou,Sy_kaikou,U,Z,lm);%单独列出xy坐标分布
%fangzhengongshiguiji=gongshiyufangzhenduibiguijitu2(S_PSD,M_PSD,theta,ex,ey,Sx_kaikou,Sy_kaikou,U,Z,lm);%看轨

%查看轨迹圆心和轴半长
%angle=theta*180/pi;
%S_PSDyuanxin=fit_ellipse_from_points(S_PSD,angle);
%M_PSDyuanxin=fit_ellipse_from_points(M_PSD,angle);
M_PSD(:,1)=-M_PSD(:,1);
for i = 1:length(theta)
    % 旋转角度 theta(i) 的旋转矩阵
    R_SPSD = [cos(theta(i)), -sin(theta(i));
           sin(theta(i)), cos(theta(i))];
    
    S_PSD(i,:)=S_PSD(i,:)*R_SPSD;
    M_PSD(i,:)=M_PSD(i,:)*R_SPSD;
end
% 打印圆心

random_indices =[1,90,180,270];

 alpha=theta;

% 从 S_PSD 中随机选取三行
x_s = S_PSD(random_indices, 1)'; % 随机选取的 x 坐标（第一列）
y_s = S_PSD(random_indices, 2)'; % 随机选取的 y 坐标（第二列）
x_m = M_PSD(random_indices, 1)';
y_m = M_PSD(random_indices, 2)';

%

t_data = -alpha(random_indices);

%新法子 改了公式
[k_fit, h_fit, a_fit, b_fit, phi_fit, theta_fit,r_fit, is_optimal_s] = fit_model_points_new_biangongshi(t_data, y_s, x_s, true, S_PSD(:,1), S_PSD(:,2));
t_data_m=t_data;
[k_fit_m, h_fit_m, a_fit_m, b_fit_m, phi_fit_m, theta_fit_m,r_fit_m, is_optimal_m] = fit_model_points_new_biangongshi(t_data_m, y_m, x_m, true, M_PSD(:,1), M_PSD(:,2));



% 打印圆心
    
    ex_temp=-(h_fit-h_fit_m)/2;
    ey_temp=-(k_fit-k_fit_m)/2;
    Sx_temp=(h_fit+h_fit_m)*100/(2*U);
    Sy_temp=1*(k_fit+k_fit_m)*100/(2*U);

    fprintf('ex: (%.4f)\n', ex_temp);
    fprintf('ey: (%.4f)\n', ey_temp);
    
    fprintf('Sx: (%.4f)\n', (h_fit+h_fit_m)*100/(2*U));
    fprintf('Sy: (%.4f)\n', 1*(k_fit+k_fit_m)*100/(2*U));

%% 参数设置
max_noise = 0.015;       % 定义噪声最大幅度（根据实际情况调整）
num_iterations = 10;  % 循环次数
               % 假设的常数（需根据实际情况定义）

%% 初始化存储矩阵
ex_all = zeros(num_iterations, 1);
ey_all = zeros(num_iterations, 1);
Sx_all = zeros(num_iterations, 1);
Sy_all = zeros(num_iterations, 1);

%% 主循环
for i = 1:num_iterations
    % 添加均匀分布噪声（范围 [-max_noise, max_noise]）
    noise_x_s = max_noise * (2*rand(size(x_s)) - 1);
    noise_x_m = max_noise * (2*rand(size(x_m)) - 1);
    noise_y_s = max_noise * (2*rand(size(x_s)) - 1);
    noise_y_m = max_noise * (2*rand(size(x_m)) - 1);
    
    % 生成带噪声的坐标（保持原始数据维度）
    x_s_noise = x_s + noise_x_s;
    y_s_noise = y_s + noise_y_s;
    x_m_noise = x_m + noise_x_m;
    y_m_noise = y_m + noise_y_m;
    
    % 调用拟合函数（注意参数格式调整）
    [k_fit, h_fit, ~, ~, ~, ~, ~, ~] = fit_model_points_new_biangongshi(...
        t_data, y_s_noise, x_s_noise, true, x_s_noise', y_s_noise');
    
    [k_fit_m, h_fit_m, ~, ~, ~, ~, ~, ~] = fit_model_points_new_biangongshi(...
        t_data_m, y_m_noise, x_m_noise, true, x_m_noise', y_m_noise');
    
    % 计算结果参数
    ex_all(i) = -(h_fit - h_fit_m)/2;
    ey_all(i) = -(k_fit - k_fit_m)/2;
    Sx_all(i) = (h_fit + h_fit_m)*100/(2*U);
    Sy_all(i) = (k_fit + k_fit_m)*100/(2*U);
end
% 创建结构体存储结果
results = struct(...
    'Px', ex_all,...
    'Py', ey_all,...
    'Ax', Sx_all,...
    'Ay', Sy_all);
%% 结果分析
%result_metrics = struct(...
%    'ex_all', struct('mean', mean(ex_all), 'std', std(ex_all), 'range', range(ex_all)),...
%    'ey_all', struct('mean', mean(ey_all), 'std', std(ey_all), 'range', range(ey_all)),...
%    'Sx_all', struct('mean', mean(Sx_all), 'std', std(Sx_all), 'range', range(Sx_all)),...
%    'Sy_all', struct('mean', mean(Sy_all), 'std', std(Sy_all), 'range', range(Sy_all)));

%% 可视化（示例）
%figure;
%subplot(2,2,1)
%histogram(ex_all, 20);
%title('ex\_temp 分布');
%subplot(2,2,2)
%histogram(ey_all, 20);
%title('ey\_temp 分布');
%subplot(2,2,3)
%histogram(Sx_all, 20);
%title('Sx\_temp 分布');
%subplot(2,2,4)
%histogram(Sy_all, 20);
%title('Sy\_temp 分布');

%% 初始化图形窗口
figure;

%% 创建四个子图
param_names = {'Px', 'Py', 'Ax', 'Ay_all'};
baseline_values = [ex_temp, ey_temp, Sx_temp, Sy_temp]; % 假设这四个基准值已预先计算

for i = 1:4
    subplot(2,2,i);
    current_data = results.(param_names{i}); % 获取当前参数数据
    
    % 绘制数据波动折线
    plot(1:num_iterations, current_data, 'b-', 'LineWidth', 1); 
    hold on;
    
    % 添加基准线及波动范围（网页19、38的误差条方法）
    plot([1 num_iterations], [baseline_values(i) baseline_values(i)], 'k--', 'LineWidth', 1.5); % 基准线
    plot([1 num_iterations], [baseline_values(i)+0.01 baseline_values(i)+0.01], 'r:', 'LineWidth', 1.2); % 上界
    plot([1 num_iterations], [baseline_values(i)-0.01 baseline_values(i)-0.01], 'r:', 'LineWidth', 1.2); % 下界
    
    % 图形修饰（网页38的坐标控制）
    title([param_names{i} ' 波动分析'], 'FontSize', 12);
    xlabel('迭代次数', 'FontSize', 10);
    ylabel('参数值', 'FontSize', 10);
    label_pos = [0.85, 0.93]; 
    text('Units', 'normalized',...
         'Position', label_pos,...
         'String', ['(' char(96+i) ')'],... % 自动生成(a)(b)(c)(d)
         'FontSize', 14,...
         'FontWeight', 'bold',...
         'HorizontalAlignment', 'left',...
         'VerticalAlignment', 'top');
    grid on;
    axis tight;
    legend('参数波动', '基准值', '允许范围', 'Location', 'best');
    
    % 设置坐标轴范围（网页33的axis控制）
   % y_range = [baseline_values(i)-0.015, baseline_values(i)+0.015];
   % ylim(y_range);
end

%% 显示统计结果
%disp('=== 噪声影响统计结果 ===');
%disp(['ex_temp 均值: ' num2str(result_metrics.ex.mean)...
%    ' ± ' num2str(result_metrics.ex.std)]);
%disp(['ey_temp 极差: ' num2str(result_metrics.ey.range)]);
% 类似显示其他参数的统计信息


%fangzhengongshicha=xinjiucha_and_fangzhenxincha(S_PSD,M_PSD,theta,ex,ey,Sx_kaikou,Sy_kaikou,U,Z,lm);
%fangzhengongshicha2=shijizuobiaoyufangzhenwucha(S_PSD,M_PSD,theta,ex,ey,Sx_kaikou,Sy_kaikou,U,Z,lm,table_data);
%随着安装距离U的增大，四个不对中量变化
