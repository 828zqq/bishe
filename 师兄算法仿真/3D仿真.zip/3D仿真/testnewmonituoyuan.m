% 示例数据
clc;clear;
addpath('D:\开题\2025实验记录');
table_data = readtable('super0611.xlsx','Sheet','Sheet4');
% table_data = readtable('super0414.xlsx');
% %没调零视频的数据
%points_M = [-0.9,-1.46;   % 点1，r=5，θ=30度
%-0.25, -0.59;   % 点2，r=4，θ=120度
%-1.31,-1.49];
%alpha = [ 249.8; 2.8; 80.8]; % 各点法线方向角度
%
%points_S = [-0.62,1.38;   % 点1，r=5，θ=30度
%0.17, 0.79;   % 点2，r=4，θ=120度
%-1.54,1.85];   % 点3，r=6，θ=200度 

%单位为密尔调零的数据
%points_S = [57.3,1.2;   % 点1，r=5，θ=30度
%19.8, -3.9; 
%-10.1,-3.8]; 
%points_M = [31.8,-20.8;   % 点1，r=5，θ=30度
%10, -11;   % 点2，r=4，θ=120度
%-11.8,-2.8];
%alpha = [96.1; 55.1; 17.7]; 

%多加几个点
%points_S = [57.3,1.2;   % 点1，r=5，θ=30度
%19.8, -3.9; 
%-10.1,-3.8;-21.2,0;-25.9,5.4]; 
%points_M = [31.8,-20.8;   % 点1，r=5，θ=30度
%10, -11;   % 点2，r=4，θ=120度
%-11.8,-2.8;-22.9,1.3;-33,1.6];
%alpha = [96.1; 55.1; 17.7;344.8;312.2]; 

%points_M = [2.24,-5.69;   % 点1，r=5，θ=30度
%2.36, -4.39;   % 点2，r=4，θ=120度
%2.47,-2.69];
%alpha = [ 6; 259.3;138.1]; % 各点法线方向角度
%
%points_S = [3.69,0.10;   % 点1，r=5，θ=30度
%3.46, -0.04;   % 点2，r=4，θ=120度
%3.19,-0.6];   % 点3，r=6，θ=200度 
%clc;clear;
    % 手动输入三个点的坐标
%    points_S = [-0.62	1.38
%0.17	0.79
%-1.54	1.85];
%    points_S=[-0.9	-1.46
%-0.25	-0.59
%-1.31	-1.49
%];

%从superlaser调取数据
points_S=[table_data.S_PSD_x(:),table_data.S_PSD_y(:)];
points_M=[table_data.M_PSD_x(:),table_data.M_PSD_y(:)];
ys=table_data.S_PSD_y(:);
ym=table_data.M_PSD_y(:);
xs=table_data.S_PSD_x(:);
xm=table_data.M_PSD_x(:);
S_PSD=[xs,ys];
M_PSD=[xm,ym];

alpha1 = [table_data.O1(:)];
alpha1=alpha1*pi/180;
alpha2=[table_data.O2(:)];
alpha2=alpha2*pi/180;
theta=alpha1;
M_PSD(:,1)=-M_PSD(:,1);
for i = 1:length(theta)
    % 旋转角度 theta(i) 的旋转矩阵
    R_SPSD = [cos(theta(i)), -sin(theta(i));
           sin(theta(i)), cos(theta(i))];

    S_PSD(i,:)=S_PSD(i,:)*R_SPSD;
    
end
theta=alpha2;
for i = 1:length(theta)
    % 旋转角度 theta(i) 的旋转矩阵
    R_SPSD = [cos(theta(i)), -sin(theta(i));
           sin(theta(i)), cos(theta(i))];

    M_PSD(i,:)=M_PSD(i,:)*R_SPSD;
end


x_s = S_PSD(:, 1); % 随机选取的 x 坐标（第一列）
y_s = S_PSD(:, 2); % 随机选取的 y 坐标（第二列）
x_m = M_PSD(:, 1);
y_m = M_PSD(:, 2);

% random_indices =[186,187,188];
random_indices=linspace(60,114,55);

 alpha1=alpha1(random_indices)';
 alpha2=alpha2(random_indices)';

% 从 S_PSD 中随机选取三行
x_s = S_PSD(random_indices, 1)'; % 随机选取的 x 坐标（第一列）
y_s = S_PSD(random_indices, 2)'; % 随机选取的 y 坐标（第二列）
x_m = M_PSD(random_indices, 1)';
y_m = M_PSD(random_indices, 2)';

% 调用函数
U=58;
Z=2*U;

%[k_fit, h_fit, a_fit, b_fit, phi_fit, theta_fit] = fit_model_points(alpha, ys, xs, true);
%[k_fit_m, h_fit_m, a_fit_m, b_fit_m, phi_fit_m, theta_fit_m] = fit_model_points(alpha, ym, xm,true);
[k_fit, h_fit, a_fit, b_fit, phi_fit, theta_fit, is_optimal_s] = fit_model_points_new_biangongshi(alpha1, y_s, x_s,false , S_PSD(:,1), S_PSD(:,2));
[k_fit_m, h_fit_m, a_fit_m, b_fit_m, phi_fit_m, theta_fit_m, is_optimal_m] = fit_model_points_new_biangongshi(alpha2, y_m, x_m, false, M_PSD(:,1), M_PSD(:,2));
% [k_fit, h_fit, a_fit, b_fit, phi_fit, theta_fit, is_optimal_s] = fit_model_points_new_biangongshi(alpha1, y_s, x_s, true, x_s, y_s);
% [k_fit_m, h_fit_m, a_fit_m, b_fit_m, phi_fit_m, theta_fit_m, is_optimal_m] = fit_model_points_new_biangongshi(alpha2, y_m, x_m, true, x_m, y_m);
%M_center
% tedingzhi_k=((k_fit_m+k_fit)*U-Z*k_fit)/(k_fit+k_fit_m);
%   tedingzhi_h=((h_fit_m+h_fit)*U-Z*h_fit)/(h_fit+h_fit_m);
%   h_fit_m=h_fit_m*(U+tedingzhi_h)/(Z-U+tedingzhi_h);
%   k_fit_m=k_fit_m*(U+tedingzhi_k)/(Z-U+tedingzhi_k);
ex_temp=(h_fit_m-h_fit)/2;
ey_temp=(k_fit_m-k_fit)/2;
sx=(h_fit_m+h_fit)*100/(2*U);
sy=(k_fit_m+k_fit)*100/(2*U);
fprintf('ex: (%.4f)\n', ex_temp);
fprintf('ey: (%.4f)\n', ey_temp);
fprintf('Sx: (%.4f)\n', sx);
fprintf('Sy: (%.4f)\n', sy);
