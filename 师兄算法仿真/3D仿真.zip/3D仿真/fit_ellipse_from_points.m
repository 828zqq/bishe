%clc;clear;
    % 手动输入三个点的坐标
%    points_S = [-0.62	1.38
%0.17	0.79
%-1.54	1.85];
%    points_S=[-0.9	-1.46
%-0.25	-0.59
%-1.31	-1.49
%];


    % 直接在程序中定义三个点的坐标和几何角度（单位：度）
    % 格式: [x, y, 角度(0-360°)]
%  points = [0,0,0;-0.62,1.38, 249.8;   % 点1，r=5，θ=30度
%0.17, 0.79, 120;   % 点2，r=4，θ=120度
%-1.54,1.85, 200];   % 点3，r=6，θ=200度
%  points = [0,0,0;-0.9,-1.46, 249.8;   % 点1，r=5，θ=30度
%-0.25, -0.59, 120;   % 点2，r=4，θ=120度
%-1.31,-1.49, 200];

%20250217初版
function fit_ellipse=fit_ellipse_from_points(points,alpha)
    % 提取坐标和角度
    %theta=alpha*pi/180;
    %for i = 1:length(theta)
    %% 旋转角度 theta(i) 的顺时针旋转矩阵
    %R_PSD = [cos(theta(i)), -sin(theta(i));
    %       sin(theta(i)), cos(theta(i))];
    %
    %points(i,:)=points(i,:)*R_PSD;
    %
    %end
    x = points(:, 1);
    y = points(:, 2);
    alpha_deg = alpha(:);
    
    % 初始猜测参数: [h, k, a, b, theta]
    % 假设中心为坐标均值，a和b为坐标范围，theta=0°
    initial_h = mean(x);
    initial_k = mean(y);
    initial_a = (max(x) - min(x)) / 2;
    initial_b = (max(y) - min(y)) / 2;
    initial_theta = 0;
    params0 = [initial_h, initial_k, initial_a, initial_b, initial_theta];
    
    % 非线性最小二乘优化
    options = optimoptions('lsqnonlin', 'Display', 'iter', 'Algorithm', 'levenberg-marquardt');
    params = lsqnonlin(@(p) error_func(p, x, y, alpha_deg), params0, [], [], options);
    
    % 提取优化后的参数
    h = params(1);
    k = params(2);
    a = params(3);
    b = params(4);
    theta = params(5); % 椭圆的旋转角度（逆时针从x轴计算）
    
    % 输出结果
    fprintf('椭圆中心: (%.4f, %.4f)\n', h, k);
    fprintf('长轴: %.4f, 短轴: %.4f\n', a, b);
    fprintf('旋转角度 (逆时针从x轴): %.4f°\n', rad2deg(theta));
    
    
    % 绘制结果
    figure;
    plot(x, y, 'ro', 'DisplayName', '输入点'); hold on;
    plot(h, k, 'bx', 'MarkerSize', 10, 'LineWidth', 2, 'DisplayName', '拟合圆心');
    
    % 绘制拟合椭圆
    phi = linspace(0, 2*pi, 100);
    x_ellipse = h + a*cos(phi)*cos(theta) - b*sin(phi)*sin(theta);
    y_ellipse = k + a*cos(phi)*sin(theta) + b*sin(phi)*cos(theta);
    plot(x_ellipse, y_ellipse, 'b-', 'DisplayName', '拟合椭圆');
    
    % 绘制理论角度方向线（红色虚线）
    %for i = 1:length(alpha_deg)
    %    alpha_rad = deg2rad(alpha_deg(i));
    %    phi_i = (pi/2 - alpha_rad) - theta; % 转换为参数角度
    %    x_dir = h + 2*a*cos(phi_i)*cos(theta) - 2*b*sin(phi_i)*sin(theta);
    %    y_dir = k + a*cos(phi_i)*sin(theta) + b*sin(phi_i)*cos(theta);
    %    plot([h, x_dir], [k, y_dir], 'r--', 'LineWidth', 1);
    %   end
    yuanxin=[h,k,x_ellipse,y_ellipse];
    fit_ellipse=yuanxin;
    % 设置图形属性
    axis equal;
    legend;
    title('结合几何角度的椭圆拟合');
    xlabel('x');
    ylabel('y');
    grid on;
end

% 误差函数（坐标误差 + 角度误差）
function err = error_func(params, x, y, alpha_deg)
    h = params(1);
    k = params(2);
    a = params(3);
    b = params(4);
    theta = params(5);
    
    % 坐标误差：点到椭圆的代数距离
    dx = x - h;
    dy = y - k;
    costheta = cos(theta);
    sintheta = sin(theta);
    x_rot = dx * costheta + dy * sintheta;
    y_rot = -dx * sintheta + dy * costheta;
    coord_err = (x_rot.^2 / a^2 + y_rot.^2 / b^2 - 1).^2;
    
    % 角度误差：理论角度与实际角度的偏差
    alpha_rad = deg2rad(alpha_deg);
    phi = alpha_rad;
    x_fit = h + a*cos(phi)*costheta - b*sin(phi)*sintheta;
    y_fit = k + a*cos(phi)*sintheta + b*sin(phi)*costheta;
    angle_err = (x - x_fit).^2 + (y - y_fit).^2;
    
    % 总误差（权重可根据需求调整）
    err = coord_err + 0 * angle_err;
end