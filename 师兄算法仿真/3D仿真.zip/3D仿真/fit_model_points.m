function [k_fit, h_fit, a_fit, b_fit, phi_fit, theta_fit] = fit_model_points(alpha, y_data, x_data, plot_results,x,y)
    % FIT_MODEL 拟合给定的模型
    %
    % 输入参数：
    %   alpha: 数据点的 alpha 值（列向量）
    %   y_data: 数据点的 y 值（列向量）
    %   x_data: 数据点的 x 值（列向量）
    %   initial_guess: 初始猜测值 [k, h, a, b, phi, theta]
    %   plot_results: 是否绘制拟合结果（true/false）
    %
    % 输出参数：
    %   k_fit, h_fit, a_fit, b_fit, phi_fit, theta_fit: 拟合后的参数值

    initial_guess = [1, 0.5, 1, 1, pi/6, pi/4];
    % 定义目标函数（最小化残差平方和）
    %model_y = @(params, alpha) params(1) + params(3) * cos(params(5) + alpha) * sin(params(6)) + params(4) * sin(params(5) + alpha) * cos(params(6));
    %model_x = @(params, alpha) params(2) + params(3) * cos(params(5) + alpha) * cos(params(6)) - params(4) * sin(params(5) + alpha) * sin(params(6));
    model_y = @(params, alpha) params(1) + params(3) * cos(params(5) + mod(alpha, 2*pi)) * sin(params(6)) + params(4) * sin(params(5) + mod(alpha, 2*pi)) * cos(params(6));
    model_x = @(params, alpha) params(2) + params(3) * cos(params(5) + mod(alpha, 2*pi)) * cos(params(6)) - params(4) * sin(params(5) + mod(alpha, 2*pi)) * sin(params(6));
    objective = @(params) sum((model_y(params, alpha) - y_data).^2) + sum((model_x(params, alpha) - x_data).^2);

    % 定义约束条件
    constraint1 = @(params) params(1) - params(3) * cos(params(5)) * sin(params(6)) + params(4) * sin(params(5)) * cos(params(6));
    constraint2 = @(params) params(2) + params(3) * cos(params(5)) * cos(params(6)) + params(4) * sin(params(5)) * sin(params(6));

    % 使用 fmincon 进行带约束的优化
    options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm', 'interior-point');
    fitted_params = fmincon(objective, initial_guess, [], [], [], [], [], [], @(params) deal([], [constraint1(params); constraint2(params)]), options);

    % 提取拟合结果
    k_fit = fitted_params(1);
    h_fit = fitted_params(2);
    a_fit = fitted_params(3);
    b_fit = fitted_params(4);
    phi_fit = fitted_params(5);
    theta_fit = fitted_params(6);

    % 输出拟合结果
    disp('拟合结果:');
    disp(['k = ', num2str(k_fit)]);
    disp(['h = ', num2str(h_fit)]);
    disp(['a = ', num2str(a_fit)]);
    disp(['b = ', num2str(b_fit)]);
    disp(['phi = ', num2str(phi_fit)]);
    disp(['theta = ', num2str(theta_fit)]);

    figure;
    plot(x, y, 'ro', 'DisplayName', '输入点'); hold on;
    plot(h_fit, k_fit, 'bx', 'MarkerSize', 10, 'LineWidth', 2, 'DisplayName', '拟合圆心');
    
    % 绘制拟合椭圆
    phi = linspace(0, 2*pi, 100);
    x_ellipse =  h_fit + a_fit * cos(phi_fit + phi) * cos(theta_fit) - b_fit * sin(phi_fit + phi) * sin(theta_fit);
    y_ellipse =  k_fit + a_fit * cos(phi_fit + phi) * sin(theta_fit) + b_fit * sin(phi_fit + phi) * cos(theta_fit);
    plot(x_ellipse, y_ellipse, 'b-', 'DisplayName', '拟合椭圆');
    
    % 绘制理论角度方向线（红色虚线）
    %for i = 1:length(alpha_deg)
    %    alpha_rad = deg2rad(alpha_deg(i));
    %    phi_i = (pi/2 - alpha_rad) - theta; % 转换为参数角度
    %    x_dir = h + 2*a*cos(phi_i)*cos(theta) - 2*b*sin(phi_i)*sin(theta);
    %    y_dir = k + a*cos(phi_i)*sin(theta) + b*sin(phi_i)*cos(theta);
    %    plot([h, x_dir], [k, y_dir], 'r--', 'LineWidth', 1);
    %   end
    yuanxin=[h_fit,k_fit,x_ellipse,y_ellipse];
    fit_ellipse=yuanxin;
    % 设置图形属性
    axis equal;
    legend;
    title('结合几何角度的椭圆拟合');
    xlabel('x');
    ylabel('y');
    grid on;

    % 绘制拟合曲线（如果 plot_results 为 true）
    if plot_results
        alpha_fit = linspace(min(alpha), max(alpha), 100);
        y_fit = model_y(fitted_params, alpha_fit);
        x_fit = model_x(fitted_params, alpha_fit);

        figure;
        subplot(2, 1, 1);
        plot(alpha, y_data, 'bo', 'DisplayName', '数据点 (y)');
        hold on;
        plot(alpha_fit, y_fit, 'r-', 'DisplayName', '拟合曲线 (y)');
        xlabel('\alpha');
        ylabel('y');
        legend;
        title('y(\alpha) 拟合结果');
        grid on;

        subplot(2, 1, 2);
        plot(alpha, x_data, 'bo', 'DisplayName', '数据点 (x)');
        hold on;
        plot(alpha_fit, x_fit, 'r-', 'DisplayName', '拟合曲线 (x)');
        xlabel('\alpha');
        ylabel('x');
        legend;
        title('x(\alpha) 拟合结果');
        grid on;
    end
end