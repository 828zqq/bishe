%% Analysis_Parallel_Offset_Effect.m
clc; clear; close all; format long g;

%% 1. 基础参数设定
Geo.z1 = 150;          
Geo.z2 = 150;
Geo.H_M_LD = 100;      
diff_H = 20;           
Geo.H_M_PSD = Geo.H_M_LD - diff_H;
Geo.H_S_PSD = Geo.H_M_LD + 30; 
Geo.H_S_LD  = Geo.H_S_PSD - diff_H;

Const_Alpha_Unit = 0.75;   
Const_Beta_Unit  = -1.5;    

scan_vals = -3 : 0.02 : 3;
num_steps = length(scan_vals);

Err_TPM_Lin = zeros(num_steps, 4);
Err_TPM_Iter = zeros(num_steps, 4);
Err_APM_Lin = zeros(num_steps, 4);
Err_APM_Iter = zeros(num_steps, 4);

RelErr_TPM_Lin = zeros(num_steps, 4);
RelErr_TPM_Iter = zeros(num_steps, 4);
RelErr_APM_Lin = zeros(num_steps, 4);
RelErr_APM_Iter = zeros(num_steps, 4);

APM_Angles = [45, 90, 135, 180, 225, 270, 315, 350];

fprintf('开始仿真扫描 (Offset: -3mm -> +3mm)...\n');
wb = waitbar(0, '正在进行平行不对中敏感性分析...');

%% 2. 扫描
for i = 1:num_steps
    val = scan_vals(i);
    waitbar(i/num_steps, wb, sprintf('Offset = %.2f mm', val));

    True_Val_Unit.dx = val;
    True_Val_Unit.dy = val;
    True_Val_Unit.alpha = Const_Alpha_Unit;
    True_Val_Unit.beta  = Const_Beta_Unit;

    True_Val_Phys = True_Val_Unit;
    True_Val_Phys.alpha = atand(True_Val_Unit.alpha / 100);
    True_Val_Phys.beta  = atand(True_Val_Unit.beta / 100);
    
    [Geo_Calib, gamma_calib, ~] = run_calibration_logic(Geo, True_Val_Phys);
    
    [s90, m90]   = get_readings(Geo_Calib, True_Val_Phys, 90, gamma_calib);
    [s180, m180] = get_readings(Geo_Calib, True_Val_Phys, 180, gamma_calib);
    TPM_Data = [s90, m90, s180, m180];

    APM_S = zeros(8, 1); APM_M = zeros(8, 1);
    for k = 1:8
        [APM_S(k), APM_M(k)] = get_readings(Geo_Calib, True_Val_Phys, APM_Angles(k), gamma_calib);
    end

    Res_TPM_Lin = solve_TPM_linear(TPM_Data, Geo);
    Res_TPM_Iter = solve_TPM_iterative(Res_TPM_Lin, TPM_Data, Geo_Calib, gamma_calib);
    
    [As, Bs, Cs] = fit_sine_wave(APM_Angles, APM_S);
    [Am, Bm, Cm] = fit_sine_wave(APM_Angles, APM_M);
    Res_APM_Lin = solve_APM_linear(As, Bs, Am, Bm, Geo);
    Res_APM_Iter = solve_APM_iterative(Res_APM_Lin, APM_Angles, APM_S, APM_M, Geo_Calib, gamma_calib);

    E_TL = calc_unit_error(Res_TPM_Lin, True_Val_Unit);
    E_TI = calc_unit_error(Res_TPM_Iter, True_Val_Unit);
    E_AL = calc_unit_error(Res_APM_Lin, True_Val_Unit);
    E_AI = calc_unit_error(Res_APM_Iter, True_Val_Unit);
    
    Err_TPM_Lin(i,:) = E_TL; Err_TPM_Iter(i,:) = E_TI;
    Err_APM_Lin(i,:) = E_AL; Err_APM_Iter(i,:) = E_AI;

    TV_Vec = [True_Val_Unit.dx, True_Val_Unit.dy, True_Val_Unit.alpha, True_Val_Unit.beta];
    
    calc_rel = @(err, true_v) abs(err) ./ (abs(true_v) + 1e-9) * 100;
    
    RelErr_TPM_Lin(i,:) = calc_rel(E_TL, TV_Vec);
    RelErr_TPM_Iter(i,:) = calc_rel(E_TI, TV_Vec);
    RelErr_APM_Lin(i,:) = calc_rel(E_AL, TV_Vec);
    RelErr_APM_Iter(i,:) = calc_rel(E_AI, TV_Vec);
end
close(wb);

%% 3.绝对误差
% -------------------------------------------------------------------------
titles = {'dx (mm)', 'dy (mm)', 'Alpha (mm/100mm)', 'Beta (mm/100mm)'};
figure('Color', 'w', 'Position', [50, 50, 1200, 800], 'Name', '绝对误差趋势');

for k = 1:4
    subplot(2, 2, k); hold on; grid on;
    plot(scan_vals, abs(Err_TPM_Lin(:, k)), 'r--', 'LineWidth', 1.5);
    plot(scan_vals, abs(Err_APM_Lin(:, k)), 'b-.', 'LineWidth', 1.5);
    plot(scan_vals, abs(Err_TPM_Iter(:, k)), 'm-', 'LineWidth', 2);
    plot(scan_vals, abs(Err_APM_Iter(:, k)), 'k:', 'LineWidth', 2);
    
    xlabel('Parallel Offset (mm)');
    ylabel('Abs Error');
    title(['Abs Error: ', titles{k}]);
    if k==1, legend('TPM Linear', 'APM Linear', 'TPM Iter', 'APM Iter'); end
end

%% 4. 相对误差
% -------------------------------------------------------------------------
figure('Color', 'w', 'Position', [100, 100, 1200, 800], 'Name', '相对误差趋势');

for k = 1:4
    subplot(2, 2, k); hold on; grid on;
    plot(scan_vals, RelErr_TPM_Lin(:, k), 'r--', 'LineWidth', 1.5);
    plot(scan_vals, RelErr_APM_Lin(:, k), 'b-.', 'LineWidth', 1.5);
    
    xlabel('Parallel Offset (mm)');
    ylabel('Relative Error (%)');
    title(['Rel Error: ', titles{k}]);
    ylim([0, 5]); 
    if k==1, legend('TPM Linear', 'APM Linear'); end
end

%% ========================================================================
function err_vec = calc_unit_error(Res, True)
    res_alpha = 100 * tand(Res.alpha);
    res_beta  = 100 * tand(Res.beta);
    err_vec = [Res.dx - True.dx, Res.dy - True.dy, ...
               res_alpha - True.alpha, res_beta - True.beta];
end

function Sol = solve_TPM_linear(Data, Geo)
    S90=Data(1); M90=Data(2); S180=Data(3); M180=Data(4); z1=Geo.z1; z2=Geo.z2;
    Sol.dy = (z1*M180 - z2*S180)/(2*(z1+z2));
    Sol.beta = atan(-(S180+M180)/(2*(z1+z2)))*180/pi;
    termS=S90-S180/2; termM=M90-M180/2;
    dx_raw = (z2*termS - z1*termM)/(z1+z2);
    alpha_rad = atan((S90+M90 - (S180+M180)/2)/(z1+z2));
    Sol.dx = -dx_raw; Sol.alpha = -alpha_rad*180/pi;
end
function Sol = solve_TPM_iterative(Init, Data, Geo, gamma)
    x = [Init.dx; Init.dy; Init.alpha; Init.beta]; Measured = Data(:);
    for k=1:5
        Mis.dx=x(1); Mis.dy=x(2); Mis.alpha=x(3); Mis.beta=x(4);
        [s90,m90]=get_readings(Geo,Mis,90,gamma); [s180,m180]=get_readings(Geo,Mis,180,gamma);
        Sim=[s90;m90;s180;m180]; Resid=Measured-Sim;
        if norm(Resid)<1e-9, break; end
        J=zeros(4,4); delta=1e-5;
        for p=1:4
            xt=x; xt(p)=xt(p)+delta; Mt.dx=xt(1); Mt.dy=xt(2); Mt.alpha=xt(3); Mt.beta=xt(4);
            [ts90,tm90]=get_readings(Geo,Mt,90,gamma); [ts180,tm180]=get_readings(Geo,Mt,180,gamma);
            J(:,p)=([ts90;tm90;ts180;tm180]-Sim)/delta;
        end
        x=x+J\Resid;
    end
    Sol.dx=x(1); Sol.dy=x(2); Sol.alpha=x(3); Sol.beta=x(4);
end
function Sol = solve_APM_linear(As, Bs, Am, Bm, Geo)
    z1=Geo.z1; z2=Geo.z2;
    ar=(As+Am)/(z1+z2); dx=(z2*As-z1*Am)/(z1+z2);
    br=(Bs+Bm)/(z1+z2); dy=(z2*Bs-z1*Bm)/(z1+z2);
    Sol.dx=-dx; Sol.alpha=-ar*180/pi; Sol.dy=dy; Sol.beta=br*180/pi;
end
function Sol = solve_APM_iterative(Init, Ang, S, M, Geo, gamma)
    x=[Init.dx;Init.dy;Init.alpha;Init.beta]; Meas=[S;M]; N=length(Ang);
    for k=1:5
        Mis.dx=x(1); Mis.dy=x(2); Mis.alpha=x(3); Mis.beta=x(4);
        SS=zeros(N,1); MM=zeros(N,1);
        for j=1:N, [SS(j),MM(j)]=get_readings(Geo,Mis,Ang(j),gamma); end
        Sim=[SS;MM]; Resid=Meas-Sim;
        if norm(Resid)<1e-9, break; end
        J=zeros(2*N,4); delta=1e-5;
        for p=1:4
            xt=x; xt(p)=xt(p)+delta; Mt.dx=xt(1); Mt.dy=xt(2); Mt.alpha=xt(3); Mt.beta=xt(4);
            St=zeros(N,1); Mt_=zeros(N,1);
            for j=1:N, [St(j),Mt_(j)]=get_readings(Geo,Mt,Ang(j),gamma); end
            J(:,p)=([St;Mt_]-Sim)/delta;
        end
        x=x+(J'*J)\(J'*Resid);
    end
    Sol.dx=x(1); Sol.dy=x(2); Sol.alpha=x(3); Sol.beta=x(4);
end
function [A,B,C]=fit_sine_wave(t,r), rad=t*pi/180; X=[sin(rad(:)),cos(rad(:)),ones(length(rad),1)]; P=X\r(:); A=P(1); B=P(2); C=P(3); end
function [r_s,r_m]=get_readings(G,M,t,g), S=get_system_state(G,M,t,g); [~,r_s]=get_line_plane_inter(S.S.PSD_center,S.S.Read_Vec,S.M.LD_pos,S.M.Laser_Norm); [~,r_m]=get_line_plane_inter(S.M.PSD_center,S.M.Read_Vec,S.S.LD_pos,S.S.Laser_Norm); end
function S=get_system_state(G,M,t,g), th=t*pi/180; ga=g*pi/180; Rz=[cos(th) -sin(th) 0; sin(th) cos(th) 0; 0 0 1]; PS=[0;G.H_S_PSD;-G.z1]; LS=[0;G.H_S_LD;-G.z1]; S.S.PSD_center=Rz*PS; S.S.LD_pos=Rz*LS; S.S.Read_Vec=Rz*[0;1;0]; S.S.Laser_Norm=Rz*[0;1;0]; PM=[0;G.H_M_PSD;G.z2]; LM=[0;G.H_M_LD;G.z2]; nM=[0;cos(ga);-sin(ga)]; TM=get_M_transform(M.dx,M.dy,M.alpha,M.beta); RM=TM(1:3,1:3); S.M.PSD_center=apply_transform(TM,Rz*PM); S.M.LD_pos=apply_transform(TM,Rz*LM); S.M.Read_Vec=RM*(Rz*[0;1;0]); S.M.Laser_Norm=RM*(Rz*nM); end
function T=get_M_transform(x,y,a,b), a=-a*pi/180; b=b*pi/180; Ry=[cos(a) 0 sin(a);0 1 0;-sin(a) 0 cos(a)]; Rx=[1 0 0;0 cos(b) -sin(b);0 sin(b) cos(b)]; T=eye(4); T(1:3,1:3)=Ry*Rx; T(1:3,4)=[x;y;0]; end
function [p,d]=get_line_plane_inter(Lp,Lv,Pp,Pn), u=Lv/norm(Lv); n=Pn/norm(Pn); w=Lp-Pp; D=dot(n,u); N=-dot(n,w); if abs(D)<1e-8, p=[NaN;NaN;NaN]; d=NaN; else, s=N/D; p=Lp+s*u; d=s; end; end
function P=apply_transform(T,p), P=T*[p;ones(1,size(p,2))]; P=P(1:3,:); end
function [G,g,r]=run_calibration_logic(G,M), dS=G.H_S_PSD-G.H_S_LD; cS=@(h)grw(h,dS,G,M,0,'M'); try h=fzero(cS,G.H_S_PSD); catch, h=G.H_S_PSD; end; G.H_S_PSD=h; G.H_S_LD=h-dS; cM=@(x)grwg(x,G,M,'S'); try g=fzero(cM,0); catch, g=0; end; r=0; end
function v=grw(h,d,G,M,g,tg), G.H_S_PSD=h; G.H_S_LD=h-d; [rs,rm]=get_readings(G,M,0,g); if strcmp(tg,'M'), v=rm; else, v=rs; end; end
function v=grwg(g,G,M,tg), [rs,rm]=get_readings(G,M,0,g); if strcmp(tg,'M'), v=rm; else, v=rs; end; end