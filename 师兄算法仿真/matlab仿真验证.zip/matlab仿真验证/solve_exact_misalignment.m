function Solution = solve_exact_misalignment(Geo, Measured_Readings)
    S90_meas  = Measured_Readings(1);
    M90_meas  = Measured_Readings(2);
    S180_meas = Measured_Readings(3);
    M180_meas = Measured_Readings(4);
    
    z1 = Geo.z1; z2 = Geo.z2;

    x_current = [calc_dx, calc_dy, calc_alpha, calc_beta];

    tolerance = 1e-6; % 目标精度
    max_iter = 10;    % 最大迭代次数
    
    for k = 1:max_iter
        Mis_guess.dx = x_current(1);
        Mis_guess.dy = x_current(2);
        Mis_guess.alpha = x_current(3);
        Mis_guess.beta  = x_current(4);
        
        [s90_sim, m90_sim]   = get_readings_fast(Geo, Mis_guess, 90);
        [s180_sim, m180_sim] = get_readings_fast(Geo, Mis_guess, 180);
        
        % 计算残差
        residuals = [S90_meas  - s90_sim;
                     M90_meas  - m90_sim;
                     S180_meas - s180_sim;
                     M180_meas - m180_sim];
                     
        if norm(residuals) < tolerance
            break; 
        end
        
        delta = 1e-4;
        J = zeros(4, 4);
        
        for i = 1:4
            x_temp = x_current;
            x_temp(i) = x_temp(i) + delta; 
            Mis_temp.dx = x_temp(1); Mis_temp.dy = x_temp(2);
            Mis_temp.alpha = x_temp(3); Mis_temp.beta = x_temp(4);
            
            [ts90, tm90]   = get_readings_fast(Geo, Mis_temp, 90);
            [ts180, tm180] = get_readings_fast(Geo, Mis_temp, 180);
            readings_temp = [ts90; tm90; ts180; tm180];
            
            current_sim_readings = [s90_sim; m90_sim; s180_sim; m180_sim];
            
            J(:, i) = (readings_temp - current_sim_readings) / delta;
        end

        delta_x = J \ residuals; 
        x_current = x_current + delta_x';
    end
    
    Solution.dx = x_current(1);
    Solution.dy = x_current(2);
    Solution.alpha = x_current(3);
    Solution.beta  = x_current(4);
end

function [rs, rm] = get_readings_fast(Geo, Mis, theta)
    S = get_system_state(Geo, Mis, theta, 0); 
    [~, rs] = get_line_plane_inter(S.S.PSD_center, S.S.Read_Vec, S.M.LD_pos, S.M.Laser_Norm);
    [~, rm] = get_line_plane_inter(S.M.PSD_center, S.M.Read_Vec, S.S.LD_pos, S.S.Laser_Norm);
end