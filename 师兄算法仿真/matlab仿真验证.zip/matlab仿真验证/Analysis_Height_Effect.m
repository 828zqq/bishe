%% Analysis_Height_Effect.m

clc; clear; close all; format long g;

%% 1. 基础参数设定

True_Val_Unit.dx = -3.5;       
True_Val_Unit.dy = 2;       
True_Val_Unit.alpha = 2.5; 
True_Val_Unit.beta  = 3;  

True_Val_Phys.dx = True_Val_Unit.dx;
True_Val_Phys.dy = True_Val_Unit.dy;
True_Val_Phys.alpha = atand(True_Val_Unit.alpha / 100);
True_Val_Phys.beta  = atand(True_Val_Unit.beta / 100);


Geo.z1 = 200; 
Geo.z2 = 200;
diff_H = 20;  

h_range = 30 : 2 : 300;
num_steps = length(h_range);


Err_Abs_TPM_Lin = zeros(num_steps, 4);
Err_Abs_TPM_Iter = zeros(num_steps, 4);
Err_Abs_APM_Lin = zeros(num_steps, 4);
Err_Abs_APM_Iter = zeros(num_steps, 4);

Err_Rel_TPM_Lin = zeros(num_steps, 4);

APM_Angles = [45, 90, 135, 180, 225, 270, 315, 350]; 

fprintf('开始高度敏感性扫描 (H: 30mm -> 1000mm)...\n');
wb = waitbar(0, '正在计算...');

%% 2. 循环扫描
for i = 1:num_steps
    h_curr = h_range(i);
    waitbar(i/num_steps, wb, sprintf('H = %d mm', h_curr));
    
    Geo.H_M_LD = h_curr;
    Geo.H_M_PSD = h_curr - diff_H;
    
    Geo.H_S_PSD = h_curr + 10; 
    Geo.H_S_LD  = Geo.H_S_PSD - diff_H;
    
    [Geo_Calib, gamma_calib, ~] = run_calibration_logic(Geo, True_Val_Phys);

    [s90, m90]   = get_readings(Geo_Calib, True_Val_Phys, 90, gamma_calib);
    [s180, m180] = get_readings(Geo_Calib, True_Val_Phys, 180, gamma_calib);
    TPM_Data = [s90, m90, s180, m180];

    APM_S = zeros(8, 1); APM_M = zeros(8, 1);
    for k = 1:8
        [APM_S(k), APM_M(k)] = get_readings(Geo_Calib, True_Val_Phys, APM_Angles(k), gamma_calib);
    end
    
    Res_TPM_Lin  = solve_TPM_linear(TPM_Data, Geo);
    Res_TPM_Iter = solve_TPM_iterative(Res_TPM_Lin, TPM_Data, Geo_Calib, gamma_calib);
    
    [As, Bs, Cs] = fit_sine_wave(APM_Angles, APM_S);
    [Am, Bm, Cm] = fit_sine_wave(APM_Angles, APM_M);
    Res_APM_Lin  = solve_APM_linear(As, Bs, Am, Bm, Geo);
    Res_APM_Iter = solve_APM_iterative(Res_APM_Lin, APM_Angles, APM_S, APM_M, Geo_Calib, gamma_calib);
    
    % --- 误差计算 ---
    % 1. 绝对误差
    Err_Abs_TPM_Lin(i, :)  = abs(calc_unit_error(Res_TPM_Lin, True_Val_Unit));
    Err_Abs_TPM_Iter(i, :) = abs(calc_unit_error(Res_TPM_Iter, True_Val_Unit));
    Err_Abs_APM_Lin(i, :)  = abs(calc_unit_error(Res_APM_Lin, True_Val_Unit));
    Err_Abs_APM_Iter(i, :) = abs(calc_unit_error(Res_APM_Iter, True_Val_Unit));
    
    % 2. 相对误差 (%) = |AbsErr / TrueVal| * 100
    true_vec = [True_Val_Unit.dx, True_Val_Unit.dy, True_Val_Unit.alpha, True_Val_Unit.beta];
    Err_Rel_TPM_Lin(i, :) = (Err_Abs_TPM_Lin(i, :) ./ abs(true_vec)) * 100;
    Err_Rel_APM_Lin(i, :) = (Err_Abs_APM_Lin(i, :) ./ abs(true_vec)) * 100;
    Err_Rel_TPM_Iter(i, :) = (Err_Abs_TPM_Iter(i, :) ./ abs(true_vec)) * 100;
    Err_Rel_APM_Iter(i, :) = (Err_Abs_APM_Iter(i, :) ./ abs(true_vec)) * 100;
end
close(wb);

%% 3.绝对误差
% -------------------------------------------------------------------------
param_names = {'dx (mm)', 'dy (mm)', 'Alpha (mm/100mm)', 'Beta (mm/100mm)'};

figure('Color', 'w', 'Position', [50, 50, 1200, 700], 'Name', 'Absolute Error vs Height');
sgtitle('Impact of Structure Height (H\_M\_LD) on Absolute Error', 'FontSize', 14);

for k = 1:4
    subplot(2, 2, k); hold on; grid on;
    plot(h_range, Err_Abs_TPM_Lin(:, k), 'r--', 'LineWidth', 1.5);
    plot(h_range, Err_Abs_APM_Lin(:, k), 'b-.', 'LineWidth', 1.5);
    plot(h_range, Err_Abs_TPM_Iter(:, k), 'm-', 'LineWidth', 2); 
    plot(h_range, Err_Abs_APM_Iter(:, k), 'k:', 'LineWidth', 2);
    
    xlabel('Height H\_M\_LD (mm)');
    ylabel(['Abs Error (' param_names{k} ')']);
    title(param_names{k});
    if k==1, legend('TPM Lin', 'APM Lin', 'TPM Iter', 'APM Iter'); end
end

%% 4.相对误差
% -------------------------------------------------------------------------
figure('Color', 'w', 'Position',[50, 50, 1200, 700], 'Name', 'Relative Error vs Height');
sgtitle('Impact of Structure Height (H\_M\_LD) on Relative Error (%)', 'FontSize', 14);

for k = 1:4
    subplot(2, 2, k); hold on; grid on;
    plot(h_range, Err_Rel_TPM_Lin(:, k), 'r--', 'LineWidth', 1.5);
    plot(h_range, Err_Rel_APM_Lin(:, k), 'b-.', 'LineWidth', 1.5);
    plot(h_range, Err_Rel_TPM_Iter(:, k), 'm-', 'LineWidth', 2); 
    plot(h_range, Err_Rel_APM_Iter(:, k), 'k:', 'LineWidth', 2);
    
    xlabel('Height H\_M\_LD (mm)');
    ylabel('Relative Error (%)');
    title(param_names{k});
    if k==1, legend('TPM Linear', 'APM Linear','TPM Iter', 'APM Iter'); end
end

%% ========================================================================
function err_vec = calc_unit_error(Res, True)
    res_alpha = 100 * tand(Res.alpha);
    res_beta  = 100 * tand(Res.beta);
    err_vec = [Res.dx-True.dx, Res.dy-True.dy, res_alpha-True.alpha, res_beta-True.beta];
end

% --- TPM 线性 ---
function Sol = solve_TPM_linear(Data, Geo)
    S90=Data(1); M90=Data(2); S180=Data(3); M180=Data(4);
    z1=Geo.z1; z2=Geo.z2;
    Sol.dy = (z1*M180 - z2*S180)/(2*(z1+z2));
    Sol.beta = atan(-(S180+M180)/(2*(z1+z2)))*180/pi;
    termS = S90 - S180/2; termM = M90 - M180/2;
    Sol.dx = -(z2*termS - z1*termM)/(z1+z2); 
    Sol.alpha = -atan((S90+M90 - (S180+M180)/2)/(z1+z2))*180/pi;
end
% --- TPM 迭代 ---
function Sol = solve_TPM_iterative(Init, Data, Geo, gamma)
    x = [Init.dx; Init.dy; Init.alpha; Init.beta]; Measured = Data(:);
    for k=1:5
        M.dx=x(1); M.dy=x(2); M.alpha=x(3); M.beta=x(4);
        [s90,m90]=get_readings(Geo,M,90,gamma); [s180,m180]=get_readings(Geo,M,180,gamma);
        Resid = Measured - [s90;m90;s180;m180];
        if norm(Resid)<1e-9, break; end
        J=zeros(4,4); d=1e-5;
        for p=1:4
            xt=x; xt(p)=xt(p)+d; Mt=M; Mt.dx=xt(1); Mt.dy=xt(2); Mt.alpha=xt(3); Mt.beta=xt(4);
            [t1,t2]=get_readings(Geo,Mt,90,gamma); [t3,t4]=get_readings(Geo,Mt,180,gamma);
            J(:,p)=([t1;t2;t3;t4]-[s90;m90;s180;m180])/d;
        end
        x = x + J\Resid;
    end
    Sol.dx=x(1); Sol.dy=x(2); Sol.alpha=x(3); Sol.beta=x(4);
end
% --- APM 线性 ---
function Sol = solve_APM_linear(As, Bs, Am, Bm, Geo)
    z1=Geo.z1; z2=Geo.z2;
    Sol.dx = -(z2*As - z1*Am)/(z1+z2); 
    Sol.alpha = -(As+Am)/(z1+z2)*180/pi;
    Sol.dy = (z2*Bs - z1*Bm)/(z1+z2); 
    Sol.beta = (Bs+Bm)/(z1+z2)*180/pi;
end
% --- APM 迭代 ---
function Sol = solve_APM_iterative(Init, Ang, S_m, M_m, Geo, gamma)
    x=[Init.dx; Init.dy; Init.alpha; Init.beta]; Meas=[S_m;M_m]; N=length(Ang);
    for k=1:5
        M.dx=x(1); M.dy=x(2); M.alpha=x(3); M.beta=x(4);
        SimS=zeros(N,1); SimM=zeros(N,1);
        for j=1:N, [SimS(j),SimM(j)]=get_readings(Geo,M,Ang(j),gamma); end
        Resid = Meas - [SimS;SimM];
        if norm(Resid)<1e-9, break; end
        J=zeros(2*N,4); d=1e-5;
        for p=1:4
            xt=x; xt(p)=xt(p)+d; Mt=M; Mt.dx=xt(1); Mt.dy=xt(2); Mt.alpha=xt(3); Mt.beta=xt(4);
            St=zeros(N,1); Mt_=zeros(N,1);
            for j=1:N, [St(j),Mt_(j)]=get_readings(Geo,Mt,Ang(j),gamma); end
            J(:,p)=([St;Mt_]-[SimS;SimM])/d;
        end
        x = x + (J'*J)\(J'*Resid);
    end
    Sol.dx=x(1); Sol.dy=x(2); Sol.alpha=x(3); Sol.beta=x(4);
end
% --- 辅助函数 ---
function [A,B,C]=fit_sine_wave(t,r), X=[sin(t(:)*pi/180), cos(t(:)*pi/180), ones(length(t),1)]; P=X\r(:); A=P(1); B=P(2); C=P(3); end
function [rs,rm]=get_readings(G,M,t,gam), S=get_state(G,M,t,gam); [~,rs]=glpi(S.S.PSD_center,S.S.Read_Vec,S.M.LD_pos,S.M.Laser_Norm); [~,rm]=glpi(S.M.PSD_center,S.M.Read_Vec,S.S.LD_pos,S.S.Laser_Norm); end
function S=get_state(G,M,t,gam)
    th=t*pi/180; ga=gam*pi/180; Rz=[cos(th) -sin(th) 0; sin(th) cos(th) 0; 0 0 1];
    S.S.PSD_center=Rz*[0;G.H_S_PSD;-G.z1]; S.S.LD_pos=Rz*[0;G.H_S_LD;-G.z1];
    S.S.Read_Vec=Rz*[0;1;0]; S.S.Laser_Norm=Rz*[0;1;0];
    T=get_T(M.dx,M.dy,M.alpha,M.beta); RM=T(1:3,1:3);
    S.M.PSD_center=apt(T,Rz*[0;G.H_M_PSD;G.z2]); S.M.LD_pos=apt(T,Rz*[0;G.H_M_LD;G.z2]);
    S.M.Read_Vec=RM*(Rz*[0;1;0]); S.M.Laser_Norm=RM*(Rz*[0;cos(ga);-sin(ga)]);
end
function T=get_T(dx,dy,a,b), a=-a*pi/180; b=b*pi/180; T=eye(4); T(1:3,1:3)=[cos(a) 0 sin(a);0 1 0;-sin(a) 0 cos(a)]*[1 0 0;0 cos(b) -sin(b);0 sin(b) cos(b)]; T(1:3,4)=[dx;dy;0]; end
function [p,d]=glpi(Lp,Lv,Pp,Pn), u=Lv/norm(Lv); n=Pn/norm(Pn); w=Lp-Pp; D=dot(n,u); if abs(D)<1e-8, p=[nan;nan;nan];d=nan; else, s=-dot(n,w)/D; p=Lp+s*u; d=s; end; end
function P=apt(T,L), P=T*[L;ones(1,size(L,2))]; P=P(1:3,:); end
function [G,g,r]=run_calibration_logic(G,M), df=G.H_S_PSD-G.H_S_LD; cS=@(h)grw(h,df,G,M,0,'M'); try hn=fzero(cS,G.H_S_PSD);catch,hn=G.H_S_PSD;end; G.H_S_PSD=hn;G.H_S_LD=hn-df; cM=@(g)grwg(g,G,M,'S'); try g=fzero(cM,0);catch,g=0;end; r=0; end
function v=grw(h,df,G,M,g,tg), G.H_S_PSD=h; G.H_S_LD=h-df; [rs,rm]=get_readings(G,M,0,g); if strcmp(tg,'M'),v=rm;else,v=rs;end; end
function v=grwg(g,G,M,tg), [rs,rm]=get_readings(G,M,0,g); if strcmp(tg,'M'),v=rm;else,v=rs;end; end