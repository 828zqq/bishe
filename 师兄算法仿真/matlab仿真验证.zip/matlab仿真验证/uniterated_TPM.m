clc; clear; format long g;
%% 1. 基础参数设定
Geo.z1 = 300;          
Geo.z2 = 300;          

Geo.H_S_PSD = 80;      
diff_H = 20;           
Geo.H_S_LD  = Geo.H_S_PSD - diff_H; 

Geo.H_M_LD = 70;       
Geo.H_M_PSD = Geo.H_M_LD - diff_H; 


True_Val.dx = 1.25;     
True_Val.dy = 0.9;     
True_Val.alpha = -1.5;   
True_Val.beta  = 1.5; 

Misalign = True_Val;

fprintf('======================================================\n');
fprintf('1. 仿真环境初始化...\n');
fprintf('   设定真值: dx=%.4f, dy=%.4f, alpha=%.4f, beta=%.4f\n', ...
    True_Val.dx, True_Val.dy, True_Val.alpha, True_Val.beta);

%% 2. 运行仿真 (校准 + 测量)

[Geo_Calib, gamma_calib, ~] = run_calibration_logic(Geo, Misalign);

[S90, M90]   = get_readings(Geo_Calib, Misalign, 90, gamma_calib);
[S180, M180] = get_readings(Geo_Calib, Misalign, 180, gamma_calib);

fprintf('2. 仿真测量数据 (Simulated Sensor Readings):\n');
fprintf('   S90  = %10.6f mm\n', S90);
fprintf('   M90  = %10.6f mm\n', M90);
fprintf('   S180 = %10.6f mm\n', S180);
fprintf('   M180 = %10.6f mm\n', M180);

%% 3. 算法解算 

z1 = Geo.z1;
z2 = Geo.z2;

calc_dy = (z1 * M180 - z2 * S180) / (2 * (z1 + z2));

beta_term = - (S180 + M180) / (2 * (z1 + z2));
calc_beta_rad = atan(beta_term);
calc_beta_deg = calc_beta_rad * (180/pi); 

term_S = S90 - S180 / 2;
term_M = M90 - M180 / 2;
raw_dx = (z2 * term_S - z1 * term_M) / (z1 + z2);
calc_dx = -raw_dx; 

alpha_term = (S90 + M90 - (S180 + M180)/2) / (z1 + z2);
calc_alpha_rad = atan(alpha_term);
raw_alpha_deg = calc_alpha_rad * (180/pi);
calc_alpha_deg = -raw_alpha_deg;
%% 4. 误差分析 (Error Analysis)
fprintf('\n======================================================\n');
fprintf('3. 解算结果与误差分析 (Validation Report)\n');
fprintf('======================================================\n');
fprintf('%-10s | %-12s | %-12s | %-12s | %-10s\n', ...
    'Param', 'True Value', 'Calculated', 'Abs Error', 'Rel Error(%)');
fprintf('------------------------------------------------------\n');


print_error('dx (mm)', True_Val.dx, calc_dx);
print_error('dy (mm)', True_Val.dy, calc_dy);
print_error('alpha(deg)', True_Val.alpha, calc_alpha_deg);
print_error('beta (deg)', True_Val.beta, calc_beta_deg);
fprintf('======================================================\n');


%% ========================================================================
%  函数库
function print_error(name, true_val, calc_val)
    abs_err = calc_val - true_val;
    if abs(true_val) > 1e-9
        rel_err = (abs(abs_err) / abs(true_val)) * 100;
    else
        rel_err = 0;
    end
    fprintf('%-10s | %12.6f | %12.6f | %12.6f | %9.4f%%\n', ...
        name, true_val, calc_val, abs_err, rel_err);
end

function [r_s, r_m] = get_readings(Geo, Mis, theta_deg, gamma_deg)
    S = get_system_state(Geo, Mis, theta_deg, gamma_deg);
    [~, r_s] = get_line_plane_inter(S.S.PSD_center, S.S.Read_Vec, ...
                                    S.M.LD_pos, S.M.Laser_Norm);
    [~, r_m] = get_line_plane_inter(S.M.PSD_center, S.M.Read_Vec, ...
                                    S.S.LD_pos, S.S.Laser_Norm);
end

function S = get_system_state(Geo, Mis, theta_deg, gamma_deg)
    theta = theta_deg * pi / 180;
    gamma = gamma_deg * pi / 180;
    Rz = [cos(theta), -sin(theta), 0; sin(theta), cos(theta), 0; 0, 0, 1];


    P_S0 = [0; Geo.H_S_PSD; -Geo.z1];
    L_S0 = [0; Geo.H_S_LD;  -Geo.z1];
    S.S.PSD_center = Rz * P_S0;
    S.S.LD_pos     = Rz * L_S0;
    S.S.Read_Vec   = Rz * [0; 1; 0];
    S.S.Laser_Norm = Rz * [0; 1; 0];


    P_M0 = [0; Geo.H_M_PSD; Geo.z2];
    L_M0 = [0; Geo.H_M_LD;  Geo.z2];
    n_M0 = [0; cos(gamma); -sin(gamma)];
    
    P_M_rot = Rz * P_M0; L_M_rot = Rz * L_M0;
    v_M_rot = Rz * [0; 1; 0]; n_M_rot = Rz * n_M0;
    
    T_M = get_M_transform(Mis.dx, Mis.dy, Mis.alpha, Mis.beta);
    RM  = T_M(1:3, 1:3);
    
    S.M.PSD_center = apply_transform(T_M, P_M_rot);
    S.M.LD_pos     = apply_transform(T_M, L_M_rot);
    S.M.Read_Vec   = RM * v_M_rot;
    S.M.Laser_Norm = RM * n_M_rot;
end

function T = get_M_transform(dx, dy, alpha_deg, beta_deg)
    alp = -alpha_deg * pi / 180; % 注意alpha取反
    bet = beta_deg * pi / 180;
    Ry = [cos(alp), 0, sin(alp); 0, 1, 0; -sin(alp), 0, cos(alp)];
    Rx = [1, 0, 0; 0, cos(bet), -sin(bet); 0, sin(bet), cos(bet)];
    T = eye(4); T(1:3, 1:3) = Ry * Rx; T(1:3, 4) = [dx; dy; 0];
end

function [pt, dist] = get_line_plane_inter(L_pt, L_vec, P_pt, P_norm)
    u = L_vec / norm(L_vec); n = P_norm / norm(P_norm);
    w = L_pt - P_pt; D = dot(n, u); N = -dot(n, w);
    if abs(D) < 1e-8, pt = [NaN;NaN;NaN]; dist = NaN; else, sI = N / D; pt = L_pt + sI * u; dist = sI; end
end
function Pg = apply_transform(T, Pl), Pg = T * [Pl; ones(1, size(Pl, 2))]; Pg = Pg(1:3, :); end

function [Geo_out, gamma_out, res] = run_calibration_logic(Geo, Misalign)
    diff_S = Geo.H_S_PSD - Geo.H_S_LD;
    cost_S = @(h) calc_reading_single(h, diff_S, Geo, Misalign, 'M', 0);
    try h_new = fzero(cost_S, Geo.H_S_PSD); catch, h_new = Geo.H_S_PSD; end
    Geo_out = Geo; Geo_out.H_S_PSD = h_new; Geo_out.H_S_LD = h_new - diff_S;
    cost_M = @(g) calc_reading_single_gamma(g, Geo_out, Misalign, 'S');
    try gamma_out = fzero(cost_M, 0); catch, gamma_out = 0; end
    res = 0; 
end
function val = calc_reading_single(h, diff, Geo, Mis, target, g)
    Geo.H_S_PSD = h; Geo.H_S_LD = h - diff;
    [rs, rm] = get_readings(Geo, Mis, 0, g);
    if strcmp(target, 'M'), val = rm; else, val = rs; end
end
function val = calc_reading_single_gamma(g, Geo, Mis, target)
    [rs, rm] = get_readings(Geo, Mis, 0, g);
    if strcmp(target, 'M'), val = rm; else, val = rs; end
end