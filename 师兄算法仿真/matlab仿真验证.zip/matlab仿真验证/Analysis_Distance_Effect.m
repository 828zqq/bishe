%% Analysis_Distance_Effect.m
clc; clear; close all; format long g;

%% 1. 基础参数设定

Geo.H_M_LD = 50;      
diff_H = 20;           
Geo.H_M_PSD = Geo.H_M_LD - diff_H;
Geo.H_S_PSD = Geo.H_M_LD + 30; 
Geo.H_S_LD  = Geo.H_S_PSD - diff_H;

% 不对中真值
True_Val_Unit.dx = 0.5;      
True_Val_Unit.dy = -0.8;      
True_Val_Unit.alpha = -0.75; 
True_Val_Unit.beta  = 0.5; 

True_Val_Phys.dx = True_Val_Unit.dx;
True_Val_Phys.dy = True_Val_Unit.dy;
True_Val_Phys.alpha = atand(True_Val_Unit.alpha / 100);
True_Val_Phys.beta  = atand(True_Val_Unit.beta / 100);

% 扫描范围
z_range = 50 : 5 : 5000;
num_steps = length(z_range);

Err_Abs_TPM_Lin = zeros(num_steps, 4);
Err_Abs_TPM_Iter = zeros(num_steps, 4);
Err_Abs_APM_Lin = zeros(num_steps, 4);
Err_Abs_APM_Iter = zeros(num_steps, 4);

Err_Rel_TPM_Lin = zeros(num_steps, 4);
Err_Rel_TPM_Iter = zeros(num_steps, 4);
Err_Rel_APM_Lin = zeros(num_steps, 4);
Err_Rel_APM_Iter = zeros(num_steps, 4);

% APM 采样角度
APM_Angles = [45, 90, 135, 180, 225, 270, 315, 350]; 

fprintf('开始仿真扫描 (Z: 50mm -> 5000mm)...\n');
wb = waitbar(0, '正在进行距离敏感性分析...');

%% 2. 扫描
for i = 1:num_steps
    z_curr = z_range(i);
    waitbar(i/num_steps, wb, sprintf('计算中 Z = %d mm', z_curr));
    
    Geo.z1 = z_curr; Geo.z2 = z_curr;
    [Geo_Calib, gamma_calib, ~] = run_calibration_logic(Geo, True_Val_Phys);
    
    [s90, m90]   = get_readings(Geo_Calib, True_Val_Phys, 90, gamma_calib);
    [s180, m180] = get_readings(Geo_Calib, True_Val_Phys, 180, gamma_calib);
    TPM_Data = [s90, m90, s180, m180];
    
    APM_S = zeros(8, 1); APM_M = zeros(8, 1);
    for k = 1:8
        [APM_S(k), APM_M(k)] = get_readings(Geo_Calib, True_Val_Phys, APM_Angles(k), gamma_calib);
    end
    
    Res_TPM_Lin = solve_TPM_linear(TPM_Data, Geo);
    Res_TPM_Iter = solve_TPM_iterative(Res_TPM_Lin, TPM_Data, Geo_Calib, gamma_calib);
    
    [As, Bs, Cs] = fit_sine_wave(APM_Angles, APM_S);
    [Am, Bm, Cm] = fit_sine_wave(APM_Angles, APM_M);
    Res_APM_Lin = solve_APM_linear(As, Bs, Am, Bm, Geo);
    Res_APM_Iter = solve_APM_iterative(Res_APM_Lin, APM_Angles, APM_S, APM_M, Geo_Calib, gamma_calib);
    
    [Err_Abs_TPM_Lin(i, :), Err_Rel_TPM_Lin(i, :)]   = calc_errors(Res_TPM_Lin, True_Val_Unit);
    [Err_Abs_TPM_Iter(i, :), Err_Rel_TPM_Iter(i, :)] = calc_errors(Res_TPM_Iter, True_Val_Unit);
    [Err_Abs_APM_Lin(i, :), Err_Rel_APM_Lin(i, :)]   = calc_errors(Res_APM_Lin, True_Val_Unit);
    [Err_Abs_APM_Iter(i, :), Err_Rel_APM_Iter(i, :)] = calc_errors(Res_APM_Iter, True_Val_Unit);
end
close(wb);

%% 3.绝对误差
param_names = {'dx (mm)', 'dy (mm)', 'Alpha (mm/100mm)', 'Beta (mm/100mm)'};
figure('Color', 'w', 'Position', [50, 100, 1200, 800], 'Name', 'Absolute Error Analysis');

for k = 1:4
    subplot(2, 2, k); hold on; grid on;
    plot(z_range, abs(Err_Abs_TPM_Lin(:, k)), 'r--', 'LineWidth', 1.5);
    plot(z_range, abs(Err_Abs_APM_Lin(:, k)), 'b-.', 'LineWidth', 1.5);
    plot(z_range, abs(Err_Abs_TPM_Iter(:, k)), 'm-', 'LineWidth', 2); 
    plot(z_range, abs(Err_Abs_APM_Iter(:, k)), 'k:', 'LineWidth', 2);
    
    xlabel('Align Distance z1=z2 (mm)');
    ylabel(['Abs Error of ', param_names{k}]);
    title(['[Abs Error] ', param_names{k}]);
    
    if k == 1
        legend('TPM Linear', 'APM Linear', 'TPM Iter', 'APM Iter', 'Location', 'best');
    end
end

%% 4.相对误差
figure('Color', 'w', 'Position', [150, 100, 1200, 800], 'Name', 'Relative Error Analysis');

for k = 1:4
    subplot(2, 2, k); hold on; grid on;

    plot(z_range, abs(Err_Rel_TPM_Lin(:, k)), 'r--', 'LineWidth', 1.5);
    plot(z_range, abs(Err_Rel_APM_Lin(:, k)), 'b-.', 'LineWidth', 1.5);
    plot(z_range, abs(Err_Rel_TPM_Iter(:, k)), 'm-', 'LineWidth', 2); 
    plot(z_range, abs(Err_Rel_APM_Iter(:, k)), 'k:', 'LineWidth', 2);
    
    xlabel('Align Distance z1=z2 (mm)');
    ylabel(['Relative Error of ', param_names{k}, ' (%)']);
    title(['[Relative Error] ', param_names{k}]);
    
    if k == 1
        legend('TPM Linear', 'APM Linear', 'TPM Iter', 'APM Iter', 'Location', 'best');
    end
end

%% ========================================================================
%  函数库

function [abs_err, rel_err] = calc_errors(Res, True)
    res_alpha_unit = 100 * tand(Res.alpha);
    res_beta_unit  = 100 * tand(Res.beta);
    
    vals_calc = [Res.dx, Res.dy, res_alpha_unit, res_beta_unit];
    vals_true = [True.dx, True.dy, True.alpha, True.beta];
    
    abs_err = vals_calc - vals_true;
    rel_err = (abs(abs_err) ./ abs(vals_true)) * 100; % 百分比
end

% --- TPM 线性解算 ---
function Sol = solve_TPM_linear(Data, Geo)
    S90=Data(1); M90=Data(2); S180=Data(3); M180=Data(4);
    z1=Geo.z1; z2=Geo.z2;
    
    Sol.dy = (z1*M180 - z2*S180) / (2*(z1+z2));
    beta_rad = atan( -(S180+M180)/(2*(z1+z2)) );
    Sol.beta = beta_rad * 180/pi;
    
    termS = S90 - S180/2;
    termM = M90 - M180/2;
    dx_raw = (z2*termS - z1*termM)/(z1+z2);
    alpha_rad = atan( (S90+M90 - (S180+M180)/2)/(z1+z2) );
    
    Sol.dx = -dx_raw; 
    Sol.alpha = -alpha_rad * 180/pi;
end

% --- TPM 迭代解算 ---
function Sol = solve_TPM_iterative(Init, Data, Geo, gamma)
    x = [Init.dx; Init.dy; Init.alpha; Init.beta];
    Measured = Data(:); 
    for k = 1:5 
        Mis.dx=x(1); Mis.dy=x(2); Mis.alpha=x(3); Mis.beta=x(4);
        [s90, m90] = get_readings(Geo, Mis, 90, gamma);
        [s180, m180] = get_readings(Geo, Mis, 180, gamma);
        Sim = [s90; m90; s180; m180];
        Resid = Measured - Sim;
        if norm(Resid)<1e-9, break; end
        J = zeros(4,4); delta=1e-5;
        for p=1:4
            xt = x; xt(p)=xt(p)+delta;
            Mt.dx=xt(1); Mt.dy=xt(2); Mt.alpha=xt(3); Mt.beta=xt(4);
            [ts90, tm90] = get_readings(Geo, Mt, 90, gamma);
            [ts180, tm180] = get_readings(Geo, Mt, 180, gamma);
            J(:,p) = ([ts90; tm90; ts180; tm180] - Sim)/delta;
        end
        x = x + J \ Resid;
    end
    Sol.dx=x(1); Sol.dy=x(2); Sol.alpha=x(3); Sol.beta=x(4);
end

% --- APM 线性解算 ---
function Sol = solve_APM_linear(As, Bs, Am, Bm, Geo)
    z1=Geo.z1; z2=Geo.z2;
    alpha_rad = (As+Am)/(z1+z2);
    dx_raw    = (z2*As - z1*Am)/(z1+z2);
    beta_rad  = (Bs+Bm)/(z1+z2);
    dy_raw    = (z2*Bs - z1*Bm)/(z1+z2);
    Sol.dx = -dx_raw; Sol.alpha = -(alpha_rad*180/pi);
    Sol.dy = dy_raw; Sol.beta = beta_rad*180/pi;
end

% --- APM 迭代解算 ---
function Sol = solve_APM_iterative(Init, Angles, S_meas, M_meas, Geo, gamma)
    x = [Init.dx; Init.dy; Init.alpha; Init.beta];
    Measured = [S_meas; M_meas]; N = length(Angles);
    for k = 1:5
        Mis.dx=x(1); Mis.dy=x(2); Mis.alpha=x(3); Mis.beta=x(4);
        Sim_S=zeros(N,1); Sim_M=zeros(N,1);
        for j=1:N, [Sim_S(j), Sim_M(j)] = get_readings(Geo, Mis, Angles(j), gamma); end
        Sim = [Sim_S; Sim_M];
        Resid = Measured - Sim;
        if norm(Resid)<1e-9, break; end
        J = zeros(2*N, 4); delta=1e-5;
        for p=1:4
            xt = x; xt(p)=xt(p)+delta;
            Mt.dx=xt(1); Mt.dy=xt(2); Mt.alpha=xt(3); Mt.beta=xt(4);
            S_t=zeros(N,1); M_t=zeros(N,1);
            for j=1:N, [S_t(j), M_t(j)] = get_readings(Geo, Mt, Angles(j), gamma); end
            J(:,p) = ([S_t; M_t] - Sim)/delta;
        end
        x = x + (J'*J)\(J'*Resid);
    end
    Sol.dx=x(1); Sol.dy=x(2); Sol.alpha=x(3); Sol.beta=x(4);
end

% --- 拟合 ---
function [A, B, C] = fit_sine_wave(theta_deg, readings)
    rad = theta_deg * pi/180;
    X = [sin(rad(:)), cos(rad(:)), ones(length(rad),1)];
    P = X \ readings(:);
    A=P(1); B=P(2); C=P(3);
end

% --- 物理引擎---
function [r_s, r_m] = get_readings(Geo, Mis, theta_deg, gamma_deg)
    S = get_system_state(Geo, Mis, theta_deg, gamma_deg);
    [~, r_s] = get_line_plane_inter(S.S.PSD_center, S.S.Read_Vec, S.M.LD_pos, S.M.Laser_Norm);
    [~, r_m] = get_line_plane_inter(S.M.PSD_center, S.M.Read_Vec, S.S.LD_pos, S.S.Laser_Norm);
end
function S = get_system_state(Geo, Mis, theta_deg, gamma_deg)
    theta = theta_deg * pi/180; gamma = gamma_deg * pi/180;
    Rz = [cos(theta) -sin(theta) 0; sin(theta) cos(theta) 0; 0 0 1];
    P_S0 = [0; Geo.H_S_PSD; -Geo.z1]; L_S0 = [0; Geo.H_S_LD; -Geo.z1];
    S.S.PSD_center = Rz*P_S0; S.S.LD_pos = Rz*L_S0; 
    S.S.Read_Vec = Rz*[0;1;0]; S.S.Laser_Norm = Rz*[0;1;0];
    P_M0 = [0; Geo.H_M_PSD; Geo.z2]; L_M0 = [0; Geo.H_M_LD; Geo.z2];
    n_M0 = [0; cos(gamma); -sin(gamma)];
    T_M = get_M_transform(Mis.dx, Mis.dy, Mis.alpha, Mis.beta); RM = T_M(1:3,1:3);
    S.M.PSD_center = apply_transform(T_M, Rz*P_M0);
    S.M.LD_pos = apply_transform(T_M, Rz*L_M0);
    S.M.Read_Vec = RM*(Rz*[0;1;0]); S.M.Laser_Norm = RM*(Rz*n_M0);
end
function T = get_M_transform(dx, dy, a, b)
    a = -a * pi/180; b = b * pi/180; 
    Ry = [cos(a) 0 sin(a); 0 1 0; -sin(a) 0 cos(a)];
    Rx = [1 0 0; 0 cos(b) -sin(b); 0 sin(b) cos(b)];
    T = eye(4); T(1:3,1:3) = Ry*Rx; T(1:3,4) = [dx;dy;0];
end
function [pt, dist] = get_line_plane_inter(L_pt, L_vec, P_pt, P_norm)
    u = L_vec/norm(L_vec); n = P_norm/norm(P_norm); w = L_pt - P_pt;
    D = dot(n, u); N = -dot(n, w);
    if abs(D)<1e-8, pt=[NaN;NaN;NaN]; dist=NaN; else, sI=N/D; pt=L_pt+sI*u; dist=sI; end
end
function Pg = apply_transform(T, Pl), Pg = T*[Pl;ones(1,size(Pl,2))]; Pg=Pg(1:3,:); end
function [Geo, gamma, res] = run_calibration_logic(Geo, Mis)
    diff_S = Geo.H_S_PSD - Geo.H_S_LD;
    cost_S = @(h) get_readings_wrapper(h, diff_S, Geo, Mis, 0, 'M');
    try h_new = fzero(cost_S, Geo.H_S_PSD); catch, h_new = Geo.H_S_PSD; end
    Geo.H_S_PSD = h_new; Geo.H_S_LD = h_new - diff_S;
    cost_M = @(g) get_readings_wrapper_g(g, Geo, Mis, 'S');
    try gamma = fzero(cost_M, 0); catch, gamma=0; end
    res=0;
end
function val = get_readings_wrapper(h, diff, Geo, Mis, g, target)
    Geo.H_S_PSD = h; Geo.H_S_LD = h-diff;
    [rs, rm] = get_readings(Geo, Mis, 0, g);
    if strcmp(target,'M'), val=rm; else, val=rs; end
end
function val = get_readings_wrapper_g(g, Geo, Mis, target)
    [rs, rm] = get_readings(Geo, Mis, 0, g);
    if strcmp(target,'M'), val=rm; else, val=rs; end
end