function T = get_M_transform(dx, dy, alpha_deg, beta_deg)

    alp = alpha_deg * pi / 180;
    bet = beta_deg * pi / 180;
    
    Rx = [1, 0, 0;
          0, cos(bet), -sin(bet);
          0, sin(bet), cos(bet)];

    Ry = [cos(alp), 0, sin(alp);
          0, 1, 0;
          -sin(alp), 0, cos(alp)];
    
    % 组合旋转: R = Ry * Rx
    R = Ry * Rx;
 
    t = [dx; dy; 0]; 

    T = eye(4);
    T(1:3, 1:3) = R;
    T(1:3, 4) = t;
end