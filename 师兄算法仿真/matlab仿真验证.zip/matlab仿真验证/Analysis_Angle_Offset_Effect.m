%% Analysis_Angle_Effect.m
clc; clear; close all; format long g;

%% 1. 基础参数设定

Geo.z1 = 3000; 
Geo.z2 = 3000;
Geo.H_M_LD = 70; diff_H = 20;
Geo.H_M_PSD = Geo.H_M_LD - diff_H;
Geo.H_S_PSD = Geo.H_M_LD + 30; 
Geo.H_S_LD  = Geo.H_S_PSD - diff_H;

% 固定不对中量
Fixed_dx = 2.5; 
Fixed_dy = 3.0;

angle_range = -5 : 0.04 : 5;
num_steps = length(angle_range);


Abs_TPM_Lin = zeros(num_steps, 4); Rel_TPM_Lin = zeros(num_steps, 4);
Abs_TPM_Iter = zeros(num_steps, 4); Rel_TPM_Iter = zeros(num_steps, 4);
Abs_APM_Lin = zeros(num_steps, 4); Rel_APM_Lin = zeros(num_steps, 4);
Abs_APM_Iter = zeros(num_steps, 4); Rel_APM_Iter = zeros(num_steps, 4);

APM_Angles = [45, 90, 135, 180, 225, 270, 315, 350]; 

fprintf('开始角度扫描 (Range: -5 ~ +5 mm/100mm)...\n');
wb = waitbar(0, '正在进行角度敏感性分析...');

%% 2. 扫描
for i = 1:num_steps
    val_unit = angle_range(i); 
    waitbar(i/num_steps, wb, sprintf('Angle = %.2f', val_unit));
    
    True_Val_Unit.dx = Fixed_dx;
    True_Val_Unit.dy = Fixed_dy;
    True_Val_Unit.alpha = val_unit;
    True_Val_Unit.beta  = val_unit;

    True_Val_Phys = True_Val_Unit;
    True_Val_Phys.alpha = atand(val_unit / 100);
    True_Val_Phys.beta  = atand(val_unit / 100);

    [Geo_Calib, gamma_calib, ~] = run_calibration_logic(Geo, True_Val_Phys);
    
    [s90, m90]   = get_readings(Geo_Calib, True_Val_Phys, 90, gamma_calib);
    [s180, m180] = get_readings(Geo_Calib, True_Val_Phys, 180, gamma_calib);
    TPM_Data = [s90, m90, s180, m180];
    
    APM_S = zeros(8, 1); APM_M = zeros(8, 1);
    for k = 1:8
        [APM_S(k), APM_M(k)] = get_readings(Geo_Calib, True_Val_Phys, APM_Angles(k), gamma_calib);
    end
    
    Res_TPM_Lin = solve_TPM_linear(TPM_Data, Geo);
    Res_TPM_Iter = solve_TPM_iterative(Res_TPM_Lin, TPM_Data, Geo_Calib, gamma_calib);
    
    [As, Bs, Cs] = fit_sine_wave(APM_Angles, APM_S);
    [Am, Bm, Cm] = fit_sine_wave(APM_Angles, APM_M);
    Res_APM_Lin = solve_APM_linear(As, Bs, Am, Bm, Geo);
    Res_APM_Iter = solve_APM_iterative(Res_APM_Lin, APM_Angles, APM_S, APM_M, Geo_Calib, gamma_calib);
    
    %误差计算
    [Abs_TPM_Lin(i,:), Rel_TPM_Lin(i,:)]   = calc_errors(Res_TPM_Lin, True_Val_Unit);
    [Abs_TPM_Iter(i,:), Rel_TPM_Iter(i,:)] = calc_errors(Res_TPM_Iter, True_Val_Unit);
    [Abs_APM_Lin(i,:), Rel_APM_Lin(i,:)]   = calc_errors(Res_APM_Lin, True_Val_Unit);
    [Abs_APM_Iter(i,:), Rel_APM_Iter(i,:)] = calc_errors(Res_APM_Iter, True_Val_Unit);
end
close(wb);

%% 3. 绘图 - 绝对误差
param_names = {'dx (mm)', 'dy (mm)', 'Alpha (mm/100mm)', 'Beta (mm/100mm)'};
figure('Color', 'w', 'Position', [50, 50, 1200, 800], 'Name', 'Absolute Error vs Angle');

for k = 1:4
    subplot(2, 2, k); hold on; grid on;
    plot(angle_range, abs(Abs_TPM_Lin(:, k)), 'r--', 'LineWidth', 1.5);
    plot(angle_range, abs(Abs_APM_Lin(:, k)), 'b-.', 'LineWidth', 1.5);
    plot(angle_range, abs(Abs_TPM_Iter(:, k)), 'm-', 'LineWidth', 2);
    plot(angle_range, abs(Abs_APM_Iter(:, k)), 'k:', 'LineWidth', 2);
    
    xlabel('Angle (mm/100mm)'); ylabel('Abs Error');
    title(['Abs Error: ', param_names{k}]);
    if k==1, legend('TPM Lin', 'APM Lin', 'TPM Iter', 'APM Iter', 'Location','best'); end
end

%% 4. 绘图 - 相对误差
figure('Color', 'w', 'Position', [100, 100, 1200, 800], 'Name', 'Relative Error vs Angle');

for k = 1:4
    subplot(2, 2, k); hold on; grid on;
    plot(angle_range, Rel_TPM_Lin(:, k), 'r--', 'LineWidth', 1.5);
    plot(angle_range, Rel_APM_Lin(:, k), 'b-.', 'LineWidth', 1.5);
    plot(angle_range, Rel_TPM_Iter(:, k), 'm-', 'LineWidth', 2); 
    plot(angle_range, Rel_APM_Iter(:, k), 'k:', 'LineWidth', 2);
    
    xlabel('Angle (mm/100mm)'); ylabel('Relative Error (%)');
    title(['Rel Error: ', param_names{k}]);
    ylim([0, 5]);
end


%% ========================================================================
%  函数库

function [abs_err, rel_err] = calc_errors(Res, True)
    r_dx = Res.dx; r_dy = Res.dy;
    r_a = 100 * tand(Res.alpha);
    r_b = 100 * tand(Res.beta);
    
    vals_res = [r_dx, r_dy, r_a, r_b];
    vals_true = [True.dx, True.dy, True.alpha, True.beta];
    
    abs_err = vals_res - vals_true;

    rel_err = zeros(1, 4);
    for j = 1:4
        if abs(vals_true(j)) > 1e-6
            rel_err(j) = abs(abs_err(j)) / abs(vals_true(j)) * 100;
        else
            rel_err(j) = NaN;
        end
    end
end

function Sol = solve_TPM_linear(Data, Geo)
    S90=Data(1); M90=Data(2); S180=Data(3); M180=Data(4); z1=Geo.z1; z2=Geo.z2;
    Sol.dy = (z1*M180 - z2*S180)/(2*(z1+z2));
    Sol.beta = atan(-(S180+M180)/(2*(z1+z2)))*180/pi;
    termS=S90-S180/2; termM=M90-M180/2;
    Sol.dx = -(z2*termS - z1*termM)/(z1+z2);
    Sol.alpha = -atan((S90+M90-(S180+M180)/2)/(z1+z2))*180/pi;
end

function Sol = solve_APM_linear(As, Bs, Am, Bm, Geo)
    z1=Geo.z1; z2=Geo.z2;
    Sol.dx = -(z2*As - z1*Am)/(z1+z2);
    Sol.alpha = -((As+Am)/(z1+z2))*180/pi;
    Sol.dy = (z2*Bs - z1*Bm)/(z1+z2);
    Sol.beta = ((Bs+Bm)/(z1+z2))*180/pi;
end

function Sol = solve_TPM_iterative(Init, Data, Geo, gamma)
    x = [Init.dx; Init.dy; Init.alpha; Init.beta]; Measured=Data(:);
    for k=1:5
        [s90, m90] = get_readings(Geo, struct('dx',x(1),'dy',x(2),'alpha',x(3),'beta',x(4)), 90, gamma);
        [s180, m180] = get_readings(Geo, struct('dx',x(1),'dy',x(2),'alpha',x(3),'beta',x(4)), 180, gamma);
        Resid = Measured - [s90;m90;s180;m180];
        if norm(Resid)<1e-9, break; end
        J=zeros(4,4); d=1e-5;
        for p=1:4
            xt=x; xt(p)=xt(p)+d;
            [ts90, tm90] = get_readings(Geo, struct('dx',xt(1),'dy',xt(2),'alpha',xt(3),'beta',xt(4)), 90, gamma);
            [ts180, tm180] = get_readings(Geo, struct('dx',xt(1),'dy',xt(2),'alpha',xt(3),'beta',xt(4)), 180, gamma);
            J(:,p) = ([ts90;tm90;ts180;tm180] - [s90;m90;s180;m180])/d;
        end
        x = x + J\Resid;
    end
    Sol.dx=x(1); Sol.dy=x(2); Sol.alpha=x(3); Sol.beta=x(4);
end

function Sol = solve_APM_iterative(Init, Angs, S_m, M_m, Geo, gamma)
    x = [Init.dx; Init.dy; Init.alpha; Init.beta]; Meas=[S_m; M_m]; N=length(Angs);
    for k=1:5
        S_s=zeros(N,1); M_s=zeros(N,1);
        for j=1:N, [S_s(j), M_s(j)] = get_readings(Geo, struct('dx',x(1),'dy',x(2),'alpha',x(3),'beta',x(4)), Angs(j), gamma); end
        Resid = Meas - [S_s; M_s];
        if norm(Resid)<1e-9, break; end
        J=zeros(2*N,4); d=1e-5;
        for p=1:4
            xt=x; xt(p)=xt(p)+d; S_t=zeros(N,1); M_t=zeros(N,1);
            for j=1:N, [S_t(j), M_t(j)] = get_readings(Geo, struct('dx',xt(1),'dy',xt(2),'alpha',xt(3),'beta',xt(4)), Angs(j), gamma); end
            J(:,p) = ([S_t; M_t] - [S_s; M_s])/d;
        end
        x = x + (J'*J)\(J'*Resid);
    end
    Sol.dx=x(1); Sol.dy=x(2); Sol.alpha=x(3); Sol.beta=x(4);
end

function [A,B,C]=fit_sine_wave(t,r), rad=t*pi/180; X=[sin(rad(:)), cos(rad(:)), ones(length(rad),1)]; P=X\r(:); A=P(1); B=P(2); C=P(3); end

function [r_s, r_m] = get_readings(Geo, Mis, theta, gamma)
    S = get_sys(Geo, Mis, theta, gamma);
    [~, r_s] = get_int(S.S.PSD_center, S.S.Read_Vec, S.M.LD_pos, S.M.Laser_Norm);
    [~, r_m] = get_int(S.M.PSD_center, S.M.Read_Vec, S.S.LD_pos, S.S.Laser_Norm);
end
function S = get_sys(Geo, Mis, theta, gamma)
    t=theta*pi/180; g=gamma*pi/180;
    Rz=[cos(t) -sin(t) 0; sin(t) cos(t) 0; 0 0 1];
    S.S.PSD_center=Rz*[0;Geo.H_S_PSD;-Geo.z1]; S.S.LD_pos=Rz*[0;Geo.H_S_LD;-Geo.z1];
    S.S.Read_Vec=Rz*[0;1;0]; S.S.Laser_Norm=Rz*[0;1;0];
    T_M=get_Tm(Mis.dx, Mis.dy, Mis.alpha, Mis.beta); RM=T_M(1:3,1:3);
    S.M.PSD_center=app_T(T_M, Rz*[0;Geo.H_M_PSD;Geo.z2]);
    S.M.LD_pos=app_T(T_M, Rz*[0;Geo.H_M_LD;Geo.z2]);
    S.M.Read_Vec=RM*(Rz*[0;1;0]); S.M.Laser_Norm=RM*(Rz*[0;cos(g);-sin(g)]);
end
function T=get_Tm(dx,dy,a,b), a=-a*pi/180; b=b*pi/180; T=eye(4); 
    T(1:3,1:3)=[cos(a) 0 sin(a);0 1 0;-sin(a) 0 cos(a)]*[1 0 0;0 cos(b) -sin(b);0 sin(b) cos(b)]; T(1:3,4)=[dx;dy;0]; end
function [p,d]=get_int(lp,lv,pp,pn), u=lv/norm(lv); n=pn/norm(pn); w=lp-pp; D=dot(n,u); N=-dot(n,w);
    if abs(D)<1e-8, p=[NaN;NaN;NaN]; d=NaN; else, s=N/D; p=lp+s*u; d=s; end; end
function p=app_T(T,l), p=T*[l;ones(1,size(l,2))]; p=p(1:3,:); end
function [G,g,r]=run_calibration_logic(G,M), diff=G.H_S_PSD-G.H_S_LD;
    try h=fzero(@(h) cal_sub(h,diff,G,M,0,'M'), G.H_S_PSD); catch, h=G.H_S_PSD; end
    G.H_S_PSD=h; G.H_S_LD=h-diff;
    try g=fzero(@(ga) cal_sub_g(ga,G,M,'S'), 0); catch, g=0; end; r=0; end
function v=cal_sub(h,d,G,M,g,t), G.H_S_PSD=h; G.H_S_LD=h-d; [rs,rm]=get_readings(G,M,0,g); if t=='M',v=rm;else,v=rs;end; end
function v=cal_sub_g(g,G,M,t), [rs,rm]=get_readings(G,M,0,g); if t=='M',v=rm;else,v=rs;end; end