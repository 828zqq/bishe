clc; clear; close all;

%% 1. 基础参数设定
Geo.z1 = 150;          
Geo.z2 = 100;
Geo.H_S_PSD = 100;  
diff_H = 20;          
Geo.H_S_LD  = Geo.H_S_PSD - diff_H; 

Geo.H_M_LD = 100;      
Geo.H_M_PSD = Geo.H_M_LD - diff_H; 

Misalign.dx = 0;      
Misalign.dy = 10;      
Misalign.alpha = 0;  
Misalign.beta  = 5;   

%% 2. 执行校准
fprintf('正在执行自动校准...\n');
[Geo_Calib, gamma_calib, Residuals] = run_calibration_logic(Geo, Misalign);

fprintf('校准完成! \n');
fprintf('  -> 调整后的 S机 PSD高度: %.4f mm\n', Geo_Calib.H_S_PSD);
fprintf('  -> 计算出的 M机 补偿角 gamma: %.4f deg\n', gamma_calib);
fprintf('  -> 最终读数残差: S=%.2e, M=%.2e\n', Residuals(1), Residuals(2));

%% 3. 可视化绘图
State = get_system_state(Geo_Calib, Misalign, 0, gamma_calib);

figure('Color', 'w', 'Position', [50, 50, 1500, 500], 'Name', 'Calibrated System Visualization (Alpha Corrected)');

views_config = {
    [135, 30], '3D 视图';            
    [0, 0],    'YOZ 面 (主视)';      
    [0, 90],   'XOZ 面 (俯视)'       
};

for i = 1:3
    subplot(1, 3, i);
    hold on; grid on; axis equal;
    plot3(0,0,0, 'k+', 'MarkerSize', 10, 'LineWidth', 2);
    
    %% A. 绘制 S 机 (蓝色, Z负半轴)
    draw_mapped_line([0, 0, -Geo.z1-50], [0, 0, 0], 'b-.');
    draw_mapped_point(State.S.LD_pos, 'b', 's');
    draw_mapped_point(State.S.PSD_center, 'b', 'o');
    draw_mapped_segment(State.S.PSD_center, State.S.Read_Vec, 40, 'b');
    draw_mapped_plane(State.S.LD_pos, State.S.Laser_Norm, 120, [0, 0, 1]);
    
    %% B. 绘制 M 机 (红色, Z正半轴)
    T_M = get_M_transform(Misalign.dx, Misalign.dy, Misalign.alpha, Misalign.beta);
    P_start_M = apply_transform(T_M, [0; 0; 0]);
    P_end_M   = apply_transform(T_M, [0; 0; Geo.z2+50]);
    draw_mapped_line(P_start_M, P_end_M, 'r-.');
    
    draw_mapped_point(State.M.LD_pos, 'r', 's');
    draw_mapped_point(State.M.PSD_center, 'r', 'o');
    draw_mapped_segment(State.M.PSD_center, State.M.Read_Vec, 40, 'r');
    draw_mapped_plane(State.M.LD_pos, State.M.Laser_Norm, 120, [1, 0, 0]);
    
    %% C. 视图设置
    view(views_config{i, 1});
    title(views_config{i, 2}, 'FontSize', 12, 'FontWeight', 'bold');
    
    xlabel('Z (轴向)', 'FontSize', 11); 
    ylabel('X (水平)', 'FontSize', 11); 
    zlabel('Y (垂直)', 'FontSize', 11); 
    
    if i == 2 
        set(gca, 'YColor', 'none'); 
        ylabel([]);
    elseif i == 3 
        set(gca, 'ZColor', 'none');
        zlabel([]);
    end
    
    draw_user_axes_arrows(40);
    limit = max(Geo.z1, Geo.z2) + 80;
    xlim([-limit, limit]); ylim([-100, 100]); zlim([-100, 150]);
end

%% ========================================================================

function T = get_M_transform(dx, dy, alpha_deg, beta_deg)
    alp = -alpha_deg * pi / 180; 
    bet = beta_deg * pi / 180;

    Ry = [cos(alp), 0, sin(alp); 
          0,        1, 0; 
          -sin(alp),0, cos(alp)];

    Rx = [1, 0, 0; 
          0, cos(bet), -sin(bet); 
          0, sin(bet), cos(bet)];
          
    R = Ry * Rx; 
    t = [dx; dy; 0]; 
    T = eye(4); T(1:3, 1:3) = R; T(1:3, 4) = t;
end

%% --- 校准逻辑封装 ---
function [Geo_out, gamma_out, res] = run_calibration_logic(Geo, Misalign)
    diff_S = Geo.H_S_PSD - Geo.H_S_LD;
    cost_S = @(h) calc_reading_M(h, diff_S, Geo, Misalign);
    try h_new = fzero(cost_S, Geo.H_S_PSD); catch, h_new = Geo.H_S_PSD; end
    Geo_out = Geo;
    Geo_out.H_S_PSD = h_new;
    Geo_out.H_S_LD = h_new - diff_S;
    cost_M = @(g) calc_reading_S(g, Geo_out, Misalign);
    try gamma_out = fzero(cost_M, 0); catch, gamma_out = 0; end
    
    res = [cost_M(gamma_out), calc_reading_M(h_new, diff_S, Geo, Misalign)];
end

function r_m = calc_reading_M(h_s, diff, Geo, Mis)
    Geo.H_S_PSD = h_s; Geo.H_S_LD = h_s - diff;
    S = get_system_state(Geo, Mis, 0, 0);
    [~, r_m] = get_line_plane_inter(S.M.PSD_center, S.M.Read_Vec, S.S.LD_pos, S.S.Laser_Norm);
end
function r_s = calc_reading_S(g, Geo, Mis)
    S = get_system_state(Geo, Mis, 0, g);
    [~, r_s] = get_line_plane_inter(S.S.PSD_center, S.S.Read_Vec, S.M.LD_pos, S.M.Laser_Norm);
end

%% --- 几何核心 ---
function S = get_system_state(Geo, Mis, theta_deg, gamma_deg)
    theta = theta_deg*pi/180; gamma = gamma_deg*pi/180;
    % S机
    Rz = [cos(theta) -sin(theta) 0; sin(theta) cos(theta) 0; 0 0 1];
    P_S0 = [0; Geo.H_S_PSD; -Geo.z1]; L_S0 = [0; Geo.H_S_LD; -Geo.z1];
    S.S.PSD_center = Rz*P_S0; S.S.LD_pos = Rz*L_S0;
    S.S.Read_Vec = Rz*[0;1;0]; S.S.Laser_Norm = Rz*[0;1;0];
    % M机
    T_M = get_M_transform(Mis.dx, Mis.dy, Mis.alpha, Mis.beta);
    RM = T_M(1:3,1:3);
    P_M0 = [0; Geo.H_M_PSD; Geo.z2]; L_M0 = [0; Geo.H_M_LD; Geo.z2];
    n_M0 = [0; cos(gamma); -sin(gamma)];
    % 变换
    S.M.PSD_center = apply_transform(T_M, Rz*P_M0);
    S.M.LD_pos = apply_transform(T_M, Rz*L_M0);
    S.M.Read_Vec = RM*(Rz*[0;1;0]);
    S.M.Laser_Norm = RM*(Rz*n_M0);
end

function [pt, dist] = get_line_plane_inter(L_pt, L_vec, P_pt, P_norm)
    u = L_vec/norm(L_vec); n = P_norm/norm(P_norm);
    w = L_pt - P_pt; D = dot(n, u); N = -dot(n, w);
    if abs(D)<1e-8, pt=[NaN;NaN;NaN]; dist=NaN; return; end
    sI = N/D; pt = L_pt + sI*u; dist = sI;
end
function Pg = apply_transform(T, Pl), Pg = T*[Pl;ones(1,size(Pl,2))]; Pg=Pg(1:3,:); end

%% --- 绘图样式 ---
function p_plot = map_coord(p), p_plot = [p(3); p(1); p(2)]; end

function draw_mapped_point(P, color, marker)
    Pm = map_coord(P);
    scatter3(Pm(1), Pm(2), Pm(3), 10, color, 'filled', marker, 'MarkerEdgeColor', 'k');
end

function draw_mapped_line(P1, P2, style)
    if isrow(P1), P1=P1'; end; if isrow(P2), P2=P2'; end
    P1m = map_coord(P1); P2m = map_coord(P2);
    plot3([P1m(1), P2m(1)], [P1m(2), P2m(2)], [P1m(3), P2m(3)], style, 'LineWidth', 0.5);
end

function draw_mapped_segment(C, V, L, col)
    P1=C-V*(L/2); P2=C+V*(L/2); draw_mapped_line(P1,P2,['-',col]);
end

function draw_mapped_plane(P0, N, Sz, Col)
    if abs(N(3))>0.9, aux=[1;0;0]; else, aux=[0;0;1]; end
    v1=cross(N,aux); v1=v1/norm(v1)*Sz; v2=cross(N,v1); v2=v2/norm(v2)*Sz*0.3;
    C=[P0-v1-v2, P0+v1-v2, P0+v1+v2, P0-v1+v2];
    X=[];Y=[];Z=[]; for k=1:4, Pm=map_coord(C(:,k)); X(end+1)=Pm(1); Y(end+1)=Pm(2); Z(end+1)=Pm(3); end
    patch(X,Y,Z,Col,'FaceAlpha',0.15,'EdgeColor',Col,'LineStyle','--');
    Nm=map_coord(N); P0m=map_coord(P0);
    quiver3(P0m(1), P0m(2), P0m(3), Nm(1)*40, Nm(2)*40, Nm(3)*40, 'Color', Col, 'LineWidth', 1.5);
end

function draw_user_axes_arrows(L)
    quiver3(0,0,0, L,0,0, 'k', 'LineWidth', 1, 'MaxHeadSize', 40); text(L,0,0,'Z','FontSize',6);
    quiver3(0,0,0, 0,L,0, 'k', 'LineWidth', 1, 'MaxHeadSize', 4); text(0,L,0,'X','FontSize',6);
    quiver3(0,0,0, 0,0,L, 'k', 'LineWidth', 1, 'MaxHeadSize', 4); text(0,0,L,'Y','FontSize',6);
end