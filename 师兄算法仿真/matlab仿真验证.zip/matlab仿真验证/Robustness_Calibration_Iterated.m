%% Robustness_Calibration(Iterated).m
clc; clear; close all; format long g;

%% 1. 基础参数设定
% 设定不对中真值
True_Val_Unit.dx = 1.5;       
True_Val_Unit.dy = 1.0;       
True_Val_Unit.alpha = 2.75;   
True_Val_Unit.beta  = -3.5;    

True_Val_Phys.dx = True_Val_Unit.dx;
True_Val_Phys.dy = True_Val_Unit.dy;
True_Val_Phys.alpha = atand(True_Val_Unit.alpha / 100);
True_Val_Phys.beta  = atand(True_Val_Unit.beta / 100);
% 几何参数
Geo.z1 = 200; Geo.z2 = 200;
Geo.H_M_LD = 70; diff_H = 20;
Geo.H_M_PSD = Geo.H_M_LD - diff_H;
Geo.H_S_PSD = Geo.H_M_LD + 30;
Geo.H_S_LD  = Geo.H_S_PSD - diff_H;
% 扫描范围: 初始偏差
offset_range = -2 : 0.1 : 2; 
num_steps = length(offset_range);

Err_NoComp_TPM = zeros(num_steps, 4);
Err_WithComp_TPM = zeros(num_steps, 4);
Err_NoComp_APM = zeros(num_steps, 4);
Err_WithComp_APM = zeros(num_steps, 4);

% APM 采样角度
APM_Angles = [45, 90, 135, 180, 225, 270, 315, 350]; 

fprintf('开始初始偏差分析 (-2mm -> +2mm)...\n');

[Geo_Calib, gamma_calib] = calibrate_perfectly(Geo, True_Val_Phys);

%% 2. 循环扫描
% -------------------------------------------------------------------------
for i = 1:num_steps
    offset = offset_range(i);
    
    % --- 1. 生成基准数据 ---
    [s0_true, m0_true] = get_readings(Geo_Calib, True_Val_Phys, 0, gamma_calib);
    [s90_true, m90_true] = get_readings(Geo_Calib, True_Val_Phys, 90, gamma_calib);
    [s180_true, m180_true] = get_readings(Geo_Calib, True_Val_Phys, 180, gamma_calib);
    
    % APM
    APM_S_True = zeros(8, 1); APM_M_True = zeros(8, 1);
    for k = 1:8
        [APM_S_True(k), APM_M_True(k)] = get_readings(Geo_Calib, True_Val_Phys, APM_Angles(k), gamma_calib);
    end
    
    % --- 2. 模拟未完全校正 ---

    S_Offset = offset; 
    M_Offset = offset * 0.8;
    
    S0_Raw = s0_true + S_Offset;      M0_Raw = m0_true + M_Offset;
    S90_Raw = s90_true + S_Offset;    M90_Raw = m90_true + M_Offset;
    S180_Raw = s180_true + S_Offset;  M180_Raw = m180_true + M_Offset;
    
    APM_S_Raw = APM_S_True + S_Offset;
    APM_M_Raw = APM_M_True + M_Offset;
    
    % --- 3. 补偿处理 (Software Compensation) ---

    S90_Comp = S90_Raw - S0_Raw;     M90_Comp = M90_Raw - M0_Raw;
    S180_Comp = S180_Raw - S0_Raw;   M180_Comp = M180_Raw - M0_Raw;

    APM_S_Comp = APM_S_Raw - S0_Raw;
    APM_M_Comp = APM_M_Raw - M0_Raw;
    
    % --- 4. 解算与记录 ---
    
    TPM_Data_Raw = [S90_Raw, M90_Raw, S180_Raw, M180_Raw];
    Res_TPM_Raw = solve_TPM_all(TPM_Data_Raw, Geo_Calib, gamma_calib);
    Res_APM_Raw = solve_APM_all(APM_Angles, APM_S_Raw, APM_M_Raw, Geo_Calib, gamma_calib);
    
    Err_NoComp_TPM(i,:) = abs(calc_unit_error(Res_TPM_Raw, True_Val_Unit));
    Err_NoComp_APM(i,:) = abs(calc_unit_error(Res_APM_Raw, True_Val_Unit));
    
    TPM_Data_Comp = [S90_Comp, M90_Comp, S180_Comp, M180_Comp];
    Res_TPM_Comp = solve_TPM_all(TPM_Data_Comp, Geo_Calib, gamma_calib);
    Res_APM_Comp = solve_APM_all(APM_Angles, APM_S_Comp, APM_M_Comp, Geo_Calib, gamma_calib);
    
    Err_WithComp_TPM(i,:) = abs(calc_unit_error(Res_TPM_Comp, True_Val_Unit));
    Err_WithComp_APM(i,:) = abs(calc_unit_error(Res_APM_Comp, True_Val_Unit));
end

%% 3. 绘图分析
% -------------------------------------------------------------------------
param_names = {'dx (mm)', 'dy (mm)', 'Alpha (mm/100mm)', 'Beta (mm/100mm)'};

figure('Color', 'w', 'Position', [50, 50, 1200, 800], 'Name', 'Calibration Offset Analysis');
sgtitle('Impact of Initial Calibration Offset & Software Compensation', 'FontSize', 14);

for k = 1:4
    subplot(2, 2, k); hold on; grid on;
    
    plot(offset_range, Err_NoComp_TPM(:, k), 'r--', 'LineWidth', 1.5);
    plot(offset_range, Err_NoComp_APM(:, k), 'b--', 'LineWidth', 1.5);

    plot(offset_range, Err_WithComp_TPM(:, k), 'm-', 'LineWidth', 2);
    plot(offset_range, Err_WithComp_APM(:, k), 'k:', 'LineWidth', 2);
    
    xlabel('Initial Reading Offset (mm)');
    ylabel(['Abs Error (' param_names{k} ')']);
    title(param_names{k});
    
    if k==1
        legend('TPM Raw (No Comp)', 'APM Raw (No Comp)', ...
               'TPM Compensated', 'APM Compensated', 'Location', 'best'); 
    end
end

%% ========================================================================
%  函数库
% ========================================================================

% --- 封装解算流程 (线性->迭代) ---
function Sol = solve_TPM_all(Data, Geo, gamma)
    Sol_Lin = solve_TPM_linear(Data, Geo);
    Sol = solve_TPM_iterative(Sol_Lin, Data, Geo, gamma);
end
function Sol = solve_APM_all(Ang, S, M, Geo, gamma)
    [As, Bs, Cs] = fit_sine_wave(Ang, S);
    [Am, Bm, Cm] = fit_sine_wave(Ang, M);
    Sol_Lin = solve_APM_linear(As, Bs, Am, Bm, Geo);
    Sol = solve_APM_iterative(Sol_Lin, Ang, S, M, Geo, gamma);
end

% --- 统一误差计算 (绝对 + 相对) ---
function [abs_err, rel_err] = calc_errors(Res, True)
    res_alpha_unit = 100 * tand(Res.alpha);
    res_beta_unit  = 100 * tand(Res.beta);
    
    vals_calc = [Res.dx, Res.dy, res_alpha_unit, res_beta_unit];
    vals_true = [True.dx, True.dy, True.alpha, True.beta];
    
    abs_err = vals_calc - vals_true;
    rel_err = (abs(abs_err) ./ abs(vals_true)) * 100; % 百分比
end

% --- TPM 线性解算 ---
function Sol = solve_TPM_linear(Data, Geo)
    S90=Data(1); M90=Data(2); S180=Data(3); M180=Data(4);
    z1=Geo.z1; z2=Geo.z2;
    
    Sol.dy = (z1*M180 - z2*S180) / (2*(z1+z2));
    beta_rad = atan( -(S180+M180)/(2*(z1+z2)) );
    Sol.beta = beta_rad * 180/pi;
    
    termS = S90 - S180/2;
    termM = M90 - M180/2;
    dx_raw = (z2*termS - z1*termM)/(z1+z2);
    alpha_rad = atan( (S90+M90 - (S180+M180)/2)/(z1+z2) );
    
    Sol.dx = -dx_raw; 
    Sol.alpha = -alpha_rad * 180/pi;
end

% --- TPM 迭代解算 ---
function Sol = solve_TPM_iterative(Init, Data, Geo, gamma)
    x = [Init.dx; Init.dy; Init.alpha; Init.beta];
    Measured = Data(:); 
    for k = 1:5 
        Mis.dx=x(1); Mis.dy=x(2); Mis.alpha=x(3); Mis.beta=x(4);
        [s90, m90] = get_readings(Geo, Mis, 90, gamma);
        [s180, m180] = get_readings(Geo, Mis, 180, gamma);
        Sim = [s90; m90; s180; m180];
        Resid = Measured - Sim;
        if norm(Resid)<1e-9, break; end
        J = zeros(4,4); delta=1e-5;
        for p=1:4
            xt = x; xt(p)=xt(p)+delta;
            Mt.dx=xt(1); Mt.dy=xt(2); Mt.alpha=xt(3); Mt.beta=xt(4);
            [ts90, tm90] = get_readings(Geo, Mt, 90, gamma);
            [ts180, tm180] = get_readings(Geo, Mt, 180, gamma);
            J(:,p) = ([ts90; tm90; ts180; tm180] - Sim)/delta;
        end
        x = x + J \ Resid;
    end
    Sol.dx=x(1); Sol.dy=x(2); Sol.alpha=x(3); Sol.beta=x(4);
end

% --- APM 线性解算 ---
function Sol = solve_APM_linear(As, Bs, Am, Bm, Geo)
    z1=Geo.z1; z2=Geo.z2;
    alpha_rad = (As+Am)/(z1+z2);
    dx_raw    = (z2*As - z1*Am)/(z1+z2);
    beta_rad  = (Bs+Bm)/(z1+z2);
    dy_raw    = (z2*Bs - z1*Bm)/(z1+z2);
    Sol.dx = -dx_raw; Sol.alpha = -(alpha_rad*180/pi);
    Sol.dy = dy_raw; Sol.beta = beta_rad*180/pi;
end

% --- APM 迭代解算 ---
function Sol = solve_APM_iterative(Init, Angles, S_meas, M_meas, Geo, gamma)
    x = [Init.dx; Init.dy; Init.alpha; Init.beta];
    Measured = [S_meas; M_meas]; N = length(Angles);
    for k = 1:5
        Mis.dx=x(1); Mis.dy=x(2); Mis.alpha=x(3); Mis.beta=x(4);
        Sim_S=zeros(N,1); Sim_M=zeros(N,1);
        for j=1:N, [Sim_S(j), Sim_M(j)] = get_readings(Geo, Mis, Angles(j), gamma); end
        Sim = [Sim_S; Sim_M];
        Resid = Measured - Sim;
        if norm(Resid)<1e-9, break; end
        J = zeros(2*N, 4); delta=1e-5;
        for p=1:4
            xt = x; xt(p)=xt(p)+delta;
            Mt.dx=xt(1); Mt.dy=xt(2); Mt.alpha=xt(3); Mt.beta=xt(4);
            S_t=zeros(N,1); M_t=zeros(N,1);
            for j=1:N, [S_t(j), M_t(j)] = get_readings(Geo, Mt, Angles(j), gamma); end
            J(:,p) = ([S_t; M_t] - Sim)/delta;
        end
        x = x + (J'*J)\(J'*Resid);
    end
    Sol.dx=x(1); Sol.dy=x(2); Sol.alpha=x(3); Sol.beta=x(4);
end

% --- 拟合 ---
function [A, B, C] = fit_sine_wave(theta_deg, readings)
    rad = theta_deg * pi/180;
    X = [sin(rad(:)), cos(rad(:)), ones(length(rad),1)];
    P = X \ readings(:);
    A=P(1); B=P(2); C=P(3);
end

% --- 物理引擎 (含修正) ---
function [r_s, r_m] = get_readings(Geo, Mis, theta_deg, gamma_deg)
    S = get_system_state(Geo, Mis, theta_deg, gamma_deg);
    [~, r_s] = get_line_plane_inter(S.S.PSD_center, S.S.Read_Vec, S.M.LD_pos, S.M.Laser_Norm);
    [~, r_m] = get_line_plane_inter(S.M.PSD_center, S.M.Read_Vec, S.S.LD_pos, S.S.Laser_Norm);
end
function S = get_system_state(Geo, Mis, theta_deg, gamma_deg)
    theta = theta_deg * pi/180; gamma = gamma_deg * pi/180;
    Rz = [cos(theta) -sin(theta) 0; sin(theta) cos(theta) 0; 0 0 1];
    P_S0 = [0; Geo.H_S_PSD; -Geo.z1]; L_S0 = [0; Geo.H_S_LD; -Geo.z1];
    S.S.PSD_center = Rz*P_S0; S.S.LD_pos = Rz*L_S0; 
    S.S.Read_Vec = Rz*[0;1;0]; S.S.Laser_Norm = Rz*[0;1;0];
    P_M0 = [0; Geo.H_M_PSD; Geo.z2]; L_M0 = [0; Geo.H_M_LD; Geo.z2];
    n_M0 = [0; cos(gamma); -sin(gamma)];
    T_M = get_M_transform(Mis.dx, Mis.dy, Mis.alpha, Mis.beta); RM = T_M(1:3,1:3);
    S.M.PSD_center = apply_transform(T_M, Rz*P_M0);
    S.M.LD_pos = apply_transform(T_M, Rz*L_M0);
    S.M.Read_Vec = RM*(Rz*[0;1;0]); S.M.Laser_Norm = RM*(Rz*n_M0);
end
function T = get_M_transform(dx, dy, a, b)
    a = -a * pi/180; b = b * pi/180; 
    Ry = [cos(a) 0 sin(a); 0 1 0; -sin(a) 0 cos(a)];
    Rx = [1 0 0; 0 cos(b) -sin(b); 0 sin(b) cos(b)];
    T = eye(4); T(1:3,1:3) = Ry*Rx; T(1:3,4) = [dx;dy;0];
end
function [pt, dist] = get_line_plane_inter(L_pt, L_vec, P_pt, P_norm)
    u = L_vec/norm(L_vec); n = P_norm/norm(P_norm); w = L_pt - P_pt;
    D = dot(n, u); N = -dot(n, w);
    if abs(D)<1e-8, pt=[NaN;NaN;NaN]; dist=NaN; else, sI=N/D; pt=L_pt+sI*u; dist=sI; end
end
function Pg = apply_transform(T, Pl), Pg = T*[Pl;ones(1,size(Pl,2))]; Pg=Pg(1:3,:); end
function [Geo, gamma, res] = run_calibration_logic(Geo, Mis)
    diff_S = Geo.H_S_PSD - Geo.H_S_LD;
    cost_S = @(h) get_readings_wrapper(h, diff_S, Geo, Mis, 0, 'M');
    try h_new = fzero(cost_S, Geo.H_S_PSD); catch, h_new = Geo.H_S_PSD; end
    Geo.H_S_PSD = h_new; Geo.H_S_LD = h_new - diff_S;
    cost_M = @(g) get_readings_wrapper_g(g, Geo, Mis, 'S');
    try gamma = fzero(cost_M, 0); catch, gamma=0; end
    res=0;
end
function val = get_readings_wrapper(h, diff, Geo, Mis, g, target)
    Geo.H_S_PSD = h; Geo.H_S_LD = h-diff;
    [rs, rm] = get_readings(Geo, Mis, 0, g);
    if strcmp(target,'M'), val=rm; else, val=rs; end
end
function val = get_readings_wrapper_g(g, Geo, Mis, target)
    [rs, rm] = get_readings(Geo, Mis, 0, g);
    if strcmp(target,'M'), val=rm; else, val=rs; end
end

function err_vec = calc_unit_error(Res, True)
    res_alpha = 100 * tand(Res.alpha); res_beta  = 100 * tand(Res.beta);
    err_vec = [Res.dx-True.dx, Res.dy-True.dy, res_alpha-True.alpha, res_beta-True.beta];
end

function S=get_state(G,M,t,gam)
    th=t*pi/180; ga=gam*pi/180; Rz=[cos(th) -sin(th) 0; sin(th) cos(th) 0; 0 0 1];
    S.S.PSD_center=Rz*[0;G.H_S_PSD;-G.z1]; S.S.LD_pos=Rz*[0;G.H_S_LD;-G.z1];
    S.S.Read_Vec=Rz*[0;1;0]; S.S.Laser_Norm=Rz*[0;1;0];
    T=get_T(M.dx,M.dy,M.alpha,M.beta); RM=T(1:3,1:3);
    S.M.PSD_center=apt(T,Rz*[0;G.H_M_PSD;G.z2]); S.M.LD_pos=apt(T,Rz*[0;G.H_M_LD;G.z2]);
    S.M.Read_Vec=RM*(Rz*[0;1;0]); S.M.Laser_Norm=RM*(Rz*[0;cos(ga);-sin(ga)]);
end
function T=get_T(dx,dy,a,b), a=-a*pi/180; b=b*pi/180; T=eye(4); T(1:3,1:3)=[cos(a) 0 sin(a);0 1 0;-sin(a) 0 cos(a)]*[1 0 0;0 cos(b) -sin(b);0 sin(b) cos(b)]; T(1:3,4)=[dx;dy;0]; end
function [p,d]=glpi(Lp,Lv,Pp,Pn), u=Lv/norm(Lv); n=Pn/norm(Pn); w=Lp-Pp; D=dot(n,u); if abs(D)<1e-8, p=[nan;nan;nan];d=nan; else, s=-dot(n,w)/D; p=Lp+s*u; d=s; end; end
function P=apt(T,L), P=T*[L;ones(1,size(L,2))]; P=P(1:3,:); end
function [G,g]=calibrate_perfectly(G,M), df=G.H_S_PSD-G.H_S_LD; cS=@(h)grw(h,df,G,M,0,'M'); try hn=fzero(cS,G.H_S_PSD);catch,hn=G.H_S_PSD;end; G.H_S_PSD=hn;G.H_S_LD=hn-df; cM=@(g)grwg(g,G,M,'S'); try g=fzero(cM,0);catch,g=0;end; end
function v=grw(h,df,G,M,g,tg), G.H_S_PSD=h; G.H_S_LD=h-df; [rs,rm]=get_readings(G,M,0,g); if strcmp(tg,'M'),v=rm;else,v=rs;end; end
function v=grwg(g,G,M,tg), [rs,rm]=get_readings(G,M,0,g); if strcmp(tg,'M'),v=rm;else,v=rs;end; end