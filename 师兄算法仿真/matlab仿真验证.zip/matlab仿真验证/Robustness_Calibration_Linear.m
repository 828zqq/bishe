%% Robustness_Calibration(Linear).m
clc; clear; close all; format long g;

%% 1. 基础参数设定
% 设定不对中真值
True_Val_Unit.dx = 0.5;       
True_Val_Unit.dy = 1.0;       
True_Val_Unit.alpha = -1.75;  
True_Val_Unit.beta  = 1.5; 

True_Val_Phys.dx = True_Val_Unit.dx;
True_Val_Phys.dy = True_Val_Unit.dy;
True_Val_Phys.alpha = atand(True_Val_Unit.alpha / 100);
True_Val_Phys.beta  = atand(True_Val_Unit.beta / 100);

% 几何参数
Geo.z1 = 200; Geo.z2 = 200;
Geo.H_M_LD = 70; diff_H = 20;
Geo.H_M_PSD = Geo.H_M_LD - diff_H;
Geo.H_S_PSD = Geo.H_M_LD + 30;
Geo.H_S_LD  = Geo.H_S_PSD - diff_H;

% 扫描范围: 初始偏差 (Offset)
offset_range = -2 : 0.1 : 2; 
num_steps = length(offset_range);

Err_NoComp_TPM = zeros(num_steps, 4);
Err_WithComp_TPM = zeros(num_steps, 4);
Err_NoComp_APM = zeros(num_steps, 4);
Err_WithComp_APM = zeros(num_steps, 4);

APM_Angles = [45, 90, 135, 180, 225, 270, 315, 350]; 

fprintf('开始初始偏差分析 (-2mm -> +2mm)...\n');


[Geo_Calib, gamma_calib] = calibrate_perfectly(Geo, True_Val_Phys);

%% 2. 循环扫描
for i = 1:num_steps
    offset = offset_range(i);
    
    % --- 1. 生成基准数据 ---
    [s0_true, m0_true] = get_readings(Geo_Calib, True_Val_Phys, 0, gamma_calib);
    [s90_true, m90_true] = get_readings(Geo_Calib, True_Val_Phys, 90, gamma_calib);
    [s180_true, m180_true] = get_readings(Geo_Calib, True_Val_Phys, 180, gamma_calib);
    
    APM_S_True = zeros(8, 1); APM_M_True = zeros(8, 1);
    for k = 1:8
        [APM_S_True(k), APM_M_True(k)] = get_readings(Geo_Calib, True_Val_Phys, APM_Angles(k), gamma_calib);
    end
    
    % --- 2. 模拟未完全校正 ---
    S_Offset = offset; 
    M_Offset = offset * 0.8;

    S0_Raw = s0_true + S_Offset;      M0_Raw = m0_true + M_Offset;
    S90_Raw = s90_true + S_Offset;    M90_Raw = m90_true + M_Offset;
    S180_Raw = s180_true + S_Offset;  M180_Raw = m180_true + M_Offset;
    
    APM_S_Raw = APM_S_True + S_Offset;
    APM_M_Raw = APM_M_True + M_Offset;
    
    % --- 3. 补偿处理 ---

    S90_Comp = S90_Raw - S0_Raw;     M90_Comp = M90_Raw - M0_Raw;
    S180_Comp = S180_Raw - S0_Raw;   M180_Comp = M180_Raw - M0_Raw;

    APM_S_Comp = APM_S_Raw - S0_Raw;
    APM_M_Comp = APM_M_Raw - M0_Raw;
    
    % --- 4. 解算与记录 ---

    TPM_Data_Raw = [S90_Raw, M90_Raw, S180_Raw, M180_Raw];
    Res_TPM_Raw = solve_TPM_linear(TPM_Data_Raw, Geo_Calib);
    
    [As_raw, Bs_raw, Cs_raw] = fit_sine_wave(APM_Angles, APM_S_Raw);
    [Am_raw, Bm_raw, Cm_raw] = fit_sine_wave(APM_Angles, APM_M_Raw);
    Res_APM_Raw = solve_APM_linear(As_raw, Bs_raw, Am_raw, Bm_raw, Geo_Calib);
    
    Err_NoComp_TPM(i,:) = abs(calc_unit_error(Res_TPM_Raw, True_Val_Unit));
    Err_NoComp_APM(i,:) = abs(calc_unit_error(Res_APM_Raw, True_Val_Unit));
    
    % B. 补偿组 
    TPM_Data_Comp = [S90_Comp, M90_Comp, S180_Comp, M180_Comp];
    Res_TPM_Comp = solve_TPM_linear(TPM_Data_Comp, Geo_Calib);
    
    [As_cmp, Bs_cmp, Cs_cmp] = fit_sine_wave(APM_Angles, APM_S_Comp);
    [Am_cmp, Bm_cmp, Cm_cmp] = fit_sine_wave(APM_Angles, APM_M_Comp);
    Res_APM_Comp = solve_APM_linear(As_cmp, Bs_cmp, Am_cmp, Bm_cmp, Geo_Calib);
    
    Err_WithComp_TPM(i,:) = abs(calc_unit_error(Res_TPM_Comp, True_Val_Unit));
    Err_WithComp_APM(i,:) = abs(calc_unit_error(Res_APM_Comp, True_Val_Unit));
end

%% 3. 绘图分析

param_names = {'dx (mm)', 'dy (mm)', 'Alpha (mm/100mm)', 'Beta (mm/100mm)'};

figure('Color', 'w', 'Position', [50, 50, 1200, 800], 'Name', 'Calibration Offset Analysis');
sgtitle('Impact of Initial Calibration Offset & Software Compensation', 'FontSize', 14);

for k = 1:4
    subplot(2, 2, k); hold on; grid on;

    plot(offset_range, Err_NoComp_TPM(:, k), 'r--', 'LineWidth', 1.5);
    plot(offset_range, Err_NoComp_APM(:, k), 'b--', 'LineWidth', 1.5);

    plot(offset_range, Err_WithComp_TPM(:, k), 'm-', 'LineWidth', 2);
    plot(offset_range, Err_WithComp_APM(:, k), 'k:', 'LineWidth', 2);
    
    xlabel('Initial Reading Offset (mm)');
    ylabel(['Abs Error (' param_names{k} ')']);
    title(param_names{k});
    
    if k==1
        legend('TPM Raw (No Comp)', 'APM Raw (No Comp)', ...
               'TPM Comp (Software Zero)', 'APM Comp (Software Zero)', 'Location', 'best'); 
    end
end

%% ========================================================================

function err_vec = calc_unit_error(Res, True)
    res_alpha = 100 * tand(Res.alpha);
    res_beta  = 100 * tand(Res.beta);
    err_vec = [Res.dx - True.dx, Res.dy - True.dy, ...
               res_alpha - True.alpha, res_beta - True.beta];
end

% --- TPM 线性解算 ---
function Sol = solve_TPM_linear(Data, Geo)
    S90=Data(1); M90=Data(2); S180=Data(3); M180=Data(4); z1=Geo.z1; z2=Geo.z2;
    Sol.dy = (z1*M180 - z2*S180)/(2*(z1+z2));
    Sol.beta = atan(-(S180+M180)/(2*(z1+z2)))*180/pi;
    termS=S90-S180/2; termM=M90-M180/2;
    dx_raw = (z2*termS - z1*termM)/(z1+z2);
    alpha_rad = atan((S90+M90 - (S180+M180)/2)/(z1+z2));
    Sol.dx = -dx_raw; Sol.alpha = -alpha_rad*180/pi;
end

% --- APM 线性解算 ---
function Sol = solve_APM_linear(As, Bs, Am, Bm, Geo)
    z1=Geo.z1; z2=Geo.z2;
    Sol.dx = -(z2*As - z1*Am)/(z1+z2); 
    Sol.alpha = -(As+Am)/(z1+z2)*180/pi;
    Sol.dy = (z2*Bs - z1*Bm)/(z1+z2); 
    Sol.beta = (Bs+Bm)/(z1+z2)*180/pi;
end

% --- 最小二乘拟合 ---
function [A,B,C]=fit_sine_wave(t,r)
    rad=t*pi/180; 
    X=[sin(rad(:)),cos(rad(:)),ones(length(rad),1)]; 
    P=X\r(:); 
    A=P(1); B=P(2); C=P(3); 
end

% --- 物理引擎 ---
function [r_s,r_m]=get_readings(G,M,t,g)
    S=get_state(G,M,t,g); 
    [~,r_s]=glpi(S.S.PSD_center,S.S.Read_Vec,S.M.LD_pos,S.M.Laser_Norm); 
    [~,r_m]=glpi(S.M.PSD_center,S.M.Read_Vec,S.S.LD_pos,S.S.Laser_Norm); 
end
function S=get_state(G,M,t,g)
    th=t*pi/180; ga=g*pi/180; Rz=[cos(th) -sin(th) 0; sin(th) cos(th) 0; 0 0 1];
    S.S.PSD_center=Rz*[0;G.H_S_PSD;-G.z1]; S.S.LD_pos=Rz*[0;G.H_S_LD;-G.z1];
    S.S.Read_Vec=Rz*[0;1;0]; S.S.Laser_Norm=Rz*[0;1;0];
    T=get_T(M.dx,M.dy,M.alpha,M.beta); RM=T(1:3,1:3);
    S.M.PSD_center=apt(T,Rz*[0;G.H_M_PSD;G.z2]); S.M.LD_pos=apt(T,Rz*[0;G.H_M_LD;G.z2]);
    S.M.Read_Vec=RM*(Rz*[0;1;0]); S.M.Laser_Norm=RM*(Rz*[0;cos(ga);-sin(ga)]);
end
function T=get_T(dx,dy,a,b), a=-a*pi/180; b=b*pi/180; Ry=[cos(a) 0 sin(a);0 1 0;-sin(a) 0 cos(a)]; Rx=[1 0 0;0 cos(b) -sin(b);0 sin(b) cos(b)]; T=eye(4); T(1:3,1:3)=Ry*Rx; T(1:3,4)=[dx;dy;0]; end
function [p,d]=glpi(Lp,Lv,Pp,Pn), u=Lv/norm(Lv); n=Pn/norm(Pn); w=Lp-Pp; D=dot(n,u); if abs(D)<1e-8, p=[nan;nan;nan];d=nan; else, s=-dot(n,w)/D; p=Lp+s*u; d=s; end; end
function P=apt(T,L), P=T*[L;ones(1,size(L,2))]; P=P(1:3,:); end
function [G,g]=calibrate_perfectly(G,M), df=G.H_S_PSD-G.H_S_LD; cS=@(h)grw(h,df,G,M,0,'M'); try hn=fzero(cS,G.H_S_PSD);catch,hn=G.H_S_PSD;end; G.H_S_PSD=hn;G.H_S_LD=hn-df; cM=@(x)grwg(x,G,M,'S'); try g=fzero(cM,0);catch,g=0;end; end
function v=grw(h,d,G,M,g,tg), G.H_S_PSD=h; G.H_S_LD=h-d; [rs,rm]=get_readings(G,M,0,g); if strcmp(tg,'M'),v=rm;else,v=rs;end; end
function v=grwg(g,G,M,tg), [rs,rm]=get_readings(G,M,0,g); if strcmp(tg,'M'),v=rm;else,v=rs;end; end