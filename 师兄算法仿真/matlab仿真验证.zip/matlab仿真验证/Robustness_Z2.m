%% Robustness_Z2.m
clc; clear; close all; format long g;

%% 1. 基础参数设定
% 设定不对中真值 
True_Val_Unit.dx = 0.5;       
True_Val_Unit.dy = -0.75;       
True_Val_Unit.alpha = 1.0;
True_Val_Unit.beta  = -0.5;

True_Val_Phys.dx = True_Val_Unit.dx;
True_Val_Phys.dy = True_Val_Unit.dy;
True_Val_Phys.alpha = atand(True_Val_Unit.alpha / 100);
True_Val_Phys.beta  = atand(True_Val_Unit.beta / 100);

Geo_Soft.z1 = 200; 
Geo_Soft.z2 = 200;
Geo_Soft.H_M_LD = 70;
diff_H = 20;
Geo_Soft.H_M_PSD = Geo_Soft.H_M_LD - diff_H;
Geo_Soft.H_S_PSD = Geo_Soft.H_M_LD + 30;
Geo_Soft.H_S_LD  = Geo_Soft.H_S_PSD - diff_H;

Geo_Real = Geo_Soft; 

% 扫描范围: z2 实际安装误差
z2_nominal = 200;
z2_error_range = -3 : 0.04 : 3;
z2_real_values = z2_nominal + z2_error_range;
num_steps = length(z2_real_values);

Err_Abs_TPM_Lin  = zeros(num_steps, 4);
Err_Abs_TPM_Iter = zeros(num_steps, 4);
Err_Abs_APM_Lin  = zeros(num_steps, 4);
Err_Abs_APM_Iter = zeros(num_steps, 4);

Err_Rel_TPM_Iter = zeros(num_steps, 4); 

APM_Angles = [10, 50, 90, 130, 170, 210, 250, 290, 330]; 

fprintf('开始鲁棒性分析 (Z2 Error: -3mm -> +3mm)...\n');
wb = waitbar(0, '正在计算...');

%% 2. 循环扫描
for i = 1:num_steps
    z2_curr = z2_real_values(i);
    waitbar(i/num_steps, wb, sprintf('Z2 Actual = %.2f mm', z2_curr));
    
    Geo_Real.z2 = z2_curr;

    [Geo_Calib_Real, gamma_calib, ~] = run_calibration_logic(Geo_Real, True_Val_Phys);

    [s90, m90]   = get_readings(Geo_Calib_Real, True_Val_Phys, 90, gamma_calib);
    [s180, m180] = get_readings(Geo_Calib_Real, True_Val_Phys, 180, gamma_calib);
    TPM_Data = [s90, m90, s180, m180];
    
    APM_S = zeros(9, 1); APM_M = zeros(9, 1);
    for k = 1:9
        [APM_S(k), APM_M(k)] = get_readings(Geo_Calib_Real, True_Val_Phys, APM_Angles(k), gamma_calib);
    end

    % 1. TPM Linear
    Res_TPM_Lin = solve_TPM_linear(TPM_Data, Geo_Soft);

    Geo_Soft_Iter = Geo_Soft; 
    Geo_Soft_Iter.H_S_PSD = Geo_Calib_Real.H_S_PSD; % 假设软件读取到了校准后的S机高度位置(或者假设归零了)
    Geo_Soft_Iter.H_S_LD = Geo_Soft_Iter.H_S_PSD - diff_H;
    
    Res_TPM_Iter = solve_TPM_iterative(Res_TPM_Lin, TPM_Data, Geo_Soft_Iter, gamma_calib);

    [As, Bs, Cs] = fit_sine_wave(APM_Angles, APM_S);
    [Am, Bm, Cm] = fit_sine_wave(APM_Angles, APM_M);
    Res_APM_Lin = solve_APM_linear(As, Bs, Am, Bm, Geo_Soft);

    Res_APM_Iter = solve_APM_iterative(Res_APM_Lin, APM_Angles, APM_S, APM_M, Geo_Soft_Iter, gamma_calib);

    Err_Abs_TPM_Lin(i, :)  = abs(calc_unit_error(Res_TPM_Lin, True_Val_Unit));
    Err_Abs_TPM_Iter(i, :) = abs(calc_unit_error(Res_TPM_Iter, True_Val_Unit));
    Err_Abs_APM_Lin(i, :)  = abs(calc_unit_error(Res_APM_Lin, True_Val_Unit));
    Err_Abs_APM_Iter(i, :) = abs(calc_unit_error(Res_APM_Iter, True_Val_Unit));

    true_vec = [True_Val_Unit.dx, True_Val_Unit.dy, True_Val_Unit.alpha, True_Val_Unit.beta];
    Err_Rel_TPM_Lin(i, :) = (Err_Abs_TPM_Lin(i, :) ./ abs(true_vec)) * 100;
    Err_Rel_TPM_Iter(i, :) = (Err_Abs_TPM_Iter(i, :) ./ abs(true_vec)) * 100;
    Err_Rel_APM_Lin(i, :) = (Err_Abs_APM_Lin(i, :) ./ abs(true_vec)) * 100;
    Err_Rel_APM_Iter(i, :) = (Err_Abs_APM_Iter(i, :) ./ abs(true_vec)) * 100;
    
end
close(wb);

%% 3. 绘图分析
param_names = {'dx (mm)', 'dy (mm)', 'Alpha (mm/100mm)', 'Beta (mm/100mm)'};

figure('Color', 'w', 'Position', [50, 50, 1200, 700], 'Name', 'Robustness: Z2 Error Impact (Absolute)');
sgtitle('Robustness Analysis: Impact of Installation Error (z2) on Absolute Error', 'FontSize', 14);

for k = 1:4
    subplot(2, 2, k); hold on; grid on;

    plot(z2_error_range, Err_Abs_TPM_Lin(:, k), 'r--', 'LineWidth', 1.5);
    plot(z2_error_range, Err_Abs_APM_Lin(:, k), 'b-.', 'LineWidth', 1.5);
    plot(z2_error_range, Err_Abs_TPM_Iter(:, k), 'm-', 'LineWidth', 2);
    plot(z2_error_range, Err_Abs_APM_Iter(:, k), 'k:', 'LineWidth', 2);

    xline(0, 'g-', 'Alpha', 0.5);
    
    xlabel('Installation Error of z2 (mm)');
    ylabel(['Abs Error (' param_names{k} ')']);
    title(param_names{k});
    if k==1, legend('TPM Lin', 'APM Lin', 'TPM Iter', 'APM Iter', 'Location', 'best'); end
end

figure('Color', 'w', 'Position', [100, 100, 1200, 700], 'Name', 'Robustness: Z2 Error Impact (Relative)');
sgtitle('Sensitivity of Iterative Algorithm to z2 Error', 'FontSize', 14);

for k = 1:4
    subplot(2, 2, k); hold on; grid on;
    plot(z2_error_range, Err_Rel_TPM_Lin(:, k), 'r--', 'LineWidth', 1.5);
    plot(z2_error_range, Err_Rel_APM_Lin(:, k), 'b-', 'LineWidth', 1.5);
    plot(z2_error_range, Err_Rel_TPM_Iter(:, k), 'm-', 'LineWidth', 2);
    plot(z2_error_range, Err_Rel_APM_Iter(:, k), 'k:', 'LineWidth', 2);
    xlabel('Installation Error of z2 (mm)');
    ylabel('Relative Error (%)');
    title([param_names{k} ' Sensitivity']);
    if k==1, legend('TPM Lin', 'APM Lin', 'TPM Iter', 'APM Iter', 'Location', 'best'); end
end

%% ========================================================================
function err_vec = calc_unit_error(Res, True)
    res_alpha = 100 * tand(Res.alpha);
    res_beta  = 100 * tand(Res.beta);
    err_vec = [Res.dx - True.dx, Res.dy - True.dy, ...
               res_alpha - True.alpha, res_beta - True.beta];
end

function Sol = solve_TPM_linear(Data, Geo)
    S90=Data(1); M90=Data(2); S180=Data(3); M180=Data(4); z1=Geo.z1; z2=Geo.z2;
    Sol.dy = (z1*M180 - z2*S180)/(2*(z1+z2));
    Sol.beta = atan(-(S180+M180)/(2*(z1+z2)))*180/pi;
    termS=S90-S180/2; termM=M90-M180/2;
    dx_raw = (z2*termS - z1*termM)/(z1+z2);
    alpha_rad = atan((S90+M90 - (S180+M180)/2)/(z1+z2));
    Sol.dx = -dx_raw; Sol.alpha = -alpha_rad*180/pi;
end
function Sol = solve_TPM_iterative(Init, Data, Geo, gamma)
    x = [Init.dx; Init.dy; Init.alpha; Init.beta]; Measured = Data(:);
    for k=1:5
        Mis.dx=x(1); Mis.dy=x(2); Mis.alpha=x(3); Mis.beta=x(4);
        [s90,m90]=get_readings(Geo,Mis,90,gamma); [s180,m180]=get_readings(Geo,Mis,180,gamma);
        Sim=[s90;m90;s180;m180]; Resid=Measured-Sim;
        if norm(Resid)<1e-9, break; end
        J=zeros(4,4); delta=1e-5;
        for p=1:4
            xt=x; xt(p)=xt(p)+delta; Mt.dx=xt(1); Mt.dy=xt(2); Mt.alpha=xt(3); Mt.beta=xt(4);
            [ts90,tm90]=get_readings(Geo,Mt,90,gamma); [ts180,tm180]=get_readings(Geo,Mt,180,gamma);
            J(:,p)=([ts90;tm90;ts180;tm180]-Sim)/delta;
        end
        x=x+J\Resid;
    end
    Sol.dx=x(1); Sol.dy=x(2); Sol.alpha=x(3); Sol.beta=x(4);
end
function Sol = solve_APM_linear(As, Bs, Am, Bm, Geo)
    z1=Geo.z1; z2=Geo.z2;
    ar=(As+Am)/(z1+z2); dx=(z2*As-z1*Am)/(z1+z2);
    br=(Bs+Bm)/(z1+z2); dy=(z2*Bs-z1*Bm)/(z1+z2);
    Sol.dx=-dx; Sol.alpha=-ar*180/pi; Sol.dy=dy; Sol.beta=br*180/pi;
end
function Sol = solve_APM_iterative(Init, Ang, S, M, Geo, gamma)
    x=[Init.dx;Init.dy;Init.alpha;Init.beta]; Meas=[S;M]; N=length(Ang);
    for k=1:5
        Mis.dx=x(1); Mis.dy=x(2); Mis.alpha=x(3); Mis.beta=x(4);
        SS=zeros(N,1); MM=zeros(N,1);
        for j=1:N, [SS(j),MM(j)]=get_readings(Geo,Mis,Ang(j),gamma); end
        Sim=[SS;MM]; Resid=Meas-Sim;
        if norm(Resid)<1e-9, break; end
        J=zeros(2*N,4); delta=1e-5;
        for p=1:4
            xt=x; xt(p)=xt(p)+delta; Mt.dx=xt(1); Mt.dy=xt(2); Mt.alpha=xt(3); Mt.beta=xt(4);
            St=zeros(N,1); Mt_=zeros(N,1);
            for j=1:N, [St(j),Mt_(j)]=get_readings(Geo,Mt,Ang(j),gamma); end
            J(:,p)=([St;Mt_]-Sim)/delta;
        end
        x=x+(J'*J)\(J'*Resid);
    end
    Sol.dx=x(1); Sol.dy=x(2); Sol.alpha=x(3); Sol.beta=x(4);
end
function [A,B,C]=fit_sine_wave(t,r), rad=t*pi/180; X=[sin(rad(:)),cos(rad(:)),ones(length(rad),1)]; P=X\r(:); A=P(1); B=P(2); C=P(3); end
function [r_s,r_m]=get_readings(G,M,t,g), S=get_system_state(G,M,t,g); [~,r_s]=get_line_plane_inter(S.S.PSD_center,S.S.Read_Vec,S.M.LD_pos,S.M.Laser_Norm); [~,r_m]=get_line_plane_inter(S.M.PSD_center,S.M.Read_Vec,S.S.LD_pos,S.S.Laser_Norm); end
function S=get_system_state(G,M,t,g), th=t*pi/180; ga=g*pi/180; Rz=[cos(th) -sin(th) 0; sin(th) cos(th) 0; 0 0 1]; PS=[0;G.H_S_PSD;-G.z1]; LS=[0;G.H_S_LD;-G.z1]; S.S.PSD_center=Rz*PS; S.S.LD_pos=Rz*LS; S.S.Read_Vec=Rz*[0;1;0]; S.S.Laser_Norm=Rz*[0;1;0]; PM=[0;G.H_M_PSD;G.z2]; LM=[0;G.H_M_LD;G.z2]; nM=[0;cos(ga);-sin(ga)]; TM=get_M_transform(M.dx,M.dy,M.alpha,M.beta); RM=TM(1:3,1:3); S.M.PSD_center=apply_transform(TM,Rz*PM); S.M.LD_pos=apply_transform(TM,Rz*LM); S.M.Read_Vec=RM*(Rz*[0;1;0]); S.M.Laser_Norm=RM*(Rz*nM); end
function T=get_M_transform(x,y,a,b), a=-a*pi/180; b=b*pi/180; Ry=[cos(a) 0 sin(a);0 1 0;-sin(a) 0 cos(a)]; Rx=[1 0 0;0 cos(b) -sin(b);0 sin(b) cos(b)]; T=eye(4); T(1:3,1:3)=Ry*Rx; T(1:3,4)=[x;y;0]; end
function [p,d]=get_line_plane_inter(Lp,Lv,Pp,Pn), u=Lv/norm(Lv); n=Pn/norm(Pn); w=Lp-Pp; D=dot(n,u); N=-dot(n,w); if abs(D)<1e-8, p=[NaN;NaN;NaN]; d=NaN; else, s=N/D; p=Lp+s*u; d=s; end; end
function P=apply_transform(T,p), P=T*[p;ones(1,size(p,2))]; P=P(1:3,:); end
function [G,g,r]=run_calibration_logic(G,M), dS=G.H_S_PSD-G.H_S_LD; cS=@(h)grw(h,dS,G,M,0,'M'); try h=fzero(cS,G.H_S_PSD); catch, h=G.H_S_PSD; end; G.H_S_PSD=h; G.H_S_LD=h-dS; cM=@(x)grwg(x,G,M,'S'); try g=fzero(cM,0); catch, g=0; end; r=0; end
function v=grw(h,d,G,M,g,tg), G.H_S_PSD=h; G.H_S_LD=h-d; [rs,rm]=get_readings(G,M,0,g); if strcmp(tg,'M'), v=rm; else, v=rs; end; end
function v=grwg(g,G,M,tg), [rs,rm]=get_readings(G,M,0,g); if strcmp(tg,'M'), v=rm; else, v=rs; end; end