clc; clear; format long g;

%% 1. 基础参数设定
% -------------------------------------------------------------------------
Geo.z1 = 150;          
Geo.z2 = 150;          
Geo.H_S_PSD = 80;      
diff_H = 20;           
Geo.H_S_LD  = Geo.H_S_PSD - diff_H; 
Geo.H_M_LD = 70;       
Geo.H_M_PSD = Geo.H_M_LD - diff_H; 

True_Val.dx = 5.0000;      
True_Val.dy = -4.0000;    
True_Val.alpha = 3.0000;  
True_Val.beta  = -2.5000; 

Misalign = True_Val;

fprintf('======================================================\n');
fprintf('1. 设定真值 (True Values):\n');
fprintf('   dx=%.4f, dy=%.4f, alpha=%.4f, beta=%.4f\n', ...
    True_Val.dx, True_Val.dy, True_Val.alpha, True_Val.beta);

%% 2. 生成测量数据
[Geo_Calib, gamma_calib, ~] = run_calibration_logic(Geo, Misalign);

% B. 获取测量读数
[S90, M90]   = get_readings(Geo_Calib, Misalign, 90, gamma_calib);
[S180, M180] = get_readings(Geo_Calib, Misalign, 180, gamma_calib);
Measured = [S90; M90; S180; M180];

fprintf('2. 仿真测量数据 (S90, M90, S180, M180) 已生成。\n');

%% 3. 初始解算 (解析法 - 三点法公式)
% -------------------------------------------------------------------------
z1 = Geo.z1; z2 = Geo.z2;

dy0 = (z1 * M180 - z2 * S180) / (2 * (z1 + z2));
beta0_deg = atan( - (S180 + M180) / (2 * (z1 + z2)) ) * (180/pi);

term_S = S90 - S180 / 2;
term_M = M90 - M180 / 2;
dx0_raw = (z2 * term_S - z1 * term_M) / (z1 + z2);
alpha0_raw_deg = atan( (S90 + M90 - (S180 + M180)/2) / (z1 + z2) ) * (180/pi);

dx0 = -dx0_raw;       
alpha0 = -alpha0_raw_deg; 
beta0 = beta0_deg;

x_current = [dx0, dy0, alpha0, beta0];

fprintf('\n3. 初始解析解 (Initial Guess):\n');
print_diff(True_Val, x_current);

%% 4. 迭代优化
% -------------------------------------------------------------------------
fprintf('\n4. 开始迭代优化 (Target: 3 Iterations)...\n');

for k = 1:3
    Mis_curr.dx = x_current(1);
    Mis_curr.dy = x_current(2);
    Mis_curr.alpha = x_current(3);
    Mis_curr.beta  = x_current(4);

    [s90_sim, m90_sim]   = get_readings(Geo_Calib, Mis_curr, 90, gamma_calib);
    [s180_sim, m180_sim] = get_readings(Geo_Calib, Mis_curr, 180, gamma_calib);
    Simulated = [s90_sim; m90_sim; s180_sim; m180_sim];

    residuals = Measured - Simulated;
    
    J = zeros(4, 4);
    delta = 1e-5; 
    
    for i = 1:4
        x_temp = x_current;
        x_temp(i) = x_temp(i) + delta;
        
        Mis_temp.dx = x_temp(1); Mis_temp.dy = x_temp(2);
        Mis_temp.alpha = x_temp(3); Mis_temp.beta = x_temp(4);
        
        [ts90, tm90]   = get_readings(Geo_Calib, Mis_temp, 90, gamma_calib);
        [ts180, tm180] = get_readings(Geo_Calib, Mis_temp, 180, gamma_calib);
        Sim_temp = [ts90; tm90; ts180; tm180];
        
        J(:, i) = (Sim_temp - Simulated) / delta;
    end
    
    delta_x = J \ residuals;
    x_current = x_current + delta_x';
    
    fprintf('   --- Iteration %d ---\n', k);
    fprintf('   Residual Norm: %.2e\n', norm(residuals));
    err_dx = x_current(1) - True_Val.dx;
    err_dy = x_current(2) - True_Val.dy;
    err_a  = x_current(3) - True_Val.alpha;
    err_b  = x_current(4) - True_Val.beta;
    fprintf('   Errors -> dx: %.1e, dy: %.1e, a: %.1e, b: %.1e\n', ...
            err_dx, err_dy, err_a, err_b);
end

%% 5. 最终结果对比
% -------------------------------------------------------------------------
fprintf('\n======================================================\n');
fprintf('5. 最终结果对比 (Final Comparison)\n');
fprintf('======================================================\n');
fprintf('%-8s | %-10s | %-10s (Err) | %-10s (Err)\n', ...
    'Param', 'True Value', 'Initial', 'Iterated(3)');
fprintf('------------------------------------------------------\n');

x_final = x_current;
labels = {'dx', 'dy', 'alpha', 'beta'};
vals_true = [True_Val.dx, True_Val.dy, True_Val.alpha, True_Val.beta];
vals_init = [dx0, dy0, alpha0, beta0];

for i = 1:4
    err_i = abs(vals_init(i) - vals_true(i));
    err_f = abs(x_final(i) - vals_true(i));
    
    fprintf('%-8s | %10.5f | %10.5f (%.1e) | %10.5f (%.1e)\n', ...
        labels{i}, vals_true(i), vals_init(i), err_i, x_final(i), err_f);
end
fprintf('======================================================\n');


%% ========================================================================
%  底层函数库 (Physics Engine & Calibration)
% =========================================================================

function print_diff(True, x)
    err = [x(1)-True.dx, x(2)-True.dy, x(3)-True.alpha, x(4)-True.beta];
    fprintf('   [dx]: True=%.4f, Calc=%.4f, Err=%.4f\n', True.dx, x(1), err(1));
    fprintf('   [dy]: True=%.4f, Calc=%.4f, Err=%.4f\n', True.dy, x(2), err(2));
    fprintf('   [al]: True=%.4f, Calc=%.4f, Err=%.4f\n', True.alpha, x(3), err(3));
    fprintf('   [be]: True=%.4f, Calc=%.4f, Err=%.4f\n', True.beta, x(4), err(4));
end

function [r_s, r_m] = get_readings(Geo, Mis, theta_deg, gamma_deg)
    S = get_system_state(Geo, Mis, theta_deg, gamma_deg);
    [~, r_s] = get_line_plane_inter(S.S.PSD_center, S.S.Read_Vec, ...
                                    S.M.LD_pos, S.M.Laser_Norm);
    [~, r_m] = get_line_plane_inter(S.M.PSD_center, S.M.Read_Vec, ...
                                    S.S.LD_pos, S.S.Laser_Norm);
end

function S = get_system_state(Geo, Mis, theta_deg, gamma_deg)
    theta = theta_deg * pi / 180;
    gamma = gamma_deg * pi / 180;
    Rz = [cos(theta), -sin(theta), 0; sin(theta), cos(theta), 0; 0, 0, 1];

    % S 机
    P_S0 = [0; Geo.H_S_PSD; -Geo.z1];
    L_S0 = [0; Geo.H_S_LD;  -Geo.z1];
    S.S.PSD_center = Rz * P_S0;
    S.S.LD_pos     = Rz * L_S0;
    S.S.Read_Vec   = Rz * [0; 1; 0];
    S.S.Laser_Norm = Rz * [0; 1; 0];

    % M 机
    P_M0 = [0; Geo.H_M_PSD; Geo.z2];
    L_M0 = [0; Geo.H_M_LD;  Geo.z2];
    n_M0 = [0; cos(gamma); -sin(gamma)];
    
    P_M_rot = Rz * P_M0; L_M_rot = Rz * L_M0;
    v_M_rot = Rz * [0; 1; 0]; n_M_rot = Rz * n_M0;
    
    T_M = get_M_transform(Mis.dx, Mis.dy, Mis.alpha, Mis.beta);
    RM  = T_M(1:3, 1:3);
    
    S.M.PSD_center = apply_transform(T_M, P_M_rot);
    S.M.LD_pos     = apply_transform(T_M, L_M_rot);
    S.M.Read_Vec   = RM * v_M_rot;
    S.M.Laser_Norm = RM * n_M_rot;
end

function T = get_M_transform(dx, dy, alpha_deg, beta_deg)
    alp = -alpha_deg * pi / 180; 
    bet = beta_deg * pi / 180;
    Ry = [cos(alp), 0, sin(alp); 0, 1, 0; -sin(alp), 0, cos(alp)];
    Rx = [1, 0, 0; 0, cos(bet), -sin(bet); 0, sin(bet), cos(bet)];
    T = eye(4); T(1:3, 1:3) = Ry * Rx; T(1:3, 4) = [dx; dy; 0];
end

function [pt, dist] = get_line_plane_inter(L_pt, L_vec, P_pt, P_norm)
    u = L_vec / norm(L_vec); n = P_norm / norm(P_norm);
    w = L_pt - P_pt; D = dot(n, u); N = -dot(n, w);
    if abs(D) < 1e-8, pt = [NaN;NaN;NaN]; dist = NaN; else, sI = N / D; pt = L_pt + sI * u; dist = sI; end
end
function Pg = apply_transform(T, Pl), Pg = T * [Pl; ones(1, size(Pl, 2))]; Pg = Pg(1:3, :); end

function [Geo_out, gamma_out, res] = run_calibration_logic(Geo, Misalign)
    diff_S = Geo.H_S_PSD - Geo.H_S_LD;
    cost_S = @(h) calc_reading_single(h, diff_S, Geo, Misalign, 'M', 0);
    try h_new = fzero(cost_S, Geo.H_S_PSD); catch, h_new = Geo.H_S_PSD; end
    Geo_out = Geo; Geo_out.H_S_PSD = h_new; Geo_out.H_S_LD = h_new - diff_S;
    cost_M = @(g) calc_reading_single_gamma(g, Geo_out, Misalign, 'S');
    try gamma_out = fzero(cost_M, 0); catch, gamma_out = 0; end
    res = 0; 
end
function val = calc_reading_single(h, diff, Geo, Mis, target, g)
    Geo.H_S_PSD = h; Geo.H_S_LD = h - diff;
    [rs, rm] = get_readings(Geo, Mis, 0, g);
    if strcmp(target, 'M'), val = rm; else, val = rs; end
end
function val = calc_reading_single_gamma(g, Geo, Mis, target)
    [rs, rm] = get_readings(Geo, Mis, 0, g);
    if strcmp(target, 'M'), val = rm; else, val = rs; end
end