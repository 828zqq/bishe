function visualize_alignment_setup()
    dx = 5;        
    dy = 3;        
    alpha_deg = 2; 
    beta_deg = -1;
    
    z1 = 100; 
    z2 = 100; 
    H_M_LD = 20;   
    Delta_H = 10;  
    H_S_PSD_initial = 25; 
    gamma_initial_deg = 0;

    theta_deg = 0;  

    plot_size = max([z1, z2, dx, dy, H_M_LD, H_S_PSD_initial]) * 1.5;
    plane_size = plot_size / 3; 
    
    H_S_LD = H_S_PSD_initial - Delta_H;
    H_M_PSD = H_M_LD - Delta_H;
    gamma_rad = deg2rad(gamma_initial_deg);

    T_S = get_T_S(theta_deg);
    T_M = get_T_M(theta_deg, dx, dy, alpha_deg, beta_deg);

    T_M_static_transform = get_T_M(0, dx, dy, alpha_deg, beta_deg);
    

    P_S_LD_local = [0; H_S_LD; -z1; 1];

    P_S_PSD_local = [0; H_S_PSD_initial; -z1; 1];
    
    P_M_LD_local = [0; H_M_LD; z2; 1];
    P_M_PSD_local = [0; H_M_PSD; z2; 1];
    
    P_S_LD_world = T_S * P_S_LD_local;
    P_S_PSD_world = T_S * P_S_PSD_local;
    
    P_M_LD_world = T_M * P_M_LD_local;
    P_M_PSD_world = T_M * P_M_PSD_local;

    figure;
    hold on;
   
    plot3([0 plot_size*0.3], [0 0], [0 0], 'r', 'LineWidth', 2); text(plot_size*0.3, 0, 0, 'X_W');
    plot3([0 0], [0 plot_size*0.3], [0 0], 'g', 'LineWidth', 2); text(0, plot_size*0.3, 0, 'Y_W');
    plot3([0 0], [0 0], [0 plot_size*0.3], 'b', 'LineWidth', 2); text(0, 0, plot_size*0.3, 'Z_W (S-Axis)');
    
    plot3(P_S_LD_world(1), P_S_LD_world(2), P_S_LD_world(3), 'co', 'MarkerFaceColor', 'c', 'MarkerSize', 8);
    text(P_S_LD_world(1), P_S_LD_world(2), P_S_LD_world(3), '  S-LD');
    plot3(P_S_PSD_world(1), P_S_PSD_world(2), P_S_PSD_world(3), 'cs', 'MarkerFaceColor', 'c', 'MarkerSize', 8);
    text(P_S_PSD_world(1), P_S_PSD_world(2), P_S_PSD_world(3), '  S-PSD');

    V_S_Line_world = (P_S_PSD_world(1:3) - P_S_LD_world(1:3));
    P_S_Line_End = P_S_PSD_world(1:3) + V_S_Line_world * 2; 
    plot3([P_S_LD_world(1) P_S_Line_End(1)], [P_S_LD_world(2) P_S_Line_End(2)], [P_S_LD_world(3) P_S_Line_End(3)], 'c--');

    v_s1 = T_S * [-plane_size; H_S_LD; -z1-plane_size; 1];
    v_s2 = T_S * [ plane_size; H_S_LD; -z1-plane_size; 1];
    v_s3 = T_S * [ plane_size; H_S_LD; -z1+plane_size; 1];
    v_s4 = T_S * [-plane_size; H_S_LD; -z1+plane_size; 1];
    patch([v_s1(1) v_s2(1) v_s3(1) v_s4(1)], [v_s1(2) v_s2(2) v_s3(2) v_s4(2)], [v_s1(3) v_s2(3) v_s3(3) v_s4(3)], 'c', 'FaceAlpha', 0.2, 'EdgeColor', 'none');

    plot3(P_M_LD_world(1), P_M_LD_world(2), P_M_LD_world(3), 'mo', 'MarkerFaceColor', 'm', 'MarkerSize', 8);
    text(P_M_LD_world(1), P_M_LD_world(2), P_M_LD_world(3), '  M-LD');
    plot3(P_M_PSD_world(1), P_M_PSD_world(2), P_M_PSD_world(3), 'ms', 'MarkerFaceColor', 'm', 'MarkerSize', 8);
    text(P_M_PSD_world(1), P_M_PSD_world(2), P_M_PSD_world(3), '  M-PSD');

    V_M_Line_world = (P_M_PSD_world(1:3) - P_M_LD_world(1:3));
    P_M_Line_End = P_M_PSD_world(1:3) + V_M_Line_world * 2; 
    plot3([P_M_LD_world(1) P_M_Line_End(1)], [P_M_LD_world(2) P_M_Line_End(2)], [P_M_LD_world(3) P_M_Line_End(3)], 'm--');

    P_M_origin = T_M_static_transform(1:3, 4); 
    zm_vec = T_M_static_transform(1:3, 3);   
    P_axis_start = P_M_origin - zm_vec * plot_size * 1.5;
    P_axis_end   = P_M_origin + zm_vec * plot_size * 1.5;
    plot3([P_axis_start(1) P_axis_end(1)], [P_axis_start(2) P_axis_end(2)], [P_axis_start(3) P_axis_end(3)], 'm', 'LineWidth', 3);
    text(P_axis_end(1), P_axis_end(2), P_axis_end(3), '  M-Axis');
    
    n_M_local = [0; cos(gamma_rad); sin(gamma_rad)];
    R_M = T_M(1:3, 1:3);
    n_M_world = R_M * n_M_local;
    p0 = P_M_LD_world(1:3);
    a = n_M_world(1); b = n_M_world(2); c = n_M_world(3);
    
    [X_grid, Y_grid] = meshgrid(linspace(p0(1)-plane_size, p0(1)+plane_size, 10), ...
                                linspace(p0(2)-plane_size, p0(2)+plane_size, 10));
    if abs(c) > 1e-6 
        Z_grid = (-a*(X_grid - p0(1)) - b*(Y_grid - p0(2))) / c + p0(3);
        surf(X_grid, Y_grid, Z_grid, 'FaceColor', 'm', 'FaceAlpha', 0.2, 'EdgeColor', 'none');
    else
        disp('M-Laser平面近似垂直于XY面');
    end

    hold off;
    title(['对中仪可视化 (theta = ' num2str(theta_deg) ' 度)']);
    xlabel('X (WCS)');
    ylabel('Y (WCS)');
    zlabel('Z (WCS)');
    axis equal;  % 保证几何形状不失真
    grid on;
    rotate3d on;
    view(135, 30); 
end

%% 辅助函数
function T_S = get_T_S(theta_deg)
    theta_rad = deg2rad(theta_deg);
    c = cos(theta_rad);
    s = sin(theta_rad);
    
    T_S = [ c, -s,  0,  0;
            s,  c,  0,  0;
            0,  0,  1,  0;
            0,  0,  0,  1];
end

function T_M = get_T_M(theta_deg, dx, dy, alpha_deg, beta_deg)

    alpha_rad = deg2rad(alpha_deg);
    beta_rad = deg2rad(beta_deg);

    zm_unnorm = [tan(alpha_rad); tan(beta_rad); 1];
    zm = zm_unnorm / norm(zm_unnorm);

    global_Y = [0; 1; 0];
    xm_unnorm = cross(global_Y, zm);

    if norm(xm_unnorm) < 1e-9
        xm_unnorm = cross([1; 0; 0], zm);
    end
    xm = xm_unnorm / norm(xm_unnorm);

    ym = cross(zm, xm);

    P_M = [dx; dy; 0];
    
    R_M_static = [xm, ym, zm];
    T_M_static = [R_M_static, P_M;
                  0, 0, 0, 1];

    theta_rad = deg2rad(theta_deg);
    c_theta = cos(theta_rad);
    s_theta = sin(theta_rad);
    
    T_rotZ_local = [ c_theta, -s_theta,  0,  0;
                     s_theta,  c_theta,  0,  0;
                     0,          0,     1,  0;
                     0,          0,     0,  1];
    
    T_M = T_M_static * T_rotZ_local;
end