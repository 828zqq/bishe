%% System_Calibration.m 校准
function [Geo_calibrated, gamma_calibrated, Residuals] = System_Calibration(Geo, Misalign)
    
    diff_S = Geo.H_S_PSD - Geo.H_S_LD; 
    
    disp('-------------------------------------------');
    disp('开始校准过程 (θ=0)...');

    %% 1: 调整 S 机高度
    cost_func_S = @(h_s_psd) calculate_reading_M(h_s_psd, diff_S, Geo, Misalign);
    
    options = optimset('Display','off', 'TolX', 1e-6);
    try
        H_S_PSD_new = fzero(cost_func_S, Geo.H_S_PSD, options);
    catch
        error('校准失败：S 机高度无法调整到使 M 机读数为 0 (可能不对中量过大)');
    end

    Geo_calibrated = Geo;
    Geo_calibrated.H_S_PSD = H_S_PSD_new;
    Geo_calibrated.H_S_LD  = H_S_PSD_new - diff_S;
    
    fprintf('>> [步骤1] S 机高度调整完毕。\n');
    fprintf('   调整前 H_S_PSD: %.4f mm\n', Geo.H_S_PSD);
    fprintf('   调整后 H_S_PSD: %.4f mm\n', Geo_calibrated.H_S_PSD);

    %% 2: 调整 M 机激光角度
    cost_func_M = @(g) calculate_reading_S(g, Geo_calibrated, Misalign);
    
    try
        gamma_calibrated = fzero(cost_func_M, 0, options); % 初始猜测 0度
    catch
        error('校准失败：M 机角度无法调整到使 S 机读数为 0');
    end
    
    fprintf('>> [步骤2] M 机角度调整完毕。\n');
    fprintf('   计算出补偿角 gamma: %.4f deg\n', gamma_calibrated);

    %% 3. 验证 
    final_state = get_system_state(Geo_calibrated, Misalign, 0, gamma_calibrated);
    
    % 计算 S 读数
    [~, r_s] = get_line_plane_intersection(final_state.S.PSD_center, final_state.S.Read_Vec, ...
                                           final_state.M.LD_pos, final_state.M.Laser_Norm);
    % 计算 M 读数
    [~, r_m] = get_line_plane_intersection(final_state.M.PSD_center, final_state.M.Read_Vec, ...
                                           final_state.S.LD_pos, final_state.S.Laser_Norm);
                                       
    Residuals = [r_s, r_m];
    fprintf('>> 校准完成。残差 -> S读数: %.2e, M读数: %.2e\n', r_s, r_m);
    disp('-------------------------------------------');
end

%% --- 辅助计算函数  ---

function r_m = calculate_reading_M(h_s_psd, diff_s, Geo_temp, Misalign)
    Geo_temp.H_S_PSD = h_s_psd;
    Geo_temp.H_S_LD  = h_s_psd - diff_s;
    
    State = get_system_state(Geo_temp, Misalign, 0, 0);
    [~, dist] = get_line_plane_intersection(State.M.PSD_center, State.M.Read_Vec, ...
                                            State.S.LD_pos, State.S.Laser_Norm);
    r_m = dist;
end

function r_s = calculate_reading_S(gamma_val, Geo_fixed, Misalign)
    State = get_system_state(Geo_fixed, Misalign, 0, gamma_val);
    
    [~, dist] = get_line_plane_intersection(State.S.PSD_center, State.S.Read_Vec, ...
                                            State.M.LD_pos, State.M.Laser_Norm);
    r_s = dist;
end