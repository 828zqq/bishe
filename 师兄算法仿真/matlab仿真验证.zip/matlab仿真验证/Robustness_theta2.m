%% Robustness_theta.m
clc; clear; close all; format long g;

%% 1. 基础参数设定
% 不对中真值
True_Val_Unit.dx = 0.85;       
True_Val_Unit.dy = 0.55;       
True_Val_Unit.alpha = -0.95;  
True_Val_Unit.beta  = 0.65;  

True_Val_Phys.dx = True_Val_Unit.dx;
True_Val_Phys.dy = True_Val_Unit.dy;
True_Val_Phys.alpha = atand(True_Val_Unit.alpha / 100);
True_Val_Phys.beta  = atand(True_Val_Unit.beta / 100);
% 几何参数
Geo.z1 = 200; Geo.z2 = 200;
Geo.H_M_LD = 100; diff_H = 20;
Geo.H_M_PSD = Geo.H_M_LD - diff_H;
Geo.H_S_PSD = Geo.H_M_LD + 30;
Geo.H_S_LD  = Geo.H_S_PSD - diff_H;

% 扫描范围: Theta 偏差
theta_err_range = -3 : 0.1 : 3; 
num_steps = length(theta_err_range);

Err_Abs_TPM_Lin  = zeros(num_steps, 4);
Err_Abs_TPM_Iter = zeros(num_steps, 4);
Err_Abs_APM_Lin  = zeros(num_steps, 4);
Err_Abs_APM_Iter = zeros(num_steps, 4);

% APM 采样计划
APM_Targets = [45, 90, 135, 180, 225, 270, 315, 350]; 

fprintf('开始 Theta 偏差分析 (-3 deg -> +3 deg)...\n');

[Geo_Calib, gamma_calib] = calibrate_perfectly(Geo, True_Val_Phys);

%% 2. 循环扫描
for i = 1:num_steps
    err = theta_err_range(i);

    [s90, m90]   = get_readings_dual(Geo_Calib, True_Val_Phys, 90, 90+err, gamma_calib);
    [s180, m180] = get_readings_dual(Geo_Calib, True_Val_Phys, 180, 180+err, gamma_calib);
    TPM_Data = [s90, m90, s180, m180];

    APM_S = zeros(8, 1); APM_M = zeros(8, 1);
    for k = 1:8
        t_target = APM_Targets(k);
        [APM_S(k), APM_M(k)] = get_readings_dual(Geo_Calib, True_Val_Phys, t_target, t_target+err, gamma_calib);
    end

    Res_TPM_Lin = solve_TPM_linear(TPM_Data, Geo_Calib);
    Res_TPM_Iter = solve_TPM_iterative(Res_TPM_Lin, TPM_Data, Geo_Calib, gamma_calib);

    [As, Bs, Cs] = fit_sine_wave(APM_Targets, APM_S);
    [Am, Bm, Cm] = fit_sine_wave(APM_Targets, APM_M);
    Res_APM_Lin = solve_APM_linear(As, Bs, Am, Bm, Geo_Calib);
    Res_APM_Iter = solve_APM_iterative(Res_APM_Lin, APM_Targets, APM_S, APM_M, Geo_Calib, gamma_calib);

    Err_Abs_TPM_Lin(i, :)  = abs(calc_unit_error(Res_TPM_Lin, True_Val_Unit));
    Err_Abs_TPM_Iter(i, :) = abs(calc_unit_error(Res_TPM_Iter, True_Val_Unit));
    Err_Abs_APM_Lin(i, :)  = abs(calc_unit_error(Res_APM_Lin, True_Val_Unit));
    Err_Abs_APM_Iter(i, :) = abs(calc_unit_error(Res_APM_Iter, True_Val_Unit));
end

%% 3. 绘图分析
param_names = {'dx (mm)', 'dy (mm)', 'Alpha (mm/100mm)', 'Beta (mm/100mm)'};

figure('Color', 'w', 'Position', [50, 50, 1200, 700], 'Name', 'Sensitivity to Theta Deviation');
sgtitle('Impact of Angle Positioning Error (Theta Deviation) on Accuracy', 'FontSize', 14);

for k = 1:4
    subplot(2, 2, k); hold on; grid on;
    plot(theta_err_range, Err_Abs_TPM_Lin(:, k), 'r--', 'LineWidth', 1.5);
    plot(theta_err_range, Err_Abs_APM_Lin(:, k), 'b-.', 'LineWidth', 1.5);
    plot(theta_err_range, Err_Abs_TPM_Iter(:, k), 'm-', 'LineWidth', 2);
    plot(theta_err_range, Err_Abs_APM_Iter(:, k), 'k:', 'LineWidth', 2);
    
    xlabel('Theta Deviation (deg)');
    ylabel(['Abs Error (' param_names{k} ')']);
    title(param_names{k});
    
    % 标记 0 点
    xline(0, 'g-', 'Alpha', 0.3);
    
    if k==1, legend('TPM Lin', 'APM Lin', 'TPM Iter', 'APM Iter', 'Location', 'best'); end
end

%% ========================================================================

function [r_s, r_m] = get_readings_dual(Geo, Mis, theta_s_deg, theta_m_deg, gamma_deg)
    % S机状态
    S = get_S_state(Geo, theta_s_deg);
    % M机状态
    M = get_M_state(Geo, Mis, theta_m_deg, gamma_deg);

    [~, r_s] = get_line_plane_inter(S.PSD_center, S.Read_Vec, M.LD_pos, M.Laser_Norm);
    [~, r_m] = get_line_plane_inter(M.PSD_center, M.Read_Vec, S.LD_pos, S.Laser_Norm);
end

function S = get_S_state(Geo, t_deg)
    Rz = get_Rz(t_deg);
    S.PSD_center = Rz * [0; Geo.H_S_PSD; -Geo.z1];
    S.LD_pos     = Rz * [0; Geo.H_S_LD;  -Geo.z1];
    S.Read_Vec   = Rz * [0; 1; 0];
    S.Laser_Norm = Rz * [0; 1; 0];
end

function M = get_M_state(Geo, Mis, t_deg, gamma_deg)
    Rz = get_Rz(t_deg);
    ga = gamma_deg * pi/180;

    P_M0 = [0; Geo.H_M_PSD; Geo.z2];
    L_M0 = [0; Geo.H_M_LD;  Geo.z2];
    n_M0 = [0; cos(ga); -sin(ga)];

    T_M = get_M_transform(Mis.dx, Mis.dy, Mis.alpha, Mis.beta);
    RM  = T_M(1:3, 1:3);

    M.PSD_center = apply_transform(T_M, Rz * P_M0);
    M.LD_pos     = apply_transform(T_M, Rz * L_M0);
    M.Read_Vec   = RM * (Rz * [0; 1; 0]);
    M.Laser_Norm = RM * (Rz * n_M0);
end

function R = get_Rz(deg)
    rad = deg * pi/180;
    R = [cos(rad), -sin(rad), 0; sin(rad), cos(rad), 0; 0, 0, 1];
end

function [Geo, gamma] = calibrate_perfectly(Geo, Mis)
    diff_S = Geo.H_S_PSD - Geo.H_S_LD;

    cS = @(h) grw_dual(h, diff_S, Geo, Mis, 0, 0, 0, 'M');
    try h=fzero(cS, Geo.H_S_PSD); catch, h=Geo.H_S_PSD; end
    Geo.H_S_PSD = h; Geo.H_S_LD = h - diff_S;
    
    cM = @(g) grw_dual_g(g, Geo, Mis, 0, 0, 'S');
    try gamma=fzero(cM, 0); catch, gamma=0; end
end
function v = grw_dual(h, d, G, M, ts, tm, g, tg)
    G.H_S_PSD=h; G.H_S_LD=h-d; [rs,rm]=get_readings_dual(G,M,ts,tm,g);
    if strcmp(tg,'M'), v=rm; else, v=rs; end
end
function v = grw_dual_g(g, G, M, ts, tm, tg)
    [rs,rm]=get_readings_dual(G,M,ts,tm,g);
    if strcmp(tg,'M'), v=rm; else, v=rs; end
end

% --- 误差计算 ---
function err_vec = calc_unit_error(Res, True)
    res_alpha = 100 * tand(Res.alpha);
    res_beta  = 100 * tand(Res.beta);
    err_vec = [Res.dx-True.dx, Res.dy-True.dy, res_alpha-True.alpha, res_beta-True.beta];
end

function [rs, rm] = get_readings(G, M, t, g)
    [rs, rm] = get_readings_dual(G, M, t, t, g);
end
function Sol = solve_TPM_linear(Data, Geo)
    S90=Data(1); M90=Data(2); S180=Data(3); M180=Data(4); z1=Geo.z1; z2=Geo.z2;
    Sol.dy = (z1*M180 - z2*S180)/(2*(z1+z2));
    Sol.beta = atan(-(S180+M180)/(2*(z1+z2)))*180/pi;
    termS=S90-S180/2; termM=M90-M180/2;
    dx_raw = (z2*termS - z1*termM)/(z1+z2);
    alpha_rad = atan((S90+M90 - (S180+M180)/2)/(z1+z2));
    Sol.dx = -dx_raw; Sol.alpha = -alpha_rad*180/pi;
end
function Sol = solve_TPM_iterative(Init, Data, Geo, gamma)
    x = [Init.dx; Init.dy; Init.alpha; Init.beta]; Measured = Data(:);
    for k=1:5
        Mis.dx=x(1); Mis.dy=x(2); Mis.alpha=x(3); Mis.beta=x(4);
        [s90,m90]=get_readings(Geo,Mis,90,gamma); [s180,m180]=get_readings(Geo,Mis,180,gamma);
        Sim=[s90;m90;s180;m180]; Resid=Measured-Sim;
        if norm(Resid)<1e-9, break; end
        J=zeros(4,4); delta=1e-5;
        for p=1:4
            xt=x; xt(p)=xt(p)+delta; Mt.dx=xt(1); Mt.dy=xt(2); Mt.alpha=xt(3); Mt.beta=xt(4);
            [ts90,tm90]=get_readings(Geo,Mt,90,gamma); [ts180,tm180]=get_readings(Geo,Mt,180,gamma);
            J(:,p)=([ts90;tm90;ts180;tm180]-Sim)/delta;
        end
        x=x+J\Resid;
    end
    Sol.dx=x(1); Sol.dy=x(2); Sol.alpha=x(3); Sol.beta=x(4);
end
function Sol = solve_APM_linear(As, Bs, Am, Bm, Geo)
    z1=Geo.z1; z2=Geo.z2;
    ar=(As+Am)/(z1+z2); dx=(z2*As-z1*Am)/(z1+z2);
    br=(Bs+Bm)/(z1+z2); dy=(z2*Bs-z1*Bm)/(z1+z2);
    Sol.dx=-dx; Sol.alpha=-ar*180/pi; Sol.dy=dy; Sol.beta=br*180/pi;
end
function Sol = solve_APM_iterative(Init, Ang, S, M, Geo, gamma)
    x=[Init.dx;Init.dy;Init.alpha;Init.beta]; Meas=[S;M]; N=length(Ang);
    for k=1:5
        Mis.dx=x(1); Mis.dy=x(2); Mis.alpha=x(3); Mis.beta=x(4);
        SS=zeros(N,1); MM=zeros(N,1);
        for j=1:N, [SS(j),MM(j)]=get_readings(Geo,Mis,Ang(j),gamma); end
        Sim=[SS;MM]; Resid=Meas-Sim;
        if norm(Resid)<1e-9, break; end
        J=zeros(2*N,4); delta=1e-5;
        for p=1:4
            xt=x; xt(p)=xt(p)+delta; Mt.dx=xt(1); Mt.dy=xt(2); Mt.alpha=xt(3); Mt.beta=xt(4);
            St=zeros(N,1); Mt_=zeros(N,1);
            for j=1:N, [St(j),Mt_(j)]=get_readings(Geo,Mt,Ang(j),gamma); end
            J(:,p)=([St;Mt_]-Sim)/delta;
        end
        x=x+(J'*J)\(J'*Resid);
    end
    Sol.dx=x(1); Sol.dy=x(2); Sol.alpha=x(3); Sol.beta=x(4);
end

function [A,B,C]=fit_sine_wave(t,r), rad=t*pi/180; X=[sin(rad(:)),cos(rad(:)),ones(length(rad),1)]; P=X\r(:); A=P(1); B=P(2); C=P(3); end
function T=get_M_transform(x,y,a,b), a=-a*pi/180; b=b*pi/180; Ry=[cos(a) 0 sin(a);0 1 0;-sin(a) 0 cos(a)]; Rx=[1 0 0;0 cos(b) -sin(b);0 sin(b) cos(b)]; T=eye(4); T(1:3,1:3)=Ry*Rx; T(1:3,4)=[x;y;0]; end
function [p,d]=get_line_plane_inter(Lp,Lv,Pp,Pn), u=Lv/norm(Lv); n=Pn/norm(Pn); w=Lp-Pp; D=dot(n,u); N=-dot(n,w); if abs(D)<1e-8, p=[NaN;NaN;NaN]; d=NaN; else, s=N/D; p=Lp+s*u; d=s; end; end
function P=apply_transform(T,p), P=T*[p;ones(1,size(p,2))]; P=P(1:3,:); end