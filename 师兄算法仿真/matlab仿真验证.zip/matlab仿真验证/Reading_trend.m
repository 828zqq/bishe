clc; clear; close all; format long g;
%% 1. 基础参数设定
Geo.z1 = 180;
Geo.z2 = 150;

Geo.H_M_LD = 200;
diff_H = 20;
Geo.H_M_PSD = Geo.H_M_LD - diff_H;

Geo.H_S_PSD = Geo.H_M_LD + 30; 
Geo.H_S_LD  = Geo.H_S_PSD - diff_H;

% 不对中真值设定
Misalign.dx = -0.5;
Misalign.dy = 0.5;
Misalign.alpha = 0.5;
Misalign.beta  = 0.8; 

% 采样设置
theta_start = 0;
theta_end   = 360;
step_size   = 0.5;

filename = 'Simulation_Data.csv'; 

%% 2. 系统初始化与校准
fprintf('正在初始化系统...\n');
fprintf('不对中真值: dx=%.2f, dy=%.2f, alpha=%.2f, beta=%.2f\n', ...
    Misalign.dx, Misalign.dy, Misalign.alpha, Misalign.beta);

[Geo_Calib, gamma_calib, ~] = run_calibration_logic(Geo, Misalign);

fprintf('校准完成。系统已就绪 (Theta=0 时读数归零)。\n');

%% 3. 数据生成循环
theta_list = theta_start : step_size : theta_end;
num_points = length(theta_list);

data_table = zeros(num_points, 3);

fprintf('正在生成数据 (0-360 deg)...\n');

for i = 1:num_points
    theta_deg = theta_list(i);

    [s_val, m_val] = get_readings(Geo_Calib, Misalign, theta_deg, gamma_calib);

    data_table(i, :) = [theta_deg, s_val, m_val];
end

%% 4 绘图
fprintf('正在生成趋势图...\n');

figure('Name', 'S and M Readings Analysis', 'Color', 'w', 'Position', [100, 100, 800, 500]);
plot(theta_list, data_table(:, 2), 'b-', 'LineWidth', 1.5); hold on;
plot(theta_list, data_table(:, 3), 'r--', 'LineWidth', 1.5);

grid on;
xlabel('Rotation Angle \theta (deg)', 'FontSize', 12);
ylabel('Reading Value (mm)', 'FontSize', 12);
title(['S & M Readings vs Theta (dx=', num2str(Misalign.dx), ', dy=', num2str(Misalign.dy),',α=',num2str(Misalign.alpha) ,',β=',num2str(Misalign.beta),')'], 'FontSize', 13);
legend({'S Reading', 'M Reading'}, 'Location', 'best', 'FontSize', 11);
xlim([theta_start, theta_end]);

plot_filename = 'Readings_Plot.png';
saveas(gcf, plot_filename);
fprintf('图片已保存为: %s\n', fullfile(pwd, plot_filename));

%% 函数
function [r_s, r_m] = get_readings(Geo, Mis, theta_deg, gamma_deg)
    S = get_system_state(Geo, Mis, theta_deg, gamma_deg);
    [~, r_s] = get_line_plane_inter(S.S.PSD_center, S.S.Read_Vec, ...
                                    S.M.LD_pos, S.M.Laser_Norm);
    [~, r_m] = get_line_plane_inter(S.M.PSD_center, S.M.Read_Vec, ...
                                    S.S.LD_pos, S.S.Laser_Norm);
end

function S = get_system_state(Geo, Mis, theta_deg, gamma_deg)
    theta = theta_deg * pi / 180;
    gamma = gamma_deg * pi / 180;
    Rz = [cos(theta), -sin(theta), 0; sin(theta), cos(theta), 0; 0, 0, 1];

    P_S0 = [0; Geo.H_S_PSD; -Geo.z1];
    L_S0 = [0; Geo.H_S_LD;  -Geo.z1];
    S.S.PSD_center = Rz * P_S0;
    S.S.LD_pos     = Rz * L_S0;
    S.S.Read_Vec   = Rz * [0; 1; 0];
    S.S.Laser_Norm = Rz * [0; 1; 0];

    P_M0 = [0; Geo.H_M_PSD; Geo.z2];
    L_M0 = [0; Geo.H_M_LD;  Geo.z2];
    n_M0 = [0; cos(gamma); -sin(gamma)];
    
    P_M_rot = Rz * P_M0; L_M_rot = Rz * L_M0;
    v_M_rot = Rz * [0; 1; 0]; n_M_rot = Rz * n_M0;
    
    T_M = get_M_transform(Mis.dx, Mis.dy, Mis.alpha, Mis.beta);
    RM  = T_M(1:3, 1:3);
    
    S.M.PSD_center = apply_transform(T_M, P_M_rot);
    S.M.LD_pos     = apply_transform(T_M, L_M_rot);
    S.M.Read_Vec   = RM * v_M_rot;
    S.M.Laser_Norm = RM * n_M_rot;
end

% --- 坐标变换矩阵 ---
function T = get_M_transform(dx, dy, alpha_deg, beta_deg)
    alp = -alpha_deg * pi / 180;
    bet = beta_deg * pi / 180;
    Ry = [cos(alp), 0, sin(alp); 0, 1, 0; -sin(alp), 0, cos(alp)];
    Rx = [1, 0, 0; 0, cos(bet), -sin(bet); 0, sin(bet), cos(bet)];
    T = eye(4); T(1:3, 1:3) = Ry * Rx; T(1:3, 4) = [dx; dy; 0];
end

% --- 线面交点求解 ---
function [pt, dist] = get_line_plane_inter(L_pt, L_vec, P_pt, P_norm)
    u = L_vec / norm(L_vec); n = P_norm / norm(P_norm);
    w = L_pt - P_pt; D = dot(n, u); N = -dot(n, w);
    if abs(D) < 1e-8, pt = [NaN;NaN;NaN]; dist = NaN; else, sI = N / D; pt = L_pt + sI * u; dist = sI; end
end
function Pg = apply_transform(T, Pl), Pg = T * [Pl; ones(1, size(Pl, 2))]; Pg = Pg(1:3, :); end

% --- 自动校准逻辑 ---
function [Geo_out, gamma_out, res] = run_calibration_logic(Geo, Misalign)
    diff_S = Geo.H_S_PSD - Geo.H_S_LD;
    cost_S = @(h) calc_reading_single(h, diff_S, Geo, Misalign, 'M', 0);
    try h_new = fzero(cost_S, Geo.H_S_PSD); catch, h_new = Geo.H_S_PSD; end
    Geo_out = Geo; Geo_out.H_S_PSD = h_new; Geo_out.H_S_LD = h_new - diff_S;
    cost_M = @(g) calc_reading_single_gamma(g, Geo_out, Misalign, 'S');
    try gamma_out = fzero(cost_M, 0); catch, gamma_out = 0; end
    res = 0; 
end
function val = calc_reading_single(h, diff, Geo, Mis, target, g)
    Geo.H_S_PSD = h; Geo.H_S_LD = h - diff;
    [rs, rm] = get_readings(Geo, Mis, 0, g);
    if strcmp(target, 'M'), val = rm; else, val = rs; end
end
function val = calc_reading_single_gamma(g, Geo, Mis, target)
    [rs, rm] = get_readings(Geo, Mis, 0, g);
    if strcmp(target, 'M'), val = rm; else, val = rs; end
end