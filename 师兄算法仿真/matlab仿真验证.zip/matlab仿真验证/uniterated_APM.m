%% Main_ArbitraryPoint_Fitting.m
clc; clear; close all; format long g;

%% 1. 基础参数设定
Geo.z1 = 150;          
Geo.z2 = 150;

True_Val.dx = 2.0;      
True_Val.dy = -1.5;     
True_Val.alpha = 1.2;   
True_Val.beta  = -0.8;  

filename = 'Simulation_Data.csv';
if ~isfile(filename)
    error('找不到文件 %s，请先运行数据生成脚本！', filename);
end
RawData = readtable(filename);

fprintf('已加载数据，共 %d 个采样点。\n', height(RawData));
fprintf('真值设定: dx=%.2f, dy=%.2f, alpha=%.2f, beta=%.2f\n', ...
    True_Val.dx, True_Val.dy, True_Val.alpha, True_Val.beta);

%% 2. 多组实验对比 

N_list = [3, 4, 5, 6, 8, 10]; 

fprintf('\n==========================================================================\n');
fprintf(' %-6s | %-20s | %-20s | %-20s\n', 'Points', 'dx Error(mm)', 'dy Error(mm)', 'Total Angle Err(°)');
fprintf('==========================================================================\n');

for i = 1:length(N_list)
    N = N_list(i);
    
    [SelectedData, status] = select_valid_points(RawData, N, 25);
    
    if ~status
        fprintf(' N=%d: 无法找到满足间隔约束的点分布。\n', N);
        continue;
    end

    % 模型: Reading = A*sin(theta) + B*cos(theta) + C
    [As, Bs, Cs] = fit_sine_wave(SelectedData.Theta_deg, SelectedData.S_Reading_mm);
    [Am, Bm, Cm] = fit_sine_wave(SelectedData.Theta_deg, SelectedData.M_Reading_mm);

    Calculated = solve_misalignment(As, Bs, Am, Bm, Geo);

    err_dx = abs(Calculated.dx - True_Val.dx);
    err_dy = abs(Calculated.dy - True_Val.dy);
    err_a  = abs(Calculated.alpha - True_Val.alpha);
    err_b  = abs(Calculated.beta - True_Val.beta);
    total_ang_err = sqrt(err_a^2 + err_b^2);
    
    fprintf(' N=%-2d   | %.2e             | %.2e             | %.2e\n', ...
        N, err_dx, err_dy, total_ang_err);
end
fprintf('==========================================================================\n');

%% 3. 展示结果
fprintf('\n=== 详细解算报告 (基于 N=%d) ===\n', N);
fprintf('拟合参数:\n');
fprintf('  S机: %.4f sin(θ) + %.4f cos(θ) + %.4f\n', As, Bs, Cs);
fprintf('  M机: %.4f sin(θ) + %.4f cos(θ) + %.4f\n', Am, Bm, Cm);
fprintf('\n解算结果对比:\n');
print_comparison('dx (mm)', True_Val.dx, Calculated.dx);
print_comparison('dy (mm)', True_Val.dy, Calculated.dy);
print_comparison('α (deg)', True_Val.alpha, Calculated.alpha);
print_comparison('β (deg)', True_Val.beta, Calculated.beta);


%% ========================================================================
% 最小二乘法拟合
function [A, B, C] = fit_sine_wave(theta_deg, readings)
    theta_rad = theta_deg * pi / 180;

    col_sin = sin(theta_rad);
    col_cos = cos(theta_rad);
    col_one = ones(length(theta_deg), 1);
    
    X = [col_sin, col_cos, col_one];
    Y = readings;
    
    P = X \ Y; 
    
    A = P(1);
    B = P(2);
    C = P(3);
end

% 参数反解
function Sol = solve_misalignment(As, Bs, Am, Bm, Geo)
    z1 = Geo.z1;
    z2 = Geo.z2;
    
    alpha_rad = (As + Am) / (z1 + z2);
    dx_raw    = (z2 * As - z1 * Am) / (z1 + z2);
    
    beta_rad = (Bs + Bm) / (z1 + z2);
    dy_raw   = (z2 * Bs - z1 * Bm) / (z1 + z2);
    
    Sol.dx    = -dx_raw;
    Sol.alpha = -(alpha_rad * 180 / pi);

    Sol.dy    = dy_raw;
    Sol.beta  = beta_rad * 180 / pi;
end

% 选点逻辑 
function [SubTable, success] = select_valid_points(RawData, N, min_gap)
    total_rows = height(RawData)
    indices = round(linspace(1, total_rows, N))';

    angles = RawData.Theta_deg(indices);
    diffs = diff(angles);

    if any(diffs < min_gap)
        success = false;
        SubTable = [];
    else
        success = true;
        SubTable = RawData(indices, :);
    end
end

function print_comparison(label, true_v, calc_v)
    err = abs(calc_v - true_v);
    if abs(true_v) > 1e-9
        rel = (err / abs(true_v)) * 100;
    else
        rel = 0;
    end
    fprintf('%-10s | 真值: %8.4f | 解算: %8.4f | 误差: %.1e (%.4f%%)\n', ...
        label, true_v, calc_v, err, rel);
end