function State = get_system_state(Geo, Misalign, theta_deg, gamma_deg)
    
    theta = theta_deg * pi / 180;
    gamma = gamma_deg * pi / 180;

    %% ---------------- S 机 ----------------

    P_S_LD_0   = [0; Geo.H_S_LD;  -Geo.z1];
    P_S_PSD_0  = [0; Geo.H_S_PSD; -Geo.z1];

    v_S_read_0 = [0; 1; 0]; 
    
    n_S_laser_0 = [0; 1; 0];

    R_z = [cos(theta), -sin(theta), 0;
           sin(theta),  cos(theta), 0;
           0,           0,          1];
       
    State.S.LD_pos      = R_z * P_S_LD_0;
    State.S.PSD_center  = R_z * P_S_PSD_0;
    State.S.Read_Vec    = R_z * v_S_read_0;   % 向量只旋转
    State.S.Laser_Norm  = R_z * n_S_laser_0;  % 向量只旋转

    %% ---------------- M 机  ----------------
    P_M_LD_0   = [0; Geo.H_M_LD;  Geo.z2];
    P_M_PSD_0  = [0; Geo.H_M_PSD; Geo.z2];
    
    v_M_read_0 = [0; 1; 0];
    
    n_M_laser_0 = [0; cos(gamma); -sin(gamma)];
    
    P_M_LD_rot   = R_z * P_M_LD_0;
    P_M_PSD_rot  = R_z * P_M_PSD_0;
    v_M_read_rot = R_z * v_M_read_0;
    n_M_laser_rot= R_z * n_M_laser_0;

    T_M = get_M_transform(Misalign.dx, Misalign.dy, Misalign.alpha, Misalign.beta);
    R_M = T_M(1:3, 1:3); 
    
    State.M.LD_pos     = apply_transform(T_M, P_M_LD_rot);
    State.M.PSD_center = apply_transform(T_M, P_M_PSD_rot);

    State.M.Read_Vec   = R_M * v_M_read_rot;
    State.M.Laser_Norm = R_M * n_M_laser_rot;
    
end