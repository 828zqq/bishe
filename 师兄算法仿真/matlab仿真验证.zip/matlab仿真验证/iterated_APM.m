clc; clear; close all; format long g;

%% 1. 基础参数设定
Geo.z1 = 5000; Geo.z2 = 5000;
Geo.H_M_LD = 70; diff_H = 20;
Geo.H_S_PSD = 100; Geo.H_S_LD = Geo.H_S_PSD - diff_H;
Geo.H_M_PSD = Geo.H_M_LD - diff_H;

% 要确保不对中真值保证与表格相同
True_Val.dx = 2.0;      
True_Val.dy = -1.50;     
True_Val.alpha = 1.2;   
True_Val.beta  = -0.8;  

filename = 'Simulation_Data.csv';
if ~isfile(filename)
    error('请先运行 Data_Generator_AnyPoint.m 生成数据！');
end
RawData = readtable(filename);

[Geo_Calib, gamma_calib, ~] = run_calibration_logic(Geo, True_Val);

%% 2. 选点
N = 3; 

indices = round(linspace(10, height(RawData)-10, N))'; 
SelectedData = RawData(indices, :);

fprintf('选中 %d 个采样点，角度分布: %s\n', N, mat2str(SelectedData.Theta_deg', 3));

%% 3.传统任意点法 (解析解 -> 初值)
[As, Bs, Cs] = fit_sine_wave(SelectedData.Theta_deg, SelectedData.S_Reading_mm);
[Am, Bm, Cm] = fit_sine_wave(SelectedData.Theta_deg, SelectedData.M_Reading_mm);

Initial_Guess = solve_misalignment_linear(As, Bs, Am, Bm, Geo);  %反解不对中量

fprintf('\n--- 阶段一：传统解析解 (Initial Guess) ---\n');
print_comparison('dx', True_Val.dx, Initial_Guess.dx);
print_comparison('dy', True_Val.dy, Initial_Guess.dy);
print_comparison('alpha', True_Val.alpha, Initial_Guess.alpha);
print_comparison('beta', True_Val.beta, Initial_Guess.beta);
fprintf('  >> 存在模型误差 (约 4-5%%)\n');

%% 4. 高斯-牛顿迭代优化 (数值解 -> 精确解)
fprintf('\n--- 阶段二：多点迭代优化 (Gauss-Newton) ---\n');

% 构造初始向量 x0
x_curr = [Initial_Guess.dx; Initial_Guess.dy; Initial_Guess.alpha; Initial_Guess.beta];
Thetas = SelectedData.Theta_deg;
Measured_Vec = [SelectedData.S_Reading_mm; SelectedData.M_Reading_mm]; 

for iter = 1:5
    Mis_curr.dx = x_curr(1); Mis_curr.dy = x_curr(2);
    Mis_curr.alpha = x_curr(3); Mis_curr.beta = x_curr(4);
    
    Sim_S = zeros(N, 1); Sim_M = zeros(N, 1);
    for k = 1:N
        [Sim_S(k), Sim_M(k)] = get_readings(Geo_Calib, Mis_curr, Thetas(k), gamma_calib);
    end
    Sim_Vec = [Sim_S; Sim_M];
    
    Residual = Measured_Vec - Sim_Vec;
    
    %构建雅可比矩阵 J
    J = zeros(2*N, 4);
    delta = 1e-5;
    for p = 1:4
        x_tmp = x_curr; x_tmp(p) = x_tmp(p) + delta;
        Mis_tmp.dx = x_tmp(1); Mis_tmp.dy = x_tmp(2);
        Mis_tmp.alpha = x_tmp(3); Mis_tmp.beta = x_tmp(4);
        
        S_tmp = zeros(N, 1); M_tmp = zeros(N, 1);
        for k = 1:N
            [S_tmp(k), M_tmp(k)] = get_readings(Geo_Calib, Mis_tmp, Thetas(k), gamma_calib);
        end
        Vec_tmp = [S_tmp; M_tmp];
        J(:, p) = (Vec_tmp - Sim_Vec) / delta;
    end
 
    %高斯-牛顿更新
    delta_x = (J' * J) \ (J' * Residual);
    x_curr = x_curr + delta_x;
    
    fprintf('  Iter %d: Residual Norm = %.2e\n', iter, norm(Residual));
    if norm(delta_x) < 1e-6, break; end
end

%% 5. 结果对比
fprintf('\n--- 最终结果 (Final Iterated) ---\n');
print_comparison('dx', True_Val.dx, x_curr(1));
print_comparison('dy', True_Val.dy, x_curr(2));
print_comparison('alpha', True_Val.alpha, x_curr(3));
print_comparison('beta', True_Val.beta, x_curr(4));


%% ========================================================================
% 1. 拟合正弦
function [A, B, C] = fit_sine_wave(theta_deg, readings)
    rad = theta_deg * pi / 180;
    X = [sin(rad), cos(rad), ones(length(rad), 1)];
    P = X \ readings;
    A = P(1); B = P(2); C = P(3);
end

% 2. 线性初值解算
function Sol = solve_misalignment_linear(As, Bs, Am, Bm, Geo)
    z1 = Geo.z1; z2 = Geo.z2;
    alpha_rad = (As + Am) / (z1 + z2);
    dx_raw    = (z2 * As - z1 * Am) / (z1 + z2);
    beta_rad  = (Bs + Bm) / (z1 + z2);
    dy_raw    = (z2 * Bs - z1 * Bm) / (z1 + z2);
    Sol.dx = -dx_raw; Sol.alpha = -(alpha_rad*180/pi);
    Sol.dy = dy_raw; Sol.beta = beta_rad*180/pi;
end

% 3. 物理引擎
function [r_s, r_m] = get_readings(Geo, Mis, theta_deg, gamma_deg)
    S = get_system_state(Geo, Mis, theta_deg, gamma_deg);
    [~, r_s] = get_line_plane_inter(S.S.PSD_center, S.S.Read_Vec, S.M.LD_pos, S.M.Laser_Norm);
    [~, r_m] = get_line_plane_inter(S.M.PSD_center, S.M.Read_Vec, S.S.LD_pos, S.S.Laser_Norm);
end
function S = get_system_state(Geo, Mis, theta_deg, gamma_deg)
    theta = theta_deg * pi/180; gamma = gamma_deg * pi/180;
    Rz = [cos(theta) -sin(theta) 0; sin(theta) cos(theta) 0; 0 0 1];
    P_S0 = [0; Geo.H_S_PSD; -Geo.z1]; L_S0 = [0; Geo.H_S_LD; -Geo.z1];
    S.S.PSD_center = Rz*P_S0; S.S.LD_pos = Rz*L_S0; 
    S.S.Read_Vec = Rz*[0;1;0]; S.S.Laser_Norm = Rz*[0;1;0];
    
    P_M0 = [0; Geo.H_M_PSD; Geo.z2]; L_M0 = [0; Geo.H_M_LD; Geo.z2];
    n_M0 = [0; cos(gamma); -sin(gamma)];
    T_M = get_M_transform(Mis.dx, Mis.dy, Mis.alpha, Mis.beta); RM = T_M(1:3,1:3);
    
    S.M.PSD_center = apply_transform(T_M, Rz*P_M0);
    S.M.LD_pos = apply_transform(T_M, Rz*L_M0);
    S.M.Read_Vec = RM*(Rz*[0;1;0]); S.M.Laser_Norm = RM*(Rz*n_M0);
end
function T = get_M_transform(dx, dy, a, b)
    a = -a * pi/180; b = b * pi/180; % Alpha符号修正
    Ry = [cos(a) 0 sin(a); 0 1 0; -sin(a) 0 cos(a)];
    Rx = [1 0 0; 0 cos(b) -sin(b); 0 sin(b) cos(b)];
    T = eye(4); T(1:3,1:3) = Ry*Rx; T(1:3,4) = [dx;dy;0];
end
function [pt, dist] = get_line_plane_inter(L_pt, L_vec, P_pt, P_norm)
    u = L_vec/norm(L_vec); n = P_norm/norm(P_norm); w = L_pt - P_pt;
    D = dot(n, u); N = -dot(n, w);
    if abs(D)<1e-8, pt=[NaN;NaN;NaN]; dist=NaN; else, sI=N/D; pt=L_pt+sI*u; dist=sI; end
end
function Pg = apply_transform(T, Pl), Pg = T*[Pl;ones(1,size(Pl,2))]; Pg=Pg(1:3,:); end
function [Geo, gamma, res] = run_calibration_logic(Geo, Mis)
    diff_S = Geo.H_S_PSD - Geo.H_S_LD;
    cost_S = @(h) get_readings_wrapper(h, diff_S, Geo, Mis, 0, 'M');
    try h_new = fzero(cost_S, Geo.H_S_PSD); catch, h_new = Geo.H_S_PSD; end
    Geo.H_S_PSD = h_new; Geo.H_S_LD = h_new - diff_S;
    cost_M = @(g) get_readings_wrapper_g(g, Geo, Mis, 'S');
    try gamma = fzero(cost_M, 0); catch, gamma=0; end
    res=0;
end
function val = get_readings_wrapper(h, diff, Geo, Mis, g, target)
    Geo.H_S_PSD = h; Geo.H_S_LD = h-diff;
    [rs, rm] = get_readings(Geo, Mis, 0, g);
    if strcmp(target,'M'), val=rm; else, val=rs; end
end
function val = get_readings_wrapper_g(g, Geo, Mis, target)
    [rs, rm] = get_readings(Geo, Mis, 0, g);
    if strcmp(target,'M'), val=rm; else, val=rs; end
end
function print_comparison(lab, true_v, calc_v)
    err = abs(calc_v - true_v);
    if abs(true_v)>1e-9, rel=err/abs(true_v)*100; else, rel=0; end
    fprintf('%-6s | 真值: %7.4f | 解算: %7.4f | 误差: %.1e (%.4f%%)\n', lab, true_v, calc_v, err, rel);
end