function P_global = apply_transform(T, P_local)
    num_points = size(P_local, 2);
    P_homo = [P_local; ones(1, num_points)];
    P_out = T * P_homo;
    P_global = P_out(1:3, :);
end