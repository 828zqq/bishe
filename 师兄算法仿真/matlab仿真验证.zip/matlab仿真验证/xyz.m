function xyz()
    figure('Color', 'w', 'Position', [100, 100, 1200, 400]);
    L = 1;
    vec_x = [0, L, 0]; 
    vec_y = [0, 0, L];
    vec_z = [L, 0, 0]; 
    subplot(1, 3, 1);
    hold on;
    draw_axes(vec_x, vec_y, vec_z, L);
    view(120, 30); 
    title('3D 视图', 'FontSize', 12);
    subplot(1, 3, 2);
    hold on;
    draw_axes(vec_x, vec_y, vec_z, L);
    view(0, 0); 
    title('YOZ 面 (侧视)', 'FontSize', 12);
    subplot(1, 3, 3);
    hold on;
    draw_axes(vec_x, vec_y, vec_z, L);
    view(0, 90); 
    title('XOZ 面 (俯视)', 'FontSize', 12);
end

function draw_axes(vec_x, vec_y, vec_z, L)   
    origin = [0, 0, 0];
    quiver3(origin(1), origin(2), origin(3), vec_x(1), vec_x(2), vec_x(3), ...
        'k', 'LineWidth', 1.5, 'MaxHeadSize', 0.1, 'AutoScale', 'off');
    quiver3(origin(1), origin(2), origin(3), vec_y(1), vec_y(2), vec_y(3), ...
        'k', 'LineWidth', 1.5, 'MaxHeadSize', 0.1, 'AutoScale', 'off');
    quiver3(origin(1), origin(2), origin(3), vec_z(1), vec_z(2), vec_z(3), ...
        'k', 'LineWidth', 1.5, 'MaxHeadSize', 0.1, 'AutoScale', 'off');
    offset = 0.1 * L;
    text(vec_x(1), vec_x(2)+offset, vec_x(3), 'X', 'FontSize', 14, 'Interpreter', 'latex');
    text(vec_y(1), vec_y(2), vec_y(3)+offset, 'Y', 'FontSize', 14, 'Interpreter', 'latex');
    text(vec_z(1)+offset, vec_z(2), vec_z(3), 'Z', 'FontSize', 14, 'Interpreter', 'latex');
    text(-0.05, -0.05, -0.05, 'O', 'FontSize', 14, 'Interpreter', 'latex');
    axis equal;    
    axis off;        
    grid off;        
    xlim([-0.2, 1.2]); ylim([-0.2, 1.2]); zlim([-0.2, 1.2]);
end